#!/bin/sh
set -e
x86_64-w64-mingw32-windres recorder.rc -O coff -o rc.o
x86_64-w64-mingw32-gcc -Os -s -municode -mwindows -static -I shine -o TypeScribe.exe recorder.c player.c mp3enc.c webpanel.c shine/*.c rc.o -lwinmm -lshell32 -lcomctl32 -lcomdlg32 -lgdi32 -luser32 -lole32 -loleaut32 -ladvapi32 -lmsimg32 -lmfplat -lmfreadwrite -lmfuuid -luuid -lm
