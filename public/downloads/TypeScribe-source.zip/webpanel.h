#ifndef WEBPANEL_H
#define WEBPANEL_H
#include <windows.h>
/* Embedded TypeMyworDz panel (Microsoft Edge WebView2). Everything is optional:
   if the WebView2 Runtime is missing, wp_start reports it and the recorder
   keeps working, opening the website in the normal browser instead. */
typedef void (*wp_fail_fn)(const wchar_t *why);
int  wp_start(HWND parent, int x, int y, int w, int h, const wchar_t *url, wp_fail_fn fail);
void wp_bounds(int x, int y, int w, int h);
void wp_visible(int on);
int  wp_started(void);
void wp_send_audio(const wchar_t *path);   /* hand the current audio to the page */
void wp_destroy(void);
void wp_clear(void);                       /* reload the page blank (clears any transcript) */
typedef void (*wp_req_fn)(void);
void wp_set_request_cb(wp_req_fn f);       /* page asked for the loaded audio */
#endif
