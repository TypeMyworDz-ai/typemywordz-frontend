/* TypeScribe (formerly TypeMyworDz Recorder) for Windows: record, play back and
   transcribe. One small file, no installer.
   Records the microphone straight to disk as an MP3 (32 kbps by default) or a
   WAV. The file is written as the recording goes, so a crash or a power cut
   never loses the take. MP3 encoding by Shine (LGPL 2.1), see ABOUT file. */
#define UNICODE
#define _UNICODE
#define WINVER 0x0601
#define _WIN32_WINNT 0x0601
#include <windows.h>
#include <mmsystem.h>
#include <shellapi.h>
#include <shlobj.h>
#include <commctrl.h>
#include <commdlg.h>
#include <stdio.h>
#include <stdlib.h>
#include <math.h>
#include <wchar.h>
#include "mp3enc.h"
#include "player.h"
#include "webpanel.h"

#define ID_REC 101
#define ID_PAUSE 102
#define ID_STOP 103
#define ID_MARK 104
#define ID_SKIP 105
#define ID_QUAL 106
#define ID_OVER 107
#define ID_TOP 108
#define ID_SETTINGS 109
#define ID_TIMER_TXT 110
#define ID_STATUS 111
#define ID_MSG 112
#define ID_FOLDER 113
#define ID_WEB 114
#define ID_SHRINK 115
#define ID_FOOT 116
#define ID_DIR 117
#define ID_NAME 118
#define ID_DIRTXT 119
#define ID_SIZE 120
#define ID_HOTKEY_CHANGE 121
#define ID_HOTKEY_DEFAULT 122
#define ID_PLAY 130
#define ID_BACK 131
#define ID_START 132
#define ID_SEEK 133
#define ID_VOL 134
#define ID_SPEED 135
#define ID_PTIME 136
#define ID_PVOLTXT 137
#define ID_PSPDTXT 138
#define ID_BACKSECS 139
#define ID_FORWARD 149
#define ID_OPENF 146
#define ID_LASTREC 147
#define ID_PNAME 148
#define ID_SC_CHANGE 160   /* 160..163 */
#define ID_SC_DEFAULT 164  /* 164..167 */
#define TIMER_PLAY 2
#define HOTKEY_REC 1
#define HOTKEY_PLAY 2  /* 2..5 are the global playback shortcuts */
#define TIMER_UI 1
#define NBUF 4
#ifndef MOD_NOREPEAT
#define MOD_NOREPEAT 0x4000
#endif
#define DEFAULT_HOTKEY_VK 'R'
#define DEFAULT_HOTKEY_MODS (MOD_CONTROL | MOD_SHIFT)
#define PW_X 30
static int g_waveY = 150;
#define PW_Y g_waveY
#define PW_W 320
#define PW_H 52
#define RECORDER_VERSION L"2.0"
#define APP_NAME L"TypeScribe"
#define PANEL_W 440
#define ID_PSTOP 150
#define TSS_CLASS L"TSSlider"
#define WINSTYLE (WS_OVERLAPPEDWINDOW | WS_CLIPCHILDREN)
#define MINISTYLE (WS_CAPTION | WS_SYSMENU | WS_MINIMIZEBOX | WS_CLIPCHILDREN)
#define LW 380
#define STRIP_W 18
#define WEB_MIN 360
#define ID_COLLAPSE 170
#define ID_MINI 171

enum { S_IDLE, S_REC, S_PAUSED };

static const struct { const wchar_t *label; int kbps; int rate; } FMT[] = {
    { L"MP3 32 kbps, smallest", 32, 22050 },
    { L"MP3 48 kbps, clear voice (default)", 48, 22050 },
    { L"MP3 64 kbps", 64, 22050 },
    { L"MP3 96 kbps, high quality", 96, 44100 },
    { L"MP3 128 kbps, best quality", 128, 44100 },
    { L"WAV, lossless (very large files)", 0, 44100 },
};
#define NFMT 6
#define DEFAULT_FMT 1

/* Playback keyboard shortcuts. Registered system-wide, including while minimized. */
#define NSC 4
static const struct { const wchar_t *label; UINT vk; UINT mods; const wchar_t *key; } SC_DEF[NSC] = {
    { L"Play / pause", VK_SPACE, MOD_CONTROL, L"PlayKey0" },
    { L"Rewind", VK_LEFT, MOD_CONTROL, L"PlayKey1" },
    { L"Go to the start (00:00:00)", VK_HOME, MOD_CONTROL, L"PlayKey2" },
    { L"Forward 5 seconds", VK_RIGHT, MOD_CONTROL, L"PlayKey3" },
};
static const wchar_t *SC_MODKEY[NSC] = { L"PlayMods0", L"PlayMods1", L"PlayMods2", L"PlayMods3" };
static UINT g_scVk[NSC], g_scMods[NSC];
static int g_scHotkeyOk[NSC];
static void sc_unregister_global_hotkeys(void);
static int sc_register_global_hotkeys(void);
static int g_scCap = -1;
static const int REWIND_CHOICES[] = { 1, 2, 3, 5, 10, 15, 30 };
#define NREWIND 7
static int g_rewind = 5, g_plOk = 0, g_seekDrag = 0;
static void update_buttons(void);
static void layout(void);
static int g_plIsFile = 0;
static HWND g_pOpen, g_pLast, g_pName;
static HWND g_pBtn[5], g_pTime, g_pSeek, g_pVolTxt, g_pVol, g_pSpdTxt, g_pSpd;
static HWND g_lblPlay, g_lblBack, g_backCombo, g_scLbl[NSC], g_scVal[NSC], g_scBtn[NSC], g_scDef[NSC];
static int g_clipBufs = 0, g_totalBufs = 0, g_clipHold = 0, g_clipShown = 0;
static float g_lim = 1.0f;

static HINSTANCE g_inst;
static HWND g_wnd, g_timer, g_status, g_msg, g_skip, g_qual, g_over, g_top, g_name, g_lblName, g_lblQ, g_lblDir, g_dirTxt, g_btnSet, g_btnDir, g_foot, g_btn[9];
static HWND g_lblHotkey, g_hotkeyValue, g_hotkeyNote;
static HFONT g_font, g_fontBig, g_fontSmall, g_fontBrand;
static int g_panelOpen = 0;
static int g_mini = 0, g_collapsed = 0, g_ox = 0, g_hideAll = 0, g_noResize = 0, g_forceW = 0, g_needH = 520, g_miniCut = 100000, g_normValid = 0, g_userH = 0;
static RECT g_webRc, g_normRc;
static HWND g_btnMini, g_strip;
static wchar_t g_curAudio[MAX_PATH];
static HICON g_logo;
static HBRUSH g_white;
static int g_state = S_IDLE, g_showSet = 0, g_fmt = 0, g_isMp3 = 1;
static double g_scale = 1.0, g_dpi = 1.0;
static int g_zoom = 100, g_hotkeyOk = 0, g_hotkeyCapturing = 0;
static UINT g_hotkeyVk = DEFAULT_HOTKEY_VK, g_hotkeyMods = DEFAULT_HOTKEY_MODS;
static double g_fontScale = 1.0;
static HWND g_lblSize, g_size;
static const struct { const wchar_t *label; int pct; } ZOOMS[] = {
    { L"50%", 50 }, { L"60%", 60 }, { L"70%", 70 }, { L"80%", 80 },
    { L"90%", 90 }, { L"100%", 100 }, { L"110%", 110 }, { L"120%", 120 },
    { L"130%", 130 }, { L"140%", 140 }, { L"150%", 150 },
};
#define NZOOM 11
static HWAVEIN g_in;
static WAVEHDR g_hdr[NBUF];
static char *g_buf[NBUF];
static int g_rate = 22050;
static HANDLE g_file = INVALID_HANDLE_VALUE;
static DWORD g_dataBytes = 0;
static int g_peak = 0, g_silentMs = 0, g_bufCount = 0, g_maxPeak = 0;
static double g_marks[512];
static int g_nmarks = 0;
static wchar_t g_path[MAX_PATH], g_marksPath[MAX_PATH], g_dir[MAX_PATH], g_lastTime[32];
static int g_hasTake = 0;

static BOOL set_text_chg(HWND h, const wchar_t *t) {
    wchar_t cur[512]; int n = GetWindowTextW(h, cur, 512);
    if (n < 511 && !wcscmp(cur, t)) return TRUE;
    return (SetWindowTextW)(h, t);
}
#define SetWindowTextW set_text_chg
#define S(x) ((int)((x) * g_scale + 0.5))
#define F(x) ((int)((x) * g_fontScale + 0.5))
#define REGKEY L"Software\\TypeMyworDz\\Recorder"

/* ---- settings kept in the current user's registry ---- */
static void reg_set_dw(const wchar_t *n, DWORD v) {
    HKEY k;
    if (RegCreateKeyExW(HKEY_CURRENT_USER, REGKEY, 0, NULL, 0, KEY_SET_VALUE, NULL, &k, NULL) == ERROR_SUCCESS) {
        RegSetValueExW(k, n, 0, REG_DWORD, (const BYTE *)&v, 4); RegCloseKey(k);
    }
}
static void reg_set_sz(const wchar_t *n, const wchar_t *v) {
    HKEY k;
    if (RegCreateKeyExW(HKEY_CURRENT_USER, REGKEY, 0, NULL, 0, KEY_SET_VALUE, NULL, &k, NULL) == ERROR_SUCCESS) {
        RegSetValueExW(k, n, 0, REG_SZ, (const BYTE *)v, (DWORD)((wcslen(v) + 1) * sizeof(wchar_t))); RegCloseKey(k);
    }
}
static DWORD reg_get_dw(const wchar_t *n, DWORD def) {
    HKEY k; DWORD v = def, sz = 4, t = 0;
    if (RegOpenKeyExW(HKEY_CURRENT_USER, REGKEY, 0, KEY_QUERY_VALUE, &k) == ERROR_SUCCESS) {
        if (RegQueryValueExW(k, n, NULL, &t, (BYTE *)&v, &sz) != ERROR_SUCCESS || t != REG_DWORD) v = def;
        RegCloseKey(k);
    }
    return v;
}
static int reg_get_sz(const wchar_t *n, wchar_t *out, DWORD cch) {
    HKEY k; DWORD sz = cch * sizeof(wchar_t), t = 0; int ok = 0;
    if (RegOpenKeyExW(HKEY_CURRENT_USER, REGKEY, 0, KEY_QUERY_VALUE, &k) == ERROR_SUCCESS) {
        if (RegQueryValueExW(k, n, NULL, &t, (BYTE *)out, &sz) == ERROR_SUCCESS && t == REG_SZ && out[0]) ok = 1;
        RegCloseKey(k);
    }
    return ok;
}
static void save_recording_name(void) {
    wchar_t name[128];
    if (g_name) { GetWindowTextW(g_name, name, 128); reg_set_sz(L"RecordingName", name); }
}
static void save_settings(void) {
    save_recording_name();
    reg_set_dw(L"Format", (DWORD)SendMessageW(g_qual, CB_GETCURSEL, 0, 0));
    reg_set_dw(L"OnTop", SendMessageW(g_top, BM_GETCHECK, 0, 0) == BST_CHECKED);
    reg_set_dw(L"Replace", SendMessageW(g_over, BM_GETCHECK, 0, 0) == BST_CHECKED);
    reg_set_dw(L"SkipSilence", SendMessageW(g_skip, BM_GETCHECK, 0, 0) == BST_CHECKED);
    reg_set_dw(L"Zoom", (DWORD)g_zoom);
    reg_set_dw(L"HotkeyKey", g_hotkeyVk);
    reg_set_dw(L"HotkeyMods", g_hotkeyMods);
    reg_set_sz(L"Folder", g_dir);
    if (g_pVol) reg_set_dw(L"PlayVolume", (DWORD)SendMessageW(g_pVol, TBM_GETPOS, 0, 0));
    if (g_pSpd) reg_set_dw(L"PlaySpeed", (DWORD)SendMessageW(g_pSpd, TBM_GETPOS, 0, 0));
    reg_set_dw(L"RewindSeconds", (DWORD)g_rewind);
}

/* ---- WAV helpers ---- */
static void put32(unsigned char *p, DWORD v) { p[0] = v; p[1] = v >> 8; p[2] = v >> 16; p[3] = v >> 24; }
static void put16(unsigned char *p, WORD v) { p[0] = v; p[1] = v >> 8; }

static void write_header(HANDLE h, int rate, DWORD data) {
    unsigned char hd[44];
    memcpy(hd, "RIFF", 4); put32(hd + 4, 36 + data); memcpy(hd + 8, "WAVEfmt ", 8);
    put32(hd + 16, 16); put16(hd + 20, 1); put16(hd + 22, 1); put32(hd + 24, rate);
    put32(hd + 28, rate * 2); put16(hd + 32, 2); put16(hd + 34, 16);
    memcpy(hd + 36, "data", 4); put32(hd + 40, data);
    DWORD w; LARGE_INTEGER z; z.QuadPart = 0;
    SetFilePointerEx(h, z, NULL, FILE_BEGIN);
    WriteFile(h, hd, 44, &w, NULL);
    z.QuadPart = 0; SetFilePointerEx(h, z, NULL, FILE_END);
}

static int file_write(void *ctx, const void *d, int n) {
    DWORD w = 0; (void)ctx;
    if (g_file == INVALID_HANDLE_VALUE) return -1;
    return (WriteFile(g_file, d, n, &w, NULL) && (int)w == n) ? 0 : -1;
}

static double elapsed(void) { return (double)g_dataBytes / (g_rate * 2.0); }

static void fmt_time(double s, wchar_t *out, size_t n) {
    int t = (int)s, h = t / 3600, m = (t % 3600) / 60, x = t % 60;
    if (h) swprintf(out, n, L"%d:%02d:%02d", h, m, x); else swprintf(out, n, L"%02d:%02d", m, x);
}

static void fmt_hms(double s, wchar_t *out, size_t n) {
    int t = s < 0 ? 0 : (int)s;
    swprintf(out, n, L"%02d:%02d:%02d", t / 3600, (t % 3600) / 60, t % 60);
}

static void set_status(const wchar_t *t) { SetWindowTextW(g_status, t); }
static void set_msg(const wchar_t *t) { SetWindowTextW(g_msg, t); }

static int is_modifier_vk(UINT vk) {
    return vk == VK_SHIFT || vk == VK_CONTROL || vk == VK_MENU ||
        vk == VK_LSHIFT || vk == VK_RSHIFT || vk == VK_LCONTROL || vk == VK_RCONTROL ||
        vk == VK_LMENU || vk == VK_RMENU || vk == VK_LWIN || vk == VK_RWIN;
}

static int hotkey_is_valid(UINT vk, UINT mods) {
    const UINT allowed = MOD_ALT | MOD_CONTROL | MOD_SHIFT | MOD_WIN;
    if (!vk || vk > 0xFF || (mods & ~allowed) || is_modifier_vk(vk)) return 0;
    if (vk == VK_CAPITAL || vk == VK_NUMLOCK || vk == VK_SCROLL || vk == VK_F12) return 0;
    if (mods & MOD_WIN) return 0;
    if (vk == VK_TAB && mods != 0) return 0;
    if ((mods & MOD_ALT) && (vk == VK_TAB || vk == VK_F4 || vk == VK_ESCAPE || vk == VK_SPACE)) return 0;
    if ((mods & MOD_CONTROL) && (vk == VK_ESCAPE || vk == VK_TAB || vk == VK_F4)) return 0;
    if ((mods & MOD_CONTROL) && (mods & MOD_SHIFT) && vk == VK_ESCAPE) return 0;
    if ((mods & MOD_CONTROL) && (mods & MOD_ALT) && vk == VK_DELETE) return 0;
    return 1;
}

static UINT pressed_hotkey_mods(void) {
    UINT mods = 0;
    if (GetKeyState(VK_CONTROL) & 0x8000) mods |= MOD_CONTROL;
    if (GetKeyState(VK_SHIFT) & 0x8000) mods |= MOD_SHIFT;
    if (GetKeyState(VK_MENU) & 0x8000) mods |= MOD_ALT;
    if ((GetKeyState(VK_LWIN) & 0x8000) || (GetKeyState(VK_RWIN) & 0x8000)) mods |= MOD_WIN;
    return mods;
}

static void append_hotkey_text(wchar_t *out, size_t cap, const wchar_t *text) {
    size_t used = wcslen(out);
    if (used < cap - 1) wcsncat(out, text, cap - used - 1);
}

static void format_hotkey(UINT mods, UINT vk, wchar_t *out, size_t cap) {
    wchar_t key[64] = L"";
    UINT scan = MapVirtualKeyW(vk, MAPVK_VK_TO_VSC);
    LPARAM key_info = (LPARAM)scan << 16;
    if (vk == VK_INSERT || vk == VK_DELETE || vk == VK_HOME || vk == VK_END ||
        vk == VK_PRIOR || vk == VK_NEXT || vk == VK_LEFT || vk == VK_RIGHT ||
        vk == VK_UP || vk == VK_DOWN || vk == VK_NUMLOCK) key_info |= (LPARAM)1 << 24;
    out[0] = 0;
    if (mods & MOD_CONTROL) append_hotkey_text(out, cap, L"Ctrl+");
    if (mods & MOD_ALT) append_hotkey_text(out, cap, L"Alt+");
    if (mods & MOD_SHIFT) append_hotkey_text(out, cap, L"Shift+");
    if (mods & MOD_WIN) append_hotkey_text(out, cap, L"Win+");
    if (!GetKeyNameTextW((LONG)key_info, key, 64)) swprintf(key, 64, L"Key %u", vk);
    append_hotkey_text(out, cap, key);
}

static int register_global_hotkey(UINT mods, UINT vk) {
    return RegisterHotKey(g_wnd, HOTKEY_REC, mods | MOD_NOREPEAT, vk) != 0;
}

static void update_hotkey_controls(void) {
    wchar_t label[128], foot[256];
    format_hotkey(g_hotkeyMods, g_hotkeyVk, label, 128);
    if (g_hotkeyValue) SetWindowTextW(g_hotkeyValue, g_hotkeyCapturing ? L"Press a key; Esc cancels" : label);
    if (g_btn[7]) { SetWindowTextW(g_btn[7], g_hotkeyCapturing ? L"Cancel" : L"Change"); InvalidateRect(g_btn[7], NULL, TRUE); }
    if (g_btn[8]) InvalidateRect(g_btn[8], NULL, TRUE);
    if (g_foot) {
        swprintf(foot, 256, L"Version %ls  |  %ls works from any window.", RECORDER_VERSION, label);
        SetWindowTextW(g_foot, foot);
    }
}

static void update_ready_status(void) {
    wchar_t label[128], msg[200];
    if (g_state != S_IDLE) return;
    if (!g_hotkeyOk) { set_status(L"Global shortcut unavailable; open Settings to choose another"); return; }
    format_hotkey(g_hotkeyMods, g_hotkeyVk, label, 128);
    swprintf(msg, 200, L"Ready to record  (%ls)", label);
    set_status(msg);
}

static void restore_current_hotkey(void) {
    if (g_hotkeyOk) UnregisterHotKey(g_wnd, HOTKEY_REC);
    g_hotkeyOk = register_global_hotkey(g_hotkeyMods, g_hotkeyVk);
    sc_register_global_hotkeys();
    update_hotkey_controls();
    update_ready_status();
}

static int apply_hotkey(UINT vk, UINT mods) {
    wchar_t label[128], prompt[320];
    int had_old = g_hotkeyOk;
    UINT old_vk = g_hotkeyVk, old_mods = g_hotkeyMods;
    if (!hotkey_is_valid(vk, mods)) {
        if (!had_old) restore_current_hotkey();
        if (g_state == S_IDLE) set_status(L"Windows reserves that shortcut. Choose another.");
        update_hotkey_controls();
        return 0;
    }
    if (mods == 0) {
        format_hotkey(mods, vk, label, 128);
        swprintf(prompt, 320, L"%ls has no modifier key. While the recorder is open, Windows will capture it across apps. Tab may no longer move focus normally.\n\nUse this single-key shortcut?", label);
        if (MessageBoxW(g_wnd, prompt, L"Confirm global shortcut", MB_YESNO | MB_ICONWARNING | MB_DEFBUTTON2) != IDYES) {
            restore_current_hotkey();
            if (g_state == S_IDLE) set_status(L"Shortcut unchanged.");
            return 0;
        }
    }

    if (had_old) UnregisterHotKey(g_wnd, HOTKEY_REC);
    sc_unregister_global_hotkeys();
    g_hotkeyOk = 0;
    if (register_global_hotkey(mods, vk)) {
        g_hotkeyVk = vk; g_hotkeyMods = mods; g_hotkeyOk = 1;
        reg_set_dw(L"HotkeyKey", g_hotkeyVk);
        reg_set_dw(L"HotkeyMods", g_hotkeyMods);
        sc_register_global_hotkeys();
        update_hotkey_controls();
        update_ready_status();
        return 1;
    }

    g_hotkeyOk = register_global_hotkey(old_mods, old_vk);
    sc_register_global_hotkeys();
    g_hotkeyVk = old_vk; g_hotkeyMods = old_mods;
    update_hotkey_controls();
    if (g_state == S_IDLE) set_status(g_hotkeyOk ? L"Windows could not reserve that shortcut; the previous one remains." : L"Neither shortcut is available. Open Settings or use Record.");
    return 0;
}

static void cancel_hotkey_capture(void) {
    if (!g_hotkeyCapturing) return;
    g_hotkeyCapturing = 0;
    restore_current_hotkey();
    if (g_state == S_IDLE) set_status(L"Shortcut change cancelled.");
}

static void finish_hotkey_capture(UINT vk, UINT mods) {
    g_hotkeyCapturing = 0;
    if (!hotkey_is_valid(vk, mods)) {
        restore_current_hotkey();
        if (g_state == S_IDLE) set_status(L"Windows reserves that shortcut. Choose another.");
        return;
    }
    apply_hotkey(vk, mods);
}

static void begin_hotkey_capture(void) {
    if (g_hotkeyCapturing) { cancel_hotkey_capture(); return; }
    if (g_hotkeyOk) UnregisterHotKey(g_wnd, HOTKEY_REC);
    sc_unregister_global_hotkeys();
    g_hotkeyOk = 0;
    g_hotkeyCapturing = 1;
    update_hotkey_controls();
    set_status(L"Press your record/stop shortcut now. Press Esc to cancel.");
    SetFocus(g_wnd);
}


/* ---- playback shortcuts and controls ---- */
static int sc_valid(int idx, UINT vk, UINT mods) {
    int i;
    if (!vk || vk > 0xFF || is_modifier_vk(vk) || (mods & MOD_WIN)) return 0;
    if (vk == VK_ESCAPE || vk == VK_TAB || vk == VK_RETURN) return 0;
    if (mods == 0 && !(vk >= VK_F1 && vk <= VK_F11)) return 0;
    if ((mods & MOD_ALT) && (vk == VK_F4 || vk == VK_SPACE)) return 0;
    if (vk == g_hotkeyVk && mods == g_hotkeyMods) return 0;
    for (i = 0; i < NSC; i++) if (i != idx && g_scVk[i] == vk && g_scMods[i] == mods) return 0;
    return 1;
}

static void sc_unregister_global_hotkeys(void) {
    int i;
    if (!g_wnd) return;
    for (i = 0; i < NSC; i++) {
        UnregisterHotKey(g_wnd, HOTKEY_PLAY + i);
        g_scHotkeyOk[i] = 0;
    }
}

static int sc_register_global_hotkeys(void) {
    int i, all_ok = 1;
    if (!g_wnd || g_scCap >= 0 || g_hotkeyCapturing) return 0;
    if (!g_plOk) return 1;
    if (g_collapsed && g_panelOpen) return 1;
    sc_unregister_global_hotkeys();
    for (i = 0; i < NSC; i++) {
        if (g_scVk[i] == g_hotkeyVk && g_scMods[i] == g_hotkeyMods) {
            all_ok = 0;
            continue;
        }
        g_scHotkeyOk[i] = RegisterHotKey(g_wnd, HOTKEY_PLAY + i,
            g_scMods[i] | MOD_NOREPEAT, g_scVk[i]) != 0;
        if (!g_scHotkeyOk[i]) all_ok = 0;
    }
    return all_ok;
}

static void sc_update_controls(void) {
    int i; wchar_t t[128];
    for (i = 0; i < NSC; i++) {
        if (!g_scVal[i]) continue;
        if (g_scCap == i) wcscpy(t, L"Press a key; Esc cancels"); else format_hotkey(g_scMods[i], g_scVk[i], t, 128);
        SetWindowTextW(g_scVal[i], t);
        SetWindowTextW(g_scBtn[i], g_scCap == i ? L"Cancel" : L"Change");
        InvalidateRect(g_scBtn[i], NULL, TRUE); InvalidateRect(g_scDef[i], NULL, TRUE);
    }
}

static void sc_load(void) {
    int i;
    for (i = 0; i < NSC; i++) {
        UINT vk = reg_get_dw(SC_DEF[i].key, SC_DEF[i].vk), mods = reg_get_dw(SC_MODKEY[i], SC_DEF[i].mods);
        g_scVk[i] = SC_DEF[i].vk; g_scMods[i] = SC_DEF[i].mods;
        if (vk && vk <= 0xFF && !is_modifier_vk(vk) && !(mods & ~(UINT)(MOD_ALT | MOD_CONTROL | MOD_SHIFT))) { g_scVk[i] = vk; g_scMods[i] = mods; }
    }
}

static void sc_cancel(void) {
    if (g_scCap < 0) return;
    g_scCap = -1; sc_update_controls();
    if (!sc_register_global_hotkeys()) set_status(L"A playback shortcut is unavailable; another app may be using it. Choose a different key in Settings.");
    else if (g_state == S_IDLE) update_ready_status();
}

static void sc_begin(int idx) {
    if (g_hotkeyCapturing) cancel_hotkey_capture();
    if (g_scCap == idx) { sc_cancel(); return; }
    sc_unregister_global_hotkeys();
    g_scCap = idx; sc_update_controls();
    set_status(L"Press the new shortcut now. Press Esc to cancel.");
    SetFocus(g_wnd);
}

static void sc_finish(UINT vk, UINT mods) {
    int idx = g_scCap;
    if (idx < 0) return;
    if (!sc_valid(idx, vk, mods)) {
        set_status(L"That shortcut is not available. Use Ctrl, Alt or Shift with a key.");
        return;
    }
    g_scVk[idx] = vk; g_scMods[idx] = mods;
    reg_set_dw(SC_DEF[idx].key, vk); reg_set_dw(SC_MODKEY[idx], mods);
    g_scCap = -1; sc_update_controls();
    if (!sc_register_global_hotkeys()) set_status(L"A playback shortcut is unavailable; another app may be using it. Choose a different key in Settings.");
    else if (g_state == S_IDLE) set_status(L"Playback shortcut works from any window, even when minimized.");
}

static void sc_default(int idx) {
    int i;
    if (g_scCap >= 0) sc_cancel();
    for (i = 0; i < NSC; i++) if (i != idx && g_scVk[i] == SC_DEF[idx].vk && g_scMods[i] == SC_DEF[idx].mods) {
        set_status(L"That default is used by another shortcut. Change that one first.");
        return;
    }
    g_scVk[idx] = SC_DEF[idx].vk; g_scMods[idx] = SC_DEF[idx].mods;
    reg_set_dw(SC_DEF[idx].key, g_scVk[idx]); reg_set_dw(SC_MODKEY[idx], g_scMods[idx]);
    sc_update_controls();
    if (!sc_register_global_hotkeys()) set_status(L"A playback shortcut is unavailable; another app may be using it. Choose a different key in Settings.");
    else if (g_state == S_IDLE) set_status(L"Playback shortcut works from any window, even when minimized.");
}

static void back_label(void) {
    wchar_t t[32]; swprintf(t, 32, L"Back %ds", g_rewind);
    if (g_pBtn[1]) { SetWindowTextW(g_pBtn[1], t); InvalidateRect(g_pBtn[1], NULL, TRUE); }
}

static void play_update_labels(void) {
    wchar_t t[64]; int v = (int)SendMessageW(g_pVol, TBM_GETPOS, 0, 0), sp = (int)SendMessageW(g_pSpd, TBM_GETPOS, 0, 0);
    swprintf(t, 64, L"Volume %d%%", v); SetWindowTextW(g_pVolTxt, t);
    swprintf(t, 64, L"Speed %d%%", sp * 5); SetWindowTextW(g_pSpdTxt, t);
}

static void show_pos(double pos, double dur) {
    wchar_t a[32], b[32], r[32], t[120];
    fmt_hms(pos, a, 32); fmt_hms(dur, b, 32); fmt_hms(dur - pos, r, 32);
    if (wcscmp(a, g_lastTime)) { wcscpy(g_lastTime, a); SetWindowTextW(g_timer, a); }
    swprintf(t, 120, L"Total %ls   \u00B7   Remaining %ls", b, r);
    SetWindowTextW(g_pTime, t);
}

static void play_tick(void) {
    wchar_t a[32]; double pos, dur; int playing;
    if (!g_plOk) return;
    pos = pl_pos(); dur = pl_dur(); playing = pl_playing();
    if (!g_seekDrag) {
        show_pos(pos, dur);
        SendMessageW(g_pSeek, TBM_SETPOS, TRUE, dur > 0 ? (LPARAM)(pos / dur * 1000.0 + 0.5) : 0);
    }
    GetWindowTextW(g_pBtn[0], a, 32);
    if (wcscmp(a, playing ? L"Pause" : L"Play")) { SetWindowTextW(g_pBtn[0], playing ? L"Pause" : L"Play"); InvalidateRect(g_pBtn[0], NULL, TRUE); }
}

static void play_toggle(void) {
    if (!g_plOk) return;
    if (pl_playing()) pl_pause(); else pl_play();
    play_tick();
}
static void play_back(void) { if (g_plOk) { pl_seek(pl_pos() - g_rewind); play_tick(); } }
static void play_forward(void) { if (g_plOk) { pl_seek(pl_pos() + 5.0); play_tick(); } }
static void play_start(void) { if (g_plOk) { pl_seek(0); play_tick(); } }
static void play_stop(void) { if (g_plOk) { pl_pause(); pl_seek(0); play_tick(); } }

static void play_unload(void) {
    KillTimer(g_wnd, TIMER_PLAY);
    sc_unregister_global_hotkeys();
    pl_unload(); g_plOk = 0; g_curAudio[0] = 0;
}

static int play_load(const wchar_t *path, int isFile) {
    const wchar_t *base; wchar_t t[400];
    play_unload();
    if (pl_load(path) != 0) return -1;
    g_plOk = 1; g_plIsFile = isFile;
    wcsncpy(g_curAudio, path, MAX_PATH - 1); g_curAudio[MAX_PATH - 1] = 0;
    if (wp_started()) wp_send_audio(g_curAudio);
    if (!sc_register_global_hotkeys()) set_status(L"A playback shortcut is unavailable; another app may be using it. Choose a different key in Settings.");
    pl_set_volume(SendMessageW(g_pVol, TBM_GETPOS, 0, 0) / 100.0);
    pl_set_speed(SendMessageW(g_pSpd, TBM_GETPOS, 0, 0) * 0.05);
    SetWindowTextW(g_pBtn[0], L"Play");
    SendMessageW(g_pSeek, TBM_SETPOS, TRUE, 0);
    base = wcsrchr(path, L'\\'); base = base ? base + 1 : path;
    swprintf(t, 400, L"%ls", base);
    SetWindowTextW(g_pName, t);
    play_update_labels();
    SetTimer(g_wnd, TIMER_PLAY, 100, NULL);
    play_tick();
    return 0;
}
static void play_open(void) { play_load(g_path, 0); }

static int play_load_external(const wchar_t *f) {
    if (play_load(f, 1) != 0) {
        play_unload();
        if (g_hasTake) play_open();
        MessageBoxW(g_wnd, L"TypeScribe could not read this file. It plays MP3, WAV, M4A and most other audio that Windows can decode. If the file is damaged or protected, convert it to MP3 with the free tool linked below and try again.", APP_NAME, MB_OK | MB_ICONINFORMATION);
        update_buttons();
        return -1;
    }
    update_buttons();
    return 0;
}

static void play_choose_file(void) {
    OPENFILENAMEW ofn; wchar_t f[MAX_PATH] = L"";
    ZeroMemory(&ofn, sizeof ofn);
    ofn.lStructSize = sizeof ofn; ofn.hwndOwner = g_wnd;
    ofn.lpstrFilter = L"Audio files\0*.mp3;*.wav;*.m4a;*.aac;*.wma;*.mp4\0All files\0*.*\0";
    ofn.lpstrFile = f; ofn.nMaxFile = MAX_PATH;
    ofn.lpstrTitle = L"Choose an audio file to play";
    ofn.Flags = OFN_FILEMUSTEXIST | OFN_PATHMUSTEXIST | OFN_HIDEREADONLY;
    if (!GetOpenFileNameW(&ofn)) return;
    play_load_external(f);
}
static void play_last_recording(void) { if (g_hasTake) { play_open(); update_buttons(); } }

/* ---- layout: controls are placed from the top so the window grows and
   shrinks with what is showing ---- */
static int g_ready = 0, g_inLayout = 0;
static void place(HWND c, int x, int y, int w, int h, int show) {
    if (g_hideAll || (g_mini && y >= g_miniCut)) show = 0;
    SetWindowPos(c, NULL, S(x + g_ox), S(y), S(w), S(h), SWP_NOZORDER | SWP_NOACTIVATE | (show ? SWP_SHOWWINDOW : SWP_HIDEWINDOW));
}

static int playback_mode(void) { return g_state == S_IDLE && g_plOk; }

static void panel_fail(const wchar_t *why) {
    wchar_t m[600];
    g_panelOpen = 0; g_collapsed = 0; layout();
    swprintf(m, 600, L"%ls\r\n\r\nTypeScribe needs the free Microsoft Edge WebView2 Runtime for its built-in panel (Windows 11 and up-to-date Windows 10 already have it). For now TypeMyworDz will open in your normal browser instead.", why);
    MessageBoxW(g_wnd, m, APP_NAME, MB_OK | MB_ICONINFORMATION);
    ShellExecuteW(NULL, L"open", L"https://typemywordz.ai/?utm_source=typescribe", NULL, NULL, SW_SHOWNORMAL);
}

/* The left column is 380 wide. With no side panel and a wider window, it is
   centred; with the panel open it hugs the left edge. */
static int ox_for(int cwLogical) {
    if (g_mini || g_panelOpen) return 0;
    return cwLogical > LW ? (cwLogical - LW) / 2 : 0;
}

/* Strip (collapse handle) and the embedded page follow the window size. */
static void place_panel(void) {
    RECT cr; int stripX, webX, W, H;
    GetClientRect(g_wnd, &cr); W = cr.right; H = cr.bottom;
    if (g_panelOpen && !g_mini) {
        stripX = g_collapsed ? 0 : S(LW);
        webX = stripX + S(STRIP_W);
        SetWindowPos(g_strip, NULL, stripX, 0, S(STRIP_W), H, SWP_NOZORDER | SWP_NOACTIVATE | SWP_SHOWWINDOW);
        g_webRc.left = webX; g_webRc.top = 0; g_webRc.right = W > webX + 40 ? W : webX + 40; g_webRc.bottom = H > 40 ? H : 40;
        wp_bounds(g_webRc.left, 0, g_webRc.right - g_webRc.left, g_webRc.bottom);
        InvalidateRect(g_strip, NULL, FALSE);
    } else {
        SetWindowPos(g_strip, NULL, 0, 0, 1, 1, SWP_NOZORDER | SWP_NOACTIVATE | SWP_HIDEWINDOW);
    }
}

static void layout(void) {
    int y, y0, open = g_showSet, tk = (g_state == S_IDLE && g_hasTake), pm = playback_mode(), k, ch, minW, targetW;
    RECT cr; int curW;
    if (!g_wnd || g_inLayout) return;
    g_inLayout = 1;
    GetClientRect(g_wnd, &cr); curW = (int)(cr.right / g_scale + 0.5);
    g_hideAll = (g_panelOpen && g_collapsed && !g_mini);
    minW = g_mini ? LW : g_panelOpen ? (g_collapsed ? STRIP_W + WEB_MIN : LW + STRIP_W + WEB_MIN) : LW;
    targetW = g_forceW ? g_forceW : (curW < minW ? minW : curW);
    if (g_mini) targetW = LW;
    if (IsZoomed(g_wnd) || g_noResize) targetW = curW;
    g_ox = ox_for(targetW);
    g_miniCut = 100000;
    if (pm) {
        place(g_timer, 0, 58, 380, 88, 1);
        place(g_pName, 24, 148, 332, 18, 1);
        place(g_pTime, 24, 168, 332, 18, 1);
        place(g_pSeek, 22, 190, 336, 28, 1);
        place(g_pVolTxt, 30, 226, 150, 16, 1); place(g_pSpdTxt, 200, 226, 150, 16, 1);
        place(g_pVol, 24, 242, 160, 26, 1); place(g_pSpd, 196, 242, 160, 26, 1);
        place(g_pBtn[2], 22, 284, 62, 74, 1);
        place(g_pBtn[1], 90, 284, 62, 74, 1);
        place(g_pBtn[0], 158, 274, 80, 90, 1);
        place(g_pBtn[3], 244, 284, 62, 74, 1);
        place(g_pBtn[4], 312, 284, 56, 74, 1);
        place(g_status, 0, 372, 380, 20, 1);
        y0 = 400;
        if (g_mini) g_miniCut = 400;
    } else {
        place(g_timer, 0, 58, 380, 88, 1);
        place(g_status, 0, 146, 380, 20, 1);
        g_waveY = 172;
        for (k = 0; k < 5; k++) place(g_pBtn[k], 0, 0, 1, 1, 0);
        place(g_pName, 0, 0, 1, 1, 0); place(g_pTime, 0, 0, 1, 1, 0); place(g_pSeek, 0, 0, 1, 1, 0);
        place(g_pVolTxt, 0, 0, 1, 1, 0); place(g_pVol, 0, 0, 1, 1, 0); place(g_pSpdTxt, 0, 0, 1, 1, 0); place(g_pSpd, 0, 0, 1, 1, 0);
        y0 = 238;
        if (g_mini) g_miniCut = y0 + 40;
    }
    place(g_btnMini, 262, 13, 102, 26, 1);
    place(g_btn[0], 30, y0, 77, 36, 1);
    place(g_btn[1], 111, y0, 77, 36, 1);
    place(g_btn[2], 192, y0, 77, 36, 1);
    place(g_btn[3], 273, y0, 77, 36, 1);
    place(g_lblName, 30, y0 + 45, 66, 24, 1);
    place(g_name, 100, y0 + 43, 250, 26, 1);
    place(g_btnSet, 30, y0 + 77, 150, 28, 1);
    y = y0 + 115;
    if (open) {
        place(g_over, 30, y, 320, 22, 1); y += 27;
        place(g_skip, 30, y, 320, 22, 1); y += 27;
        place(g_top, 30, y, 320, 22, 1); y += 28;
        place(g_lblHotkey, 30, y, 320, 18, 1); y += 19;
        place(g_hotkeyValue, 30, y + 2, 145, 24, 1);
        place(g_btn[7], 180, y, 75, 28, 1);
        place(g_btn[8], 265, y, 85, 28, 1); y += 31;
        place(g_hotkeyNote, 30, y, 320, 52, 1); y += 55;
        place(g_lblPlay, 30, y, 320, 18, 1); y += 20;
        for (k = 0; k < NSC; k++) {
            place(g_scLbl[k], 30, y, 320, 18, 1); y += 19;
            place(g_scVal[k], 30, y + 2, 145, 24, 1);
            place(g_scBtn[k], 180, y, 75, 28, 1);
            place(g_scDef[k], 265, y, 85, 28, 1); y += 31;
        }
        place(g_lblBack, 30, y + 4, 150, 20, 1);
        place(g_backCombo, 184, y, 166, 28, 1); y += 36;
        place(g_lblQ, 30, y + 4, 68, 20, 1);
        place(g_qual, 100, y, 250, 28, 1); y += 34;
        place(g_lblSize, 30, y + 4, 88, 20, 1);
        place(g_size, 124, y, 226, 28, 1); y += 34;
        place(g_lblDir, 30, y, 320, 18, 1); y += 20;
        place(g_dirTxt, 30, y, 320, 24, 1); y += 27;
        place(g_btnDir, 30, y, 170, 28, 1); y += 34;
        place(g_btn[5], 30, y, 154, 28, tk); place(g_btn[6], 196, y, 154, 28, tk); if (tk) y += 34;
        place(g_foot, 30, y, 320, 30, 1); y += 34;
    } else {
        place(g_over, 0, 0, 1, 1, 0); place(g_skip, 0, 0, 1, 1, 0); place(g_top, 0, 0, 1, 1, 0);
        place(g_lblHotkey, 0, 0, 1, 1, 0); place(g_hotkeyValue, 0, 0, 1, 1, 0); place(g_hotkeyNote, 0, 0, 1, 1, 0);
        place(g_lblPlay, 0, 0, 1, 1, 0); place(g_lblBack, 0, 0, 1, 1, 0); place(g_backCombo, 0, 0, 1, 1, 0);
        for (k = 0; k < NSC; k++) { place(g_scLbl[k], 0, 0, 1, 1, 0); place(g_scVal[k], 0, 0, 1, 1, 0); place(g_scBtn[k], 0, 0, 1, 1, 0); place(g_scDef[k], 0, 0, 1, 1, 0); }
        place(g_btn[7], 0, 0, 1, 1, 0); place(g_btn[8], 0, 0, 1, 1, 0);
        place(g_lblQ, 0, 0, 1, 1, 0); place(g_qual, 0, 0, 1, 1, 0);
        place(g_lblSize, 0, 0, 1, 1, 0); place(g_size, 0, 0, 1, 1, 0);
        place(g_lblDir, 0, 0, 1, 1, 0); place(g_dirTxt, 0, 0, 1, 1, 0); place(g_btnDir, 0, 0, 1, 1, 0);
        place(g_btn[5], 0, 0, 1, 1, 0); place(g_btn[6], 0, 0, 1, 1, 0); place(g_foot, 0, 0, 1, 1, 0);
    }
    place(g_msg, 30, y, 320, 38, 1); y += 42;
    if (g_state == S_IDLE) {
        if (g_hasTake) { place(g_pOpen, 30, y, 154, 30, 1); place(g_pLast, 196, y, 154, 30, 1); }
        else { place(g_pOpen, 30, y, 320, 30, 1); place(g_pLast, 0, 0, 1, 1, 0); }
        y += 36;
    } else { place(g_pOpen, 0, 0, 1, 1, 0); place(g_pLast, 0, 0, 1, 1, 0); }
    place(g_btn[4], 30, y, 320, 82, 1); y += 90;
    if (g_panelOpen && y < 680) y = 680;
    ch = g_mini ? (pm ? 400 : y0 + 36 + 16) : y;
    g_needH = ch;
    if (!g_noResize && !IsZoomed(g_wnd)) {
        RECT r = { 0, 0, S(targetW), S(g_mini || g_userH <= ch ? ch : g_userH) };
        AdjustWindowRectEx(&r, (DWORD)GetWindowLongPtrW(g_wnd, GWL_STYLE), FALSE, 0);
        SetWindowPos(g_wnd, NULL, 0, 0, r.right - r.left, r.bottom - r.top, SWP_NOMOVE | SWP_NOZORDER | SWP_NOACTIVATE | SWP_FRAMECHANGED);
        {   /* keep the window on the screen */
            RECT wr; MONITORINFO mi; HMONITOR mon = MonitorFromWindow(g_wnd, MONITOR_DEFAULTTONEAREST);
            mi.cbSize = sizeof mi; GetWindowRect(g_wnd, &wr);
            if (GetMonitorInfoW(mon, &mi)) {
                int nx = wr.left, ny = wr.top;
                if (wr.right > mi.rcWork.right) nx = mi.rcWork.right - (wr.right - wr.left);
                if (wr.bottom > mi.rcWork.bottom) ny = mi.rcWork.bottom - (wr.bottom - wr.top);
                if (nx < mi.rcWork.left) nx = mi.rcWork.left;
                if (ny < mi.rcWork.top) ny = mi.rcWork.top;
                if (nx != wr.left || ny != wr.top) SetWindowPos(g_wnd, NULL, nx, ny, 0, 0, SWP_NOSIZE | SWP_NOZORDER | SWP_NOACTIVATE);
            }
        }
    }
    place_panel();
    InvalidateRect(g_timer, NULL, FALSE);
    InvalidateRect(g_wnd, NULL, FALSE);
    g_inLayout = 0;
}

static void set_collapsed(int on) {
    if (!g_panelOpen || on == g_collapsed) return;
    g_collapsed = on;
    if (on) { if (g_plOk && pl_playing()) pl_pause(); sc_unregister_global_hotkeys(); }
    else if (g_plOk) sc_register_global_hotkeys();
    g_noResize = 1; layout(); g_noResize = 0;
    SetFocus(g_wnd);
}

static void panel_toggle(void) {
    RECT cr; int curW;
    if (g_panelOpen) {
        g_panelOpen = 0; g_collapsed = 0; wp_visible(0);
        if (g_plOk) sc_register_global_hotkeys();
        g_forceW = LW; layout(); g_forceW = 0; return;
    }
    GetClientRect(g_wnd, &cr); curW = (int)(cr.right / g_scale + 0.5);
    g_panelOpen = 1; g_collapsed = 0;
    g_forceW = curW >= LW + STRIP_W + PANEL_W ? 0 : LW + STRIP_W + PANEL_W;
    layout(); g_forceW = 0;
    if (!wp_started()) {
        if (!wp_start(g_wnd, g_webRc.left, 0, g_webRc.right - g_webRc.left, g_webRc.bottom, L"https://typemywordz.ai/?app=typescribe", panel_fail)) return;
    } else wp_visible(1);
    if (g_plOk && g_curAudio[0]) wp_send_audio(g_curAudio);
}

/* TypeScribe asked for by the page: hand over whatever audio is loaded now. */
static void panel_request_audio(void) {
    if (g_plOk && g_curAudio[0]) wp_send_audio(g_curAudio);
}

static void mini_save_pos(void) {
    RECT wr;
    if (!g_mini || !GetWindowRect(g_wnd, &wr)) return;
    reg_set_dw(L"MiniX", (DWORD)wr.left); reg_set_dw(L"MiniY", (DWORD)wr.top);
}

static void mini_enter(void) {
    WINDOWPLACEMENT wpm; RECT wr; MONITORINFO mi; HMONITOR mon; int x, y, w, h;
    if (g_mini) return;
    if (g_hotkeyCapturing) cancel_hotkey_capture();
    if (g_scCap >= 0) sc_cancel();
    wpm.length = sizeof wpm; GetWindowPlacement(g_wnd, &wpm); g_normRc = wpm.rcNormalPosition; g_normValid = 1;
    if (IsZoomed(g_wnd)) ShowWindow(g_wnd, SW_RESTORE);
    /* the transcript is cleared: the panel is reloaded blank and hidden */
    if (wp_started()) { wp_clear(); wp_visible(0); }
    g_panelOpen = 0; g_collapsed = 0; g_showSet = 0;
    if (g_plOk) sc_register_global_hotkeys();
    g_mini = 1;
    SetWindowLongPtrW(g_wnd, GWL_STYLE, (LONG_PTR)(MINISTYLE | WS_VISIBLE));
    g_forceW = LW; layout(); g_forceW = 0;
    GetWindowRect(g_wnd, &wr); w = wr.right - wr.left; h = wr.bottom - wr.top;
    {   DWORD sx = reg_get_dw(L"MiniX", 0x7FFFFFFF), sy = reg_get_dw(L"MiniY", 0x7FFFFFFF);
        POINT pt; pt.x = wr.left; pt.y = wr.top;
        if (sx != 0x7FFFFFFF && sy != 0x7FFFFFFF) { pt.x = (int)sx; pt.y = (int)sy; }
        mon = MonitorFromPoint(pt, MONITOR_DEFAULTTOPRIMARY);
        mi.cbSize = sizeof mi;
        if (!GetMonitorInfoW(mon, &mi)) { mi.rcWork.left = 0; mi.rcWork.top = 0; mi.rcWork.right = 1280; mi.rcWork.bottom = 720; }
        if (sx == 0x7FFFFFFF || sy == 0x7FFFFFFF) { x = mi.rcWork.left + 12; y = mi.rcWork.bottom - h - 12; }   /* docked bottom left */
        else { x = (int)sx; y = (int)sy; }
        if (x + w > mi.rcWork.right) x = mi.rcWork.right - w;
        if (y + h > mi.rcWork.bottom) y = mi.rcWork.bottom - h;
        if (x < mi.rcWork.left) x = mi.rcWork.left;
        if (y < mi.rcWork.top) y = mi.rcWork.top; }
    SetWindowPos(g_wnd, NULL, x, y, 0, 0, SWP_NOSIZE | SWP_NOZORDER | SWP_NOACTIVATE);
    InvalidateRect(g_btnMini, NULL, FALSE);
}

static void mini_exit(void) {
    if (!g_mini) return;
    mini_save_pos();
    g_mini = 0;
    SetWindowLongPtrW(g_wnd, GWL_STYLE, (LONG_PTR)(WINSTYLE | WS_VISIBLE));
    g_forceW = LW; layout(); g_forceW = 0;
    if (g_normValid) {
        RECT wr; MONITORINFO mi; HMONITOR mon = MonitorFromRect(&g_normRc, MONITOR_DEFAULTTONEAREST); int x = g_normRc.left, y = g_normRc.top, w, h;
        GetWindowRect(g_wnd, &wr); w = wr.right - wr.left; h = wr.bottom - wr.top;
        mi.cbSize = sizeof mi;
        if (GetMonitorInfoW(mon, &mi)) {
            if (x + w > mi.rcWork.right) x = mi.rcWork.right - w;
            if (y + h > mi.rcWork.bottom) y = mi.rcWork.bottom - h;
            if (x < mi.rcWork.left) x = mi.rcWork.left;
            if (y < mi.rcWork.top) y = mi.rcWork.top;
        }
        SetWindowPos(g_wnd, NULL, x, y, 0, 0, SWP_NOSIZE | SWP_NOZORDER | SWP_NOACTIVATE);
    }
    InvalidateRect(g_btnMini, NULL, FALSE);
}

static void update_buttons(void) {
    int rec = g_state == S_REC, pau = g_state == S_PAUSED, idle = g_state == S_IDLE;
    EnableWindow(g_btn[0], idle);
    EnableWindow(g_btn[1], rec || pau);
    EnableWindow(g_btn[2], rec || pau);
    EnableWindow(g_btn[3], rec);
    EnableWindow(g_qual, idle);
    EnableWindow(g_name, idle);
    EnableWindow(g_over, idle);
    EnableWindow(g_btnDir, idle);
    SetWindowTextW(g_btn[1], pau ? L"Resume" : L"Pause");
    SetWindowTextW(g_btnSet, g_showSet ? L"Settings  \u25B4" : L"Settings  \u25BE");
    layout();
}

static void process_hdr(WAVEHDR *h) {
    if (h->dwUser || !(h->dwFlags & WHDR_DONE) || h->dwBytesRecorded == 0) { return; }
    h->dwUser = 1;
    short *s = (short *)h->lpData; int n = h->dwBytesRecorded / 2, pk = 0, i;
    for (i = 0; i < n; i++) { int v = s[i] < 0 ? -s[i] : s[i]; if (v > pk) pk = v; }
    g_peak = pk; if (pk > g_maxPeak) g_maxPeak = pk;
    g_totalBufs++;
    if (pk >= 32000) { g_clipBufs++; g_clipHold = 14; }
    /* Peak limiter: turns the volume down for a moment when the signal gets
       close to the top, instead of letting it clip and distort. */
    for (i = 0; i < n; i++) {
        float a = (float)(s[i] < 0 ? -s[i] : s[i]), need = a > 27000.0f ? 27000.0f / a : 1.0f, v;
        if (need < g_lim) g_lim += (need - g_lim) * 0.35f; else g_lim += (1.0f - g_lim) * 0.0004f;
        v = s[i] * g_lim;
        s[i] = (short)(v > 32767.f ? 32767 : v < -32768.f ? -32768 : v);
    }
    int ms = (int)((double)n * 1000.0 / g_rate), keep = 1;
    if (SendMessageW(g_skip, BM_GETCHECK, 0, 0) == BST_CHECKED) {
        if (pk < 450) { g_silentMs += ms; if (g_silentMs > 1500) keep = 0; } else g_silentMs = 0;
    } else g_silentMs = 0;
    if (keep && g_file != INVALID_HANDLE_VALUE) {
        if (g_isMp3) {
            mp3_feed(s, n, file_write, NULL);
        } else {
            DWORD w; WriteFile(g_file, h->lpData, h->dwBytesRecorded, &w, NULL);
            if (++g_bufCount % 30 == 0) write_header(g_file, g_rate, g_dataBytes + h->dwBytesRecorded);
        }
        g_dataBytes += h->dwBytesRecorded;
    }
}

static void close_input(void) {
    int i;
    if (g_in) {
        waveInStop(g_in);
        for (i = 0; i < NBUF; i++) process_hdr(&g_hdr[i]);
        waveInReset(g_in);
        for (i = 0; i < NBUF; i++) { waveInUnprepareHeader(g_in, &g_hdr[i], sizeof(WAVEHDR)); }
        waveInClose(g_in); g_in = NULL;
    }
    for (i = 0; i < NBUF; i++) { free(g_buf[i]); g_buf[i] = NULL; }
}

/* Builds the file name from the name box. Empty means date and time. An
   existing name gets (2), (3) ... unless "replace" is ticked. */
static void make_paths(wchar_t *base, size_t cap) {
    wchar_t name[200]; SYSTEMTIME t; size_t n, i, j = 0;
    const wchar_t *ext = g_isMp3 ? L"mp3" : L"wav";
    GetWindowTextW(g_name, name, 200);
    wchar_t clean[200];
    for (i = 0; name[i] && j < 150; i++) {
        wchar_t c = name[i];
        if (c < 32 || wcschr(L"\\/:*?\"<>|", c)) c = L'-';
        clean[j++] = c;
    }
    clean[j] = 0;
    for (;;) {
        n = wcslen(clean);
        if (n && (clean[n - 1] == L' ' || clean[n - 1] == L'.')) clean[n - 1] = 0; else break;
    }
    n = wcslen(clean);
    if (n > 4 && (_wcsicmp(clean + n - 4, L".mp3") == 0 || _wcsicmp(clean + n - 4, L".wav") == 0)) clean[n - 4] = 0;
    for (i = 0; clean[i] == L' '; i++) {}
    if (i) memmove(clean, clean + i, (wcslen(clean + i) + 1) * sizeof(wchar_t));
    if (!clean[0]) {
        GetLocalTime(&t);
        swprintf(clean, 200, L"recording-%04d%02d%02d-%02d%02d%02d", t.wYear, t.wMonth, t.wDay, t.wHour, t.wMinute, t.wSecond);
    }
    swprintf(base, cap, L"%ls", clean);
    swprintf(g_path, MAX_PATH, L"%ls\\%ls.%ls", g_dir, base, ext);
    if (SendMessageW(g_over, BM_GETCHECK, 0, 0) != BST_CHECKED) {
        int k = 2;
        while (GetFileAttributesW(g_path) != INVALID_FILE_ATTRIBUTES && k < 1000) {
            swprintf(base, cap, L"%ls (%d)", clean, k);
            swprintf(g_path, MAX_PATH, L"%ls\\%ls.%ls", g_dir, base, ext);
            k++;
        }
    }
    swprintf(g_marksPath, MAX_PATH, L"%ls\\%ls-marks.txt", g_dir, base);
}

static void start_recording(void) {
    int i, sel = (int)SendMessageW(g_qual, CB_GETCURSEL, 0, 0);
    wchar_t base[260];
    if (g_state != S_IDLE) return;
    if (sel < 0 || sel >= NFMT) sel = 0;
    g_fmt = sel; g_isMp3 = FMT[sel].kbps > 0; g_rate = FMT[sel].rate;
    WAVEFORMATEX wf; ZeroMemory(&wf, sizeof wf);
    wf.wFormatTag = WAVE_FORMAT_PCM; wf.nChannels = 1; wf.nSamplesPerSec = g_rate; wf.wBitsPerSample = 16;
    wf.nBlockAlign = 2; wf.nAvgBytesPerSec = g_rate * 2;
    if (waveInOpen(&g_in, WAVE_MAPPER, &wf, (DWORD_PTR)g_wnd, 0, CALLBACK_WINDOW) != MMSYSERR_NOERROR) {
        g_in = NULL;
        set_status(L"No microphone found");
        set_msg(L"Plug in or enable a microphone in Windows sound settings, then press Record again.");
        return;
    }
    CreateDirectoryW(g_dir, NULL);
    make_paths(base, 260);
    {
        int over = SendMessageW(g_over, BM_GETCHECK, 0, 0) == BST_CHECKED;
        g_file = CreateFileW(g_path, GENERIC_WRITE, FILE_SHARE_READ, NULL, over ? CREATE_ALWAYS : CREATE_NEW, FILE_ATTRIBUTE_NORMAL, NULL);
    }
    if (g_file == INVALID_HANDLE_VALUE) {
        waveInClose(g_in); g_in = NULL;
        set_status(L"Could not create the file");
        set_msg(L"Windows would not let the recorder write there. Open Settings and choose another folder, or close any program using a file with the same name.");
        return;
    }
    if (g_isMp3 && mp3_open(g_rate, FMT[sel].kbps) != 0) {
        CloseHandle(g_file); g_file = INVALID_HANDLE_VALUE; DeleteFileW(g_path);
        waveInClose(g_in); g_in = NULL;
        set_status(L"Could not start the MP3 encoder");
        set_msg(L"Choose WAV in Settings and try again.");
        return;
    }
    g_lastTime[0] = 0; SetWindowTextW(g_timer, L"00:00:00");
    g_dataBytes = 0; g_silentMs = 0; g_bufCount = 0; g_nmarks = 0; g_peak = 0; g_maxPeak = 0;
    g_clipBufs = 0; g_totalBufs = 0; g_clipHold = 0; g_clipShown = 0; g_lim = 1.0f;
    if (g_scCap >= 0) sc_cancel();
    play_unload();
    if (!g_isMp3) write_header(g_file, g_rate, 0);
    DWORD size = g_rate * 2 / 10;
    for (i = 0; i < NBUF; i++) {
        g_buf[i] = (char *)calloc(1, size);
        ZeroMemory(&g_hdr[i], sizeof(WAVEHDR));
        g_hdr[i].lpData = g_buf[i]; g_hdr[i].dwBufferLength = size;
        waveInPrepareHeader(g_in, &g_hdr[i], sizeof(WAVEHDR));
        waveInAddBuffer(g_in, &g_hdr[i], sizeof(WAVEHDR));
    }
    waveInStart(g_in);
    g_state = S_REC; g_hasTake = 0;
    set_status(L"Recording"); set_msg(L"Saving as you go. If anything goes wrong, your recording is already on disk.");
    SetTimer(g_wnd, TIMER_UI, 70, NULL);
    save_settings();
    update_buttons();
}

static void pause_toggle(void) {
    int i;
    if (g_state == S_REC) {
        waveInStop(g_in); g_state = S_PAUSED; set_status(L"Paused");
    } else if (g_state == S_PAUSED) {
        for (i = 0; i < NBUF; i++) {
            if (g_hdr[i].dwFlags & WHDR_DONE) { g_hdr[i].dwUser = 0; g_hdr[i].dwBytesRecorded = 0; waveInAddBuffer(g_in, &g_hdr[i], sizeof(WAVEHDR)); }
        }
        waveInStart(g_in); g_state = S_REC; set_status(L"Recording");
    }
    update_buttons();
}

static void add_mark(void) {
    wchar_t t[32], s[96];
    if (g_nmarks < 512) g_marks[g_nmarks++] = elapsed();
    fmt_time(elapsed(), t, 32);
    swprintf(s, 96, L"Recording. Mark %d added at %ls", g_nmarks, t);
    set_status(s);
}

static void stop_recording(void) {
    wchar_t t[32], m[MAX_PATH + 160];
    close_input();
    KillTimer(g_wnd, TIMER_UI);
    if (g_file != INVALID_HANDLE_VALUE) {
        if (g_isMp3) mp3_close(file_write, NULL); else write_header(g_file, g_rate, g_dataBytes);
        CloseHandle(g_file); g_file = INVALID_HANDLE_VALUE;
    }
    g_state = S_IDLE; g_peak = 0;
    if (g_dataBytes < 4000) {
        DeleteFileW(g_path); g_hasTake = 0;
        set_status(L"Nothing was recorded"); set_msg(L"The recording was empty, so no file was kept. Check your microphone and try again.");
    } else {
        double mb = 0; WIN32_FILE_ATTRIBUTE_DATA fa;
        g_hasTake = 1;
        if (GetFileAttributesExW(g_path, GetFileExInfoStandard, &fa)) mb = ((double)fa.nFileSizeHigh * 4294967296.0 + fa.nFileSizeLow) / 1048576.0;
        if (g_nmarks > 0) {
            HANDLE h = CreateFileW(g_marksPath, GENERIC_WRITE, 0, NULL, CREATE_ALWAYS, FILE_ATTRIBUTE_NORMAL, NULL);
            if (h != INVALID_HANDLE_VALUE) {
                int i; char line[64]; DWORD w;
                for (i = 0; i < g_nmarks; i++) { int sec = (int)g_marks[i]; int n = sprintf(line, "Mark %d  %02d:%02d\r\n", i + 1, sec / 60, sec % 60); WriteFile(h, line, n, &w, NULL); }
                CloseHandle(h);
            }
        }
        fmt_time(elapsed(), t, 32);
        swprintf(m, MAX_PATH + 160, L"Saved (%ls, %.1f MB) to:\r\n%ls\r\nNext: press \"Transcribe on TypeMyworDz\" and choose this file there.", t, mb, g_path);
        set_status(L"Done and saved"); set_msg(m);
        if (g_maxPeak < 60) {
            set_status(L"Saved, but no sound was picked up");
            set_msg(L"The recording is silent. In Windows go to Settings, Privacy, Microphone and switch on \"Let desktop apps access your microphone\", then record again.");
        } else {
            if (g_totalBufs > 0 && g_clipBufs * 100 > g_totalBufs * 3 && g_clipBufs >= 3) {
                set_status(L"Saved, but the sound was too loud");
                set_msg(L"Your microphone was too loud, so parts of this recording are distorted. In Windows go to Settings, System, Sound, Input, lower the microphone volume (and switch off Microphone Boost if you see it), then record again.");
            }
            play_open();
        }
    }
    InvalidateRect(g_wnd, NULL, FALSE);
    update_buttons();
}

static void open_url(const wchar_t *u) { ShellExecuteW(NULL, L"open", u, NULL, NULL, SW_SHOWNORMAL); }

static void choose_folder(void) {
    BROWSEINFOW bi; PIDLIST_ABSOLUTE pid;
    ZeroMemory(&bi, sizeof bi);
    bi.hwndOwner = g_wnd; bi.lpszTitle = L"Choose where your recordings are saved";
    bi.ulFlags = BIF_RETURNONLYFSDIRS | BIF_NEWDIALOGSTYLE;
    pid = SHBrowseForFolderW(&bi);
    if (pid) {
        wchar_t p[MAX_PATH];
        if (SHGetPathFromIDListW(pid, p) && p[0]) { wcscpy(g_dir, p); SetWindowTextW(g_dirTxt, g_dir); save_settings(); }
        CoTaskMemFree(pid);
    }
}


/* ---- smooth vector drawing (GDI+ loaded at run time; plain GDI if it is missing) ---- */
typedef struct { float x, y; } PTF;
typedef struct { UINT32 v; void *cb; BOOL a, b; } GSI;
typedef struct { HDC dc; void *g; } GP;
static HMODULE g_gdip; static ULONG_PTR g_gtok; static int g_gdipTried;
static int (WINAPI *p_start)(ULONG_PTR *, const GSI *, void *);
static int (WINAPI *p_fromhdc)(HDC, void **);
static int (WINAPI *p_delg)(void *);
static int (WINAPI *p_smooth)(void *, int);
static int (WINAPI *p_brush)(UINT32, void **);
static int (WINAPI *p_delb)(void *);
static int (WINAPI *p_poly)(void *, void *, const PTF *, int, int);
static int (WINAPI *p_ell)(void *, void *, float, float, float, float);
static void gp_init(void) {
    GSI in; if (g_gdipTried) return; g_gdipTried = 1;
    g_gdip = LoadLibraryW(L"gdiplus.dll"); if (!g_gdip) return;
    p_start = (void *)GetProcAddress(g_gdip, "GdiplusStartup");
    p_fromhdc = (void *)GetProcAddress(g_gdip, "GdipCreateFromHDC");
    p_delg = (void *)GetProcAddress(g_gdip, "GdipDeleteGraphics");
    p_smooth = (void *)GetProcAddress(g_gdip, "GdipSetSmoothingMode");
    p_brush = (void *)GetProcAddress(g_gdip, "GdipCreateSolidFill");
    p_delb = (void *)GetProcAddress(g_gdip, "GdipDeleteBrush");
    p_poly = (void *)GetProcAddress(g_gdip, "GdipFillPolygon");
    p_ell = (void *)GetProcAddress(g_gdip, "GdipFillEllipse");
    in.v = 1; in.cb = NULL; in.a = FALSE; in.b = FALSE;
    if (!p_start || !p_fromhdc || !p_delg || !p_smooth || !p_brush || !p_delb || !p_poly || !p_ell || p_start(&g_gtok, &in, NULL) != 0) p_start = NULL;
}
static void gp_begin(GP *g, HDC dc) {
    gp_init(); g->dc = dc; g->g = NULL;
    if (p_start && p_fromhdc(dc, &g->g) == 0) p_smooth(g->g, 4); else g->g = NULL;
}
static void gp_end(GP *g) { if (g->g) p_delg(g->g); g->g = NULL; }
static UINT32 argb(COLORREF c) { return 0xFF000000u | ((UINT32)GetRValue(c) << 16) | ((UINT32)GetGValue(c) << 8) | GetBValue(c); }
static void gp_poly(GP *g, COLORREF c, const PTF *pt, int n) {
    if (g->g) { void *b = NULL; if (p_brush(argb(c), &b) == 0) { p_poly(g->g, b, pt, n, 0); p_delb(b); } }
    else { POINT q[8]; int i; HBRUSH br = CreateSolidBrush(c); HPEN pe = CreatePen(PS_SOLID, 1, c); HGDIOBJ ob = SelectObject(g->dc, br), op = SelectObject(g->dc, pe);
        for (i = 0; i < n && i < 8; i++) { q[i].x = (LONG)(pt[i].x + 0.5f); q[i].y = (LONG)(pt[i].y + 0.5f); }
        Polygon(g->dc, q, n); SelectObject(g->dc, ob); SelectObject(g->dc, op); DeleteObject(br); DeleteObject(pe); }
}
static void gp_ell(GP *g, COLORREF c, float x, float y, float w, float h) {
    if (g->g) { void *b = NULL; if (p_brush(argb(c), &b) == 0) { p_ell(g->g, b, x, y, w, h); p_delb(b); } }
    else { HBRUSH br = CreateSolidBrush(c); HPEN pe = CreatePen(PS_SOLID, 1, c); HGDIOBJ ob = SelectObject(g->dc, br), op = SelectObject(g->dc, pe);
        Ellipse(g->dc, (int)x, (int)y, (int)(x + w), (int)(y + h)); SelectObject(g->dc, ob); SelectObject(g->dc, op); DeleteObject(br); DeleteObject(pe); }
}
static void gp_rect(GP *g, COLORREF c, float x, float y, float w, float h) {
    PTF q[4]; q[0].x = x; q[0].y = y; q[1].x = x + w; q[1].y = y; q[2].x = x + w; q[2].y = y + h; q[3].x = x; q[3].y = y + h;
    gp_poly(g, c, q, 4);
}
static void gp_pill(GP *g, COLORREF c, float x, float y, float w, float h) {
    float r = h / 2;
    gp_ell(g, c, x, y, h, h); gp_ell(g, c, x + w - h, y, h, h); gp_rect(g, c, x + r, y, w - h, h);
}
/* icons, centred on (cx, cy), s = size in pixels */
static void ic_tri(GP *g, COLORREF c, float cx, float cy, float s, int right) {
    PTF q[3]; float h = s * 0.5f;
    if (right) { q[0].x = cx - h * 0.7f; q[0].y = cy - h; q[1].x = cx - h * 0.7f; q[1].y = cy + h; q[2].x = cx + h * 0.9f; q[2].y = cy; }
    else { q[0].x = cx + h * 0.7f; q[0].y = cy - h; q[1].x = cx + h * 0.7f; q[1].y = cy + h; q[2].x = cx - h * 0.9f; q[2].y = cy; }
    gp_poly(g, c, q, 3);
}
static void ic_play(GP *g, COLORREF c, float cx, float cy, float s) { ic_tri(g, c, cx + s * 0.06f, cy, s, 1); }
static void ic_pause(GP *g, COLORREF c, float cx, float cy, float s) { float bw = s * 0.28f; gp_rect(g, c, cx - bw * 1.45f, cy - s * 0.5f, bw, s); gp_rect(g, c, cx + bw * 0.45f, cy - s * 0.5f, bw, s); }
static void ic_stop(GP *g, COLORREF c, float cx, float cy, float s) { gp_rect(g, c, cx - s * 0.45f, cy - s * 0.45f, s * 0.9f, s * 0.9f); }
static void ic_start(GP *g, COLORREF c, float cx, float cy, float s) { gp_rect(g, c, cx - s * 0.55f, cy - s * 0.5f, s * 0.16f, s); ic_tri(g, c, cx + s * 0.18f, cy, s * 0.85f, 0); }
static void ic_rew(GP *g, COLORREF c, float cx, float cy, float s) { ic_tri(g, c, cx - s * 0.26f, cy, s * 0.62f, 0); ic_tri(g, c, cx + s * 0.28f, cy, s * 0.62f, 0); }
static void ic_fwd(GP *g, COLORREF c, float cx, float cy, float s) { ic_tri(g, c, cx - s * 0.28f, cy, s * 0.62f, 1); ic_tri(g, c, cx + s * 0.26f, cy, s * 0.62f, 1); }

/* ---- slider: a modern progress / volume / speed bar. Speaks the same messages
   as the Windows trackbar, so the rest of the program is unchanged. ---- */
#define TSG(h, i) ((int)GetWindowLongPtrW((h), (i) * (int)sizeof(LONG_PTR)))
#define TSS(h, i, v) SetWindowLongPtrW((h), (i) * (int)sizeof(LONG_PTR), (LONG_PTR)(v))
enum { TS_MIN, TS_MAX, TS_POS, TS_DRAG, TS_PAGE, TS_LINE, TS_N };
static void tss_note(HWND h, int code) { SendMessageW(GetParent(h), WM_HSCROLL, MAKEWPARAM(code, (WORD)TSG(h, TS_POS)), (LPARAM)h); }
static void tss_set(HWND h, int v) {
    int lo = TSG(h, TS_MIN), hi = TSG(h, TS_MAX);
    if (v < lo) v = lo; if (v > hi) v = hi;
    if (v != TSG(h, TS_POS)) { TSS(h, TS_POS, v); InvalidateRect(h, NULL, FALSE); }
}
static int tss_from_x(HWND h, int x) {
    RECT r; int pad = S(10), lo = TSG(h, TS_MIN), hi = TSG(h, TS_MAX), wd;
    GetClientRect(h, &r); wd = r.right - 2 * pad; if (wd < 1) wd = 1;
    x -= pad; if (x < 0) x = 0; if (x > wd) x = wd;
    return lo + (int)((double)x * (hi - lo) / wd + 0.5);
}
static LRESULT CALLBACK tss_proc(HWND h, UINT m, WPARAM w, LPARAM l) {
    switch (m) {
    case WM_CREATE: TSS(h, TS_MIN, 0); TSS(h, TS_MAX, 100); TSS(h, TS_POS, 0); TSS(h, TS_DRAG, 0); TSS(h, TS_PAGE, 10); TSS(h, TS_LINE, 1); return 0;
    case 0x0406: /* TBM_SETRANGE */ TSS(h, TS_MIN, (short)LOWORD(l)); TSS(h, TS_MAX, (short)HIWORD(l)); InvalidateRect(h, NULL, FALSE); return 0;
    case 0x0405: /* TBM_SETPOS */ if (!TSG(h, TS_DRAG)) tss_set(h, (int)l); return 0;
    case 0x0400: /* TBM_GETPOS */ return TSG(h, TS_POS);
    case 0x0415: TSS(h, TS_PAGE, (int)l); return 0;
    case 0x0417: TSS(h, TS_LINE, (int)l); return 0;
    case WM_GETDLGCODE: return DLGC_WANTARROWS;
    case WM_ERASEBKGND: return 1;
    case WM_SETFOCUS: case WM_KILLFOCUS: InvalidateRect(h, NULL, FALSE); return 0;
    case WM_LBUTTONDOWN:
        SetFocus(h); SetCapture(h); TSS(h, TS_DRAG, 1);
        TSS(h, TS_POS, tss_from_x(h, (short)LOWORD(l))); InvalidateRect(h, NULL, FALSE); tss_note(h, TB_THUMBTRACK); return 0;
    case WM_MOUSEMOVE:
        if (TSG(h, TS_DRAG)) { TSS(h, TS_POS, tss_from_x(h, (short)LOWORD(l))); InvalidateRect(h, NULL, FALSE); tss_note(h, TB_THUMBTRACK); }
        return 0;
    case WM_LBUTTONUP:
        if (TSG(h, TS_DRAG)) { TSS(h, TS_DRAG, 0); ReleaseCapture(); tss_note(h, TB_ENDTRACK); InvalidateRect(h, NULL, FALSE); }
        return 0;
    case WM_CAPTURECHANGED: if (TSG(h, TS_DRAG)) { TSS(h, TS_DRAG, 0); tss_note(h, TB_ENDTRACK); } return 0;
    case WM_MOUSEWHEEL: {
        int d = GET_WHEEL_DELTA_WPARAM(w) > 0 ? 1 : -1;
        tss_set(h, TSG(h, TS_POS) + d * TSG(h, TS_LINE) * 2); tss_note(h, d > 0 ? TB_LINEDOWN : TB_LINEUP); tss_note(h, TB_ENDTRACK); return 0; }
    case WM_KEYDOWN: {
        int v = TSG(h, TS_POS), ln = TSG(h, TS_LINE), pg = TSG(h, TS_PAGE), code = TB_LINEDOWN;
        switch (w) {
        case VK_LEFT: case VK_DOWN: v -= ln; code = TB_LINEUP; break;
        case VK_RIGHT: case VK_UP: v += ln; break;
        case VK_PRIOR: v += pg; code = TB_PAGEDOWN; break;
        case VK_NEXT: v -= pg; code = TB_PAGEUP; break;
        case VK_HOME: v = TSG(h, TS_MIN); code = TB_TOP; break;
        case VK_END: v = TSG(h, TS_MAX); code = TB_BOTTOM; break;
        default: return DefWindowProcW(h, m, w, l);
        }
        tss_set(h, v); tss_note(h, code); tss_note(h, TB_ENDTRACK); return 0; }
    case WM_PAINT: {
        PAINTSTRUCT ps; HDC dc = BeginPaint(h, &ps); RECT r; GetClientRect(h, &r);
        HDC mdc = CreateCompatibleDC(dc); HBITMAP bm = CreateCompatibleBitmap(dc, r.right, r.bottom); HGDIOBJ ob = SelectObject(mdc, bm);
        HBRUSH wb = CreateSolidBrush(RGB(255, 255, 255)); GP g; int pad = S(10), lo = TSG(h, TS_MIN), hi = TSG(h, TS_MAX), pos = TSG(h, TS_POS);
        float cy = r.bottom / 2.0f, th = (float)S(6), tw = (float)(r.right - 2 * pad), fx; float rad = (float)S(8);
        FillRect(mdc, &r, wb); DeleteObject(wb);
        gp_begin(&g, mdc);
        gp_pill(&g, RGB(228, 225, 245), (float)pad, cy - th / 2, tw, th);
        fx = hi > lo ? (float)(pos - lo) / (hi - lo) * tw : 0;
        if (fx > 1) gp_pill(&g, RGB(91, 68, 207), (float)pad, cy - th / 2, fx < th ? th : fx, th);
        if (GetFocus() == h) gp_ell(&g, RGB(214, 207, 247), pad + fx - rad - S(3), cy - rad - S(3), 2 * rad + 2 * S(3), 2 * rad + 2 * S(3));
        gp_ell(&g, RGB(255, 255, 255), pad + fx - rad - 1, cy - rad - 1, 2 * rad + 2, 2 * rad + 2);
        gp_ell(&g, RGB(91, 68, 207), pad + fx - rad + 1, cy - rad + 1, 2 * rad - 2, 2 * rad - 2);
        gp_ell(&g, RGB(255, 255, 255), pad + fx - rad * 0.32f, cy - rad * 0.32f, rad * 0.64f, rad * 0.64f);
        gp_end(&g);
        BitBlt(dc, 0, 0, r.right, r.bottom, mdc, 0, 0, SRCCOPY);
        SelectObject(mdc, ob); DeleteObject(bm); DeleteDC(mdc); EndPaint(h, &ps); return 0; }
    }
    return DefWindowProcW(h, m, w, l);
}

/* global-style transport buttons: Start | Back | Play/Pause | Forward | Stop */
static void draw_transport(DRAWITEMSTRUCT *d) {
    int id = (int)d->CtlID, down = (d->itemState & ODS_SELECTED) != 0, big = id == ID_PLAY;
    int lab = S(17), W = d->rcItem.right - d->rcItem.left, H = d->rcItem.bottom - d->rcItem.top;
    int dia = H - lab - S(2); GP g; HBRUSH wb = CreateSolidBrush(RGB(255, 255, 255)); wchar_t t[64];
    float cx, cy, isz;
    COLORREF fill, ink;
    FillRect(d->hDC, &d->rcItem, wb); DeleteObject(wb);
    if (dia > W) dia = W;
    cx = d->rcItem.left + W / 2.0f; cy = d->rcItem.top + dia / 2.0f + S(1); isz = dia * (big ? 0.36f : 0.34f);
    GetWindowTextW(d->hwndItem, t, 64);
    if (big) { fill = down ? RGB(70, 50, 170) : RGB(91, 68, 207); ink = RGB(255, 255, 255); }
    else { fill = down ? RGB(222, 217, 247) : RGB(240, 237, 252); ink = RGB(91, 68, 207); }
    gp_begin(&g, d->hDC);
    if (big) gp_ell(&g, RGB(226, 221, 248), cx - dia / 2.0f - S(3), cy - dia / 2.0f - S(3), (float)dia + 2 * S(3), (float)dia + 2 * S(3));
    gp_ell(&g, fill, cx - dia / 2.0f, cy - dia / 2.0f, (float)dia, (float)dia);
    switch (id) {
    case ID_PLAY: if (!wcscmp(t, L"Pause")) ic_pause(&g, ink, cx, cy, isz); else ic_play(&g, ink, cx, cy, isz * 1.05f); break;
    case ID_START: ic_start(&g, ink, cx, cy, isz); break;
    case ID_BACK: ic_rew(&g, ink, cx, cy, isz * 1.1f); break;
    case ID_FORWARD: ic_fwd(&g, ink, cx, cy, isz * 1.1f); break;
    case ID_PSTOP: ic_stop(&g, ink, cx, cy, isz * 0.9f); break;
    }
    gp_end(&g);
    { RECT lr = { d->rcItem.left - S(4), d->rcItem.bottom - lab, d->rcItem.right + S(4), d->rcItem.bottom };
      HGDIOBJ of = SelectObject(d->hDC, g_fontSmall); SetBkMode(d->hDC, TRANSPARENT); SetTextColor(d->hDC, RGB(110, 114, 128));
      DrawTextW(d->hDC, t, -1, &lr, DT_CENTER | DT_VCENTER | DT_SINGLELINE | DT_NOCLIP); SelectObject(d->hDC, of); }
    if (d->itemState & ODS_FOCUS) { RECT fr = { d->rcItem.left + S(2), d->rcItem.top, d->rcItem.right - S(2), d->rcItem.top + dia + S(2) }; DrawFocusRect(d->hDC, &fr); }
}

static void draw_header(HDC dc) {
    RECT cl, r; HBRUSH wb = CreateSolidBrush(RGB(255, 255, 255)); HPEN lp = CreatePen(PS_SOLID, 1, RGB(236, 233, 248));
    HGDIOBJ op, of; SIZE a, b; int dx = S(g_ox), x = S(60) + dx, y = S(10);
    GetClientRect(g_wnd, &cl); r.left = 0; r.top = 0; r.right = cl.right; r.bottom = S(52);
    FillRect(dc, &r, wb); DeleteObject(wb);
    op = SelectObject(dc, lp);
    MoveToEx(dc, 0, S(51), NULL); LineTo(dc, cl.right, S(51)); SelectObject(dc, op); DeleteObject(lp);
    if (!g_logo) g_logo = (HICON)LoadImageW(g_inst, MAKEINTRESOURCEW(1), IMAGE_ICON, S(32), S(32), 0);
    if (g_logo) DrawIconEx(dc, S(18) + dx, S(10), g_logo, S(32), S(32), 0, NULL, DI_NORMAL);
    of = SelectObject(dc, g_fontBrand); SetBkMode(dc, TRANSPARENT);
    GetTextExtentPoint32W(dc, L"Type", 4, &a); GetTextExtentPoint32W(dc, L"Scribe", 6, &b);
    SetTextColor(dc, RGB(91, 68, 207)); TextOutW(dc, x, y - S(2), L"Type", 4);
    SetTextColor(dc, RGB(40, 167, 69)); TextOutW(dc, x + a.cx, y - S(2), L"Scribe", 6);
    SelectObject(dc, g_fontSmall); SetTextColor(dc, RGB(150, 154, 166));
    TextOutW(dc, x + a.cx + b.cx + S(6), y + S(7), L"v" RECORDER_VERSION, 1 + (int)wcslen(RECORDER_VERSION));
    SelectObject(dc, of);
}

static void draw_button(DRAWITEMSTRUCT *d);
static void draw_button_raw(DRAWITEMSTRUCT *d);
static void draw_button_main(DRAWITEMSTRUCT *d);
static void draw_button_raw(DRAWITEMSTRUCT *d) {
    int id = (int)d->CtlID;
    if (id == ID_PLAY || id == ID_BACK || id == ID_START || id == ID_FORWARD || id == ID_PSTOP) { draw_transport(d); return; }
    draw_button_main(d);
}

static void draw_button(DRAWITEMSTRUCT *d) {
    int w = d->rcItem.right - d->rcItem.left, h = d->rcItem.bottom - d->rcItem.top;
    HDC real = d->hDC, m; HBITMAP bm; HGDIOBJ ob; RECT all; HBRUSH wb;
    if (w <= 1 || h <= 1) return;
    m = CreateCompatibleDC(real); bm = CreateCompatibleBitmap(real, d->rcItem.right, d->rcItem.bottom);
    ob = SelectObject(m, bm);
    all.left = 0; all.top = 0; all.right = d->rcItem.right; all.bottom = d->rcItem.bottom;
    wb = CreateSolidBrush(RGB(255, 255, 255)); FillRect(m, &all, wb); DeleteObject(wb);
    d->hDC = m; draw_button_raw(d); d->hDC = real;
    BitBlt(real, d->rcItem.left, d->rcItem.top, w, h, m, d->rcItem.left, d->rcItem.top, SRCCOPY);
    SelectObject(m, ob); DeleteObject(bm); DeleteDC(m);
}

static void draw_button_main(DRAWITEMSTRUCT *d) {
    int id = (int)d->CtlID;
    if (id == ID_MINI) {
        HBRUSH bb = CreateSolidBrush(RGB(243, 241, 252)); HPEN bp = CreatePen(PS_SOLID, 1, RGB(91, 68, 207));
        HGDIOBJ ob0 = SelectObject(d->hDC, bb), op0 = SelectObject(d->hDC, bp), of0;
        RECT tr = d->rcItem;
        RoundRect(d->hDC, d->rcItem.left, d->rcItem.top, d->rcItem.right, d->rcItem.bottom, S(26), S(26));
        SelectObject(d->hDC, ob0); SelectObject(d->hDC, op0); DeleteObject(bb); DeleteObject(bp);
        of0 = SelectObject(d->hDC, g_fontSmall); SetBkMode(d->hDC, TRANSPARENT); SetTextColor(d->hDC, RGB(91, 68, 207));
        DrawTextW(d->hDC, g_mini ? L"Full size" : L"Type Mini", -1, &tr, DT_CENTER | DT_VCENTER | DT_SINGLELINE);
        SelectObject(d->hDC, of0);
        if (d->itemState & ODS_FOCUS) { RECT fr = d->rcItem; InflateRect(&fr, -S(3), -S(3)); DrawFocusRect(d->hDC, &fr); }
        return;
    }
    if (id == ID_COLLAPSE) {
        HBRUSH bb = CreateSolidBrush(RGB(243, 241, 252)); HPEN lp = CreatePen(PS_SOLID, 1, RGB(222, 218, 244)); HGDIOBJ of0, op0;
        RECT tr = d->rcItem;
        FillRect(d->hDC, &d->rcItem, bb); DeleteObject(bb);
        op0 = SelectObject(d->hDC, lp);
        MoveToEx(d->hDC, d->rcItem.left, d->rcItem.top, NULL); LineTo(d->hDC, d->rcItem.left, d->rcItem.bottom);
        MoveToEx(d->hDC, d->rcItem.right - 1, d->rcItem.top, NULL); LineTo(d->hDC, d->rcItem.right - 1, d->rcItem.bottom);
        SelectObject(d->hDC, op0); DeleteObject(lp);
        of0 = SelectObject(d->hDC, g_font); SetBkMode(d->hDC, TRANSPARENT); SetTextColor(d->hDC, RGB(91, 68, 207));
        DrawTextW(d->hDC, g_collapsed ? L"\u203A" : L"\u2039", -1, &tr, DT_CENTER | DT_VCENTER | DT_SINGLELINE);
        SelectObject(d->hDC, of0);
        return;
    }
    if (id == ID_WEB) {
        HBRUSH bb = CreateSolidBrush(RGB(91, 68, 207)); HPEN bp = CreatePen(PS_SOLID, 1, RGB(91, 68, 207));
        HGDIOBJ ob0 = SelectObject(d->hDC, bb), op0 = SelectObject(d->hDC, bp);
        RoundRect(d->hDC, d->rcItem.left, d->rcItem.top, d->rcItem.right, d->rcItem.bottom, S(14), S(14));
        SelectObject(d->hDC, ob0); SelectObject(d->hDC, op0); DeleteObject(bb); DeleteObject(bp);
        int cs = S(34), cx = d->rcItem.right - S(14) - cs, cy = (d->rcItem.top + d->rcItem.bottom - cs) / 2;
        HBRUSH gb = CreateSolidBrush(RGB(40, 167, 69)); HPEN gp = CreatePen(PS_SOLID, 1, RGB(40, 167, 69));
        ob0 = SelectObject(d->hDC, gb); op0 = SelectObject(d->hDC, gp);
        Ellipse(d->hDC, cx, cy, cx + cs, cy + cs);
        SelectObject(d->hDC, ob0); SelectObject(d->hDC, op0); DeleteObject(gb); DeleteObject(gp);
        SetBkMode(d->hDC, TRANSPARENT); SetTextColor(d->hDC, RGB(255, 255, 255));
        HGDIOBJ of0 = SelectObject(d->hDC, g_font);
        RECT ar = { cx, cy, cx + cs, cy + cs };
        DrawTextW(d->hDC, g_panelOpen ? L"\u2190" : L"\u2192", -1, &ar, DT_CENTER | DT_VCENTER | DT_SINGLELINE);
        RECT t1 = { d->rcItem.left + S(16), d->rcItem.top + S(9), cx - S(8), d->rcItem.top + S(36) };
        DrawTextW(d->hDC, L"Transcribe on TypeMyworDz", -1, &t1, DT_LEFT | DT_VCENTER | DT_SINGLELINE);
        SelectObject(d->hDC, g_fontSmall); SetTextColor(d->hDC, RGB(240, 238, 250));
        RECT t2 = { d->rcItem.left + S(16), d->rcItem.top + S(36), cx - S(8), d->rcItem.bottom - S(7) };
        DrawTextW(d->hDC, g_panelOpen ? L"The panel is open on the right. Click to close it." : L"Sign in and transcribe right here, without leaving TypeScribe.", -1, &t2, DT_LEFT | DT_WORDBREAK);
        SelectObject(d->hDC, of0);
        if (d->itemState & ODS_FOCUS) { RECT fr = d->rcItem; InflateRect(&fr, -S(4), -S(4)); DrawFocusRect(d->hDC, &fr); }
        return;
    }
    int disabled = (d->itemState & ODS_DISABLED) != 0, down = (d->itemState & ODS_SELECTED) != 0;
    COLORREF fill = RGB(255, 255, 255), border = RGB(91, 68, 207), text = RGB(91, 68, 207);
    if (id == ID_REC || id == ID_WEB) { fill = RGB(40, 167, 69); border = fill; text = RGB(255, 255, 255); }
    else if (id == ID_STOP) { fill = RGB(20, 22, 26); border = fill; text = RGB(255, 255, 255); }
    if (down && !disabled) { if (fill == RGB(255, 255, 255)) fill = RGB(238, 235, 252); else fill = RGB(GetRValue(fill) * 85 / 100, GetGValue(fill) * 85 / 100, GetBValue(fill) * 85 / 100); }
    if (disabled) { fill = (fill == RGB(255, 255, 255)) ? RGB(255, 255, 255) : RGB(190, 192, 198); border = RGB(209, 205, 238); text = (text == RGB(255, 255, 255)) ? RGB(255, 255, 255) : RGB(190, 186, 224); }
    HBRUSH b = CreateSolidBrush(fill); HPEN p = CreatePen(PS_SOLID, 1, border);
    HGDIOBJ ob = SelectObject(d->hDC, b), op = SelectObject(d->hDC, p);
    int act = (id >= ID_REC && id <= ID_MARK && id != ID_SKIP && id != ID_QUAL && id != ID_OVER && id != ID_TOP);
    int rr = act ? S(36) : S(10);
    RoundRect(d->hDC, d->rcItem.left, d->rcItem.top, d->rcItem.right, d->rcItem.bottom, rr, rr);
    SelectObject(d->hDC, ob); SelectObject(d->hDC, op); DeleteObject(b); DeleteObject(p);
    wchar_t t[64]; GetWindowTextW(d->hwndItem, t, 64);
    SetBkMode(d->hDC, TRANSPARENT); SetTextColor(d->hDC, text);
    HGDIOBJ of = SelectObject(d->hDC, g_font);
    RECT tr = d->rcItem;
    if (act) {
        GP g; float cx = (float)(d->rcItem.left + S(16)), cy = (d->rcItem.top + d->rcItem.bottom) / 2.0f, sz = (float)S(11);
        gp_begin(&g, d->hDC);
        if (id == ID_REC) gp_ell(&g, text, cx - sz * 0.5f, cy - sz * 0.5f, sz, sz);
        else if (id == ID_PAUSE) { if (!wcscmp(t, L"Resume")) ic_play(&g, text, cx, cy, sz); else ic_pause(&g, text, cx, cy, sz); }
        else if (id == ID_STOP) ic_stop(&g, text, cx, cy, sz * 0.9f);
        else if (id == ID_MARK) { PTF q[4]; q[0].x = cx; q[0].y = cy - sz * 0.6f; q[1].x = cx + sz * 0.5f; q[1].y = cy; q[2].x = cx; q[2].y = cy + sz * 0.6f; q[3].x = cx - sz * 0.5f; q[3].y = cy; gp_poly(&g, text, q, 4); }
        gp_end(&g);
        tr.left += S(22); tr.right -= S(4);
    }
    DrawTextW(d->hDC, t, -1, &tr, DT_CENTER | DT_VCENTER | DT_SINGLELINE);
    SelectObject(d->hDC, of);
}

/* The wave bars: the same bars, spacing and purple as the TypeMyworDz web app,
   drawn off screen and copied over so they never flicker. */
static void grad(HDC dc, int x, int y1, int y2, COLORREF a, COLORREF b) {
    TRIVERTEX v[2]; GRADIENT_RECT gr = { 0, 1 };
    v[0].x = x; v[0].y = y1; v[0].Red = GetRValue(a) << 8; v[0].Green = GetGValue(a) << 8; v[0].Blue = GetBValue(a) << 8; v[0].Alpha = 0;
    v[1].x = x + S(3); v[1].y = y2; v[1].Red = GetRValue(b) << 8; v[1].Green = GetGValue(b) << 8; v[1].Blue = GetBValue(b) << 8; v[1].Alpha = 0;
    GradientFill(dc, v, 2, &gr, 1, GRADIENT_FILL_RECT_V);
}

static void draw_wave(HDC dc) {
    int w = S(PW_W), h = S(PW_H), i;
    HDC m = CreateCompatibleDC(dc);
    HBITMAP bm = CreateCompatibleBitmap(dc, w, h);
    HGDIOBJ obm = SelectObject(m, bm);
    HBRUSH bg = CreateSolidBrush(RGB(247, 245, 253)); HPEN pen = CreatePen(PS_SOLID, 1, RGB(232, 229, 246)), bl = CreatePen(PS_SOLID, 1, RGB(228, 225, 244));
    HBRUSH wb = CreateSolidBrush(RGB(255, 255, 255));
    RECT all = { 0, 0, w, h }; FillRect(m, &all, wb);
    HGDIOBJ ob = SelectObject(m, bg), op = SelectObject(m, pen);
    RoundRect(m, 0, 0, w, h, S(18), S(18));
    SelectObject(m, bl); MoveToEx(m, S(18), h / 2, NULL); LineTo(m, w - S(18), h / 2);
    int rec = g_state == S_REC, live = rec && g_peak > 1200, paused = g_state == S_PAUSED;
    double lvl = rec ? g_peak / 12000.0 : 0; if (lvl > 1) lvl = 1;
    double tt = GetTickCount() / 1000.0 * 1.4;
    int bw = S(3), gap = S(4), total = 32 * bw + 31 * gap, x0 = (w - total) / 2;
    COLORREF mid = live ? RGB(115, 98, 205) : paused ? RGB(226, 223, 246) : RGB(214, 209, 243);
    COLORREF edge = live ? RGB(190, 181, 239) : paused ? RGB(238, 236, 250) : RGB(232, 229, 247);
    for (i = 0; i < 32; i++) {
        double pulse = 0.32 + fabs(sin(i * 0.72 + tt * 0.9)) * 0.68;
        double sc = 0.22 + lvl * 1.75 * pulse; if (sc > 1.35) sc = 1.35; if (sc < 0.22) sc = 0.22;
        int bh = (int)(S(34) * sc), y1 = (h - bh) / 2, x = x0 + i * (bw + gap);
        grad(m, x, y1, y1 + bh / 2, edge, mid);
        grad(m, x, y1 + bh / 2, y1 + bh, mid, edge);
    }
    BitBlt(dc, S(PW_X + g_ox), S(PW_Y), w, h, m, 0, 0, SRCCOPY);
    SelectObject(m, ob); SelectObject(m, op); SelectObject(m, obm);
    DeleteObject(bg); DeleteObject(pen); DeleteObject(bl); DeleteObject(wb); DeleteObject(bm); DeleteDC(m);
}

static void make_fonts(void) {
    HFONT a = g_font, b = g_fontSmall, c = g_fontBig, d0 = g_fontBrand;
    g_fontScale = g_scale;
    g_font = CreateFontW(-F(15), 0, 0, 0, FW_SEMIBOLD, 0, 0, 0, DEFAULT_CHARSET, 0, 0, CLEARTYPE_QUALITY, 0, L"Segoe UI");
    g_fontSmall = CreateFontW(-F(13), 0, 0, 0, FW_NORMAL, 0, 0, 0, DEFAULT_CHARSET, 0, 0, CLEARTYPE_QUALITY, 0, L"Segoe UI");
    g_fontBig = CreateFontW(-F(66), 0, 0, 0, FW_SEMIBOLD, 0, 0, 0, DEFAULT_CHARSET, 0, 0, CLEARTYPE_QUALITY, 0, L"Segoe UI");
    g_fontBrand = CreateFontW(-F(24), 0, 0, 0, FW_BOLD, 0, 0, 0, DEFAULT_CHARSET, 0, 0, CLEARTYPE_QUALITY, 0, L"Georgia");
    if (a) { /* controls already exist: give them the new fonts, then free the old ones */
        int i; HWND all[] = { g_status, g_msg, g_skip, g_qual, g_over, g_top, g_name, g_lblName, g_lblQ, g_lblDir, g_dirTxt, g_btnSet, g_btnDir, g_foot, g_lblSize, g_size, g_lblHotkey, g_hotkeyValue, g_hotkeyNote };
        for (i = 0; i < 19; i++) if (all[i]) SendMessageW(all[i], WM_SETFONT, (WPARAM)g_font, TRUE);
        for (i = 0; i < 9; i++) if (g_btn[i]) SendMessageW(g_btn[i], WM_SETFONT, (WPARAM)g_font, TRUE);
        for (i = 0; i < 5; i++) if (g_pBtn[i]) SendMessageW(g_pBtn[i], WM_SETFONT, (WPARAM)g_fontSmall, TRUE);
        if (g_pOpen) SendMessageW(g_pOpen, WM_SETFONT, (WPARAM)g_font, TRUE);
        if (g_pLast) SendMessageW(g_pLast, WM_SETFONT, (WPARAM)g_font, TRUE);
        if (g_pName) SendMessageW(g_pName, WM_SETFONT, (WPARAM)g_fontSmall, TRUE);
        for (i = 0; i < NSC; i++) {
            if (g_scVal[i]) SendMessageW(g_scVal[i], WM_SETFONT, (WPARAM)g_font, TRUE);
            if (g_scBtn[i]) SendMessageW(g_scBtn[i], WM_SETFONT, (WPARAM)g_font, TRUE);
            if (g_scDef[i]) SendMessageW(g_scDef[i], WM_SETFONT, (WPARAM)g_font, TRUE);
            if (g_scLbl[i]) SendMessageW(g_scLbl[i], WM_SETFONT, (WPARAM)g_fontSmall, TRUE);
        }
        if (g_lblPlay) SendMessageW(g_lblPlay, WM_SETFONT, (WPARAM)g_font, TRUE);
        if (g_lblBack) SendMessageW(g_lblBack, WM_SETFONT, (WPARAM)g_font, TRUE);
        if (g_backCombo) SendMessageW(g_backCombo, WM_SETFONT, (WPARAM)g_font, TRUE);
        if (g_pTime) SendMessageW(g_pTime, WM_SETFONT, (WPARAM)g_fontSmall, TRUE);
        if (g_pVolTxt) SendMessageW(g_pVolTxt, WM_SETFONT, (WPARAM)g_fontSmall, TRUE);
        if (g_pSpdTxt) SendMessageW(g_pSpdTxt, WM_SETFONT, (WPARAM)g_fontSmall, TRUE);
        SendMessageW(g_timer, WM_SETFONT, (WPARAM)g_fontBig, TRUE);
        SendMessageW(g_msg, WM_SETFONT, (WPARAM)g_fontSmall, TRUE);
        SendMessageW(g_lblDir, WM_SETFONT, (WPARAM)g_fontSmall, TRUE);
        SendMessageW(g_dirTxt, WM_SETFONT, (WPARAM)g_fontSmall, TRUE);
        SendMessageW(g_foot, WM_SETFONT, (WPARAM)g_fontSmall, TRUE);
        if (g_hotkeyNote) SendMessageW(g_hotkeyNote, WM_SETFONT, (WPARAM)g_fontSmall, TRUE);
        DeleteObject(a); DeleteObject(b); DeleteObject(c); if (d0) DeleteObject(d0);
    }
}

static void set_zoom(int pct) {
    g_zoom = pct; g_scale = g_dpi * pct / 100.0;
    make_fonts(); layout();
}

static HWND mkex(DWORD ex, const wchar_t *cls, const wchar_t *txt, DWORD style, int x, int y, int w, int h, int id, HFONT f) {
    HWND c = CreateWindowExW(ex, cls, txt, WS_CHILD | WS_VISIBLE | style, S(x), S(y), S(w), S(h), g_wnd, (HMENU)(INT_PTR)id, g_inst, NULL);
    SendMessageW(c, WM_SETFONT, (WPARAM)(f ? f : g_font), TRUE);
    return c;
}
static HWND mk(const wchar_t *cls, const wchar_t *txt, DWORD style, int x, int y, int w, int h, int id, HFONT f) {
    return mkex(0, cls, txt, style, x, y, w, h, id, f);
}

static void topmost(int on) {
    SetWindowPos(g_wnd, on ? HWND_TOPMOST : HWND_NOTOPMOST, 0, 0, 0, 0, SWP_NOMOVE | SWP_NOSIZE | SWP_NOACTIVATE);
}

static LRESULT CALLBACK proc(HWND h, UINT m, WPARAM w, LPARAM l) {
    switch (m) {
    case WM_CREATE: {
        int i; wchar_t df[MAX_PATH], docs[MAX_PATH];
        g_wnd = h;
        DragAcceptFiles(h, TRUE);
        g_btnMini = mk(L"BUTTON", L"Type Mini", BS_OWNERDRAW | WS_TABSTOP, 262, 13, 102, 26, ID_MINI, 0);
        g_strip = mk(L"BUTTON", L"", BS_OWNERDRAW, 380, 0, STRIP_W, 100, ID_COLLAPSE, 0);
        ShowWindow(g_strip, SW_HIDE);
        g_timer = mk(L"STATIC", L"00:00:00", SS_CENTER, 0, 56, 380, 90, ID_TIMER_TXT, g_fontBig);
        g_status = mk(L"STATIC", L"Ready to record", SS_CENTER, 0, 66, 380, 22, ID_STATUS, 0);
        g_btn[0] = mk(L"BUTTON", L"Record", BS_OWNERDRAW | WS_TABSTOP, 30, 178, 74, 38, ID_REC, 0);
        g_btn[1] = mk(L"BUTTON", L"Pause", BS_OWNERDRAW | WS_TABSTOP, 112, 178, 74, 38, ID_PAUSE, 0);
        g_btn[2] = mk(L"BUTTON", L"Stop", BS_OWNERDRAW | WS_TABSTOP, 194, 178, 74, 38, ID_STOP, 0);
        g_btn[3] = mk(L"BUTTON", L"Mark", BS_OWNERDRAW | WS_TABSTOP, 276, 178, 74, 38, ID_MARK, 0);
        g_lblName = mk(L"STATIC", L"File name", 0, 30, 235, 66, 20, 0, 0);
        g_name = mkex(WS_EX_CLIENTEDGE, L"EDIT", L"", ES_AUTOHSCROLL | WS_TABSTOP, 100, 232, 250, 24, ID_NAME, 0);
        SendMessageW(g_name, EM_LIMITTEXT, 120, 0);
        SendMessageW(g_name, EM_SETCUEBANNER, FALSE, (LPARAM)L"Empty = date and time");
        {
            wchar_t saved_name[128];
            if (!reg_get_sz(L"RecordingName", saved_name, 128)) wcscpy(saved_name, L"TMWZ Audio");
            SetWindowTextW(g_name, saved_name);
        }
        g_over = mk(L"BUTTON", L"Replace a file that has the same name", BS_AUTOCHECKBOX | WS_TABSTOP, 30, 266, 320, 22, ID_OVER, 0);
        g_skip = mk(L"BUTTON", L"Skip long silences while recording", BS_AUTOCHECKBOX | WS_TABSTOP, 30, 292, 320, 22, ID_SKIP, 0);
        g_top = mk(L"BUTTON", L"Keep this window on top of other windows", BS_AUTOCHECKBOX | WS_TABSTOP, 30, 318, 320, 22, ID_TOP, 0);
        g_lblHotkey = mk(L"STATIC", L"Global record/stop shortcut", 0, 30, 348, 320, 18, 0, 0);
        g_hotkeyValue = mk(L"STATIC", L"Ctrl+Shift+R", SS_LEFT, 30, 369, 145, 24, 0, 0);
        g_btn[7] = mk(L"BUTTON", L"Change", BS_OWNERDRAW | WS_TABSTOP, 180, 367, 75, 28, ID_HOTKEY_CHANGE, 0);
        g_btn[8] = mk(L"BUTTON", L"Default", BS_OWNERDRAW | WS_TABSTOP, 265, 367, 85, 28, ID_HOTKEY_DEFAULT, 0);
        g_hotkeyNote = mk(L"STATIC", L"Works while minimized. A single key is intercepted in other apps; Tab also affects normal focus navigation.", SS_LEFT, 30, 399, 320, 52, 0, g_fontSmall);
        g_btnSet = mk(L"BUTTON", L"Settings", BS_OWNERDRAW | WS_TABSTOP, 30, 458, 130, 28, ID_SETTINGS, 0);
        g_lblQ = mk(L"STATIC", L"Quality", 0, 30, 388, 60, 20, 0, 0);
        g_qual = mk(L"COMBOBOX", L"", CBS_DROPDOWNLIST | WS_TABSTOP | WS_VSCROLL, 92, 384, 258, 140, ID_QUAL, 0);
        for (i = 0; i < NFMT; i++) SendMessageW(g_qual, CB_ADDSTRING, 0, (LPARAM)FMT[i].label);
        g_lblDir = mk(L"STATIC", L"Save recordings in", 0, 30, 420, 320, 18, 0, g_fontSmall);
        g_dirTxt = mk(L"STATIC", L"", SS_LEFT | SS_PATHELLIPSIS, 30, 440, 320, 34, ID_DIRTXT, g_fontSmall);
        g_btnDir = mk(L"BUTTON", L"Change folder...", BS_OWNERDRAW | WS_TABSTOP, 30, 478, 150, 28, ID_DIR, 0);
        g_msg = mk(L"STATIC", L"Recordings save locally as you go. Drag an MP3, WAV or M4A onto this window to play it.", 0, 30, 518, 320, 64, ID_MSG, g_fontSmall);
        g_btn[4] = mk(L"BUTTON", L"Transcribe on TypeMyworDz", BS_OWNERDRAW | WS_TABSTOP, 30, 590, 320, 64, ID_WEB, 0);
        g_btn[5] = mk(L"BUTTON", L"Show file in folder", BS_OWNERDRAW | WS_TABSTOP, 30, 590, 320, 34, ID_FOLDER, 0);
        g_btn[6] = mk(L"BUTTON", L"Make the file smaller (free tool)", BS_OWNERDRAW | WS_TABSTOP, 30, 632, 320, 32, ID_SHRINK, 0);
        g_foot = mk(L"STATIC", L"Version " RECORDER_VERSION L" · Ctrl+Shift+R starts and stops recording from any window.", 0, 30, 672, 320, 34, ID_FOOT, g_fontSmall);
        g_lblSize = mk(L"STATIC", L"Window size", 0, 30, 388, 90, 20, 0, 0);
        g_size = mk(L"COMBOBOX", L"", CBS_DROPDOWNLIST | WS_TABSTOP | WS_VSCROLL, 124, 384, 226, 140, ID_SIZE, 0);
        for (i = 0; i < NZOOM; i++) SendMessageW(g_size, CB_ADDSTRING, 0, (LPARAM)ZOOMS[i].label);
        /* playback panel (shown when a recording or audio file is loaded) */
        g_pOpen = mk(L"BUTTON", L"Play a file from this computer", BS_OWNERDRAW | WS_TABSTOP, 30, 560, 320, 30, ID_OPENF, 0);
        g_pLast = mk(L"BUTTON", L"Play my recording", BS_OWNERDRAW | WS_TABSTOP, 196, 560, 154, 30, ID_LASTREC, 0);
        g_pName = mk(L"STATIC", L"", SS_CENTER | 0x4000, 24, 148, 332, 18, ID_PNAME, g_fontSmall);
        g_pBtn[0] = mk(L"BUTTON", L"Play", BS_OWNERDRAW | WS_TABSTOP, 158, 274, 80, 90, ID_PLAY, 0);
        g_pBtn[1] = mk(L"BUTTON", L"Back 5s", BS_OWNERDRAW | WS_TABSTOP, 90, 284, 62, 74, ID_BACK, 0);
        g_pBtn[2] = mk(L"BUTTON", L"Start", BS_OWNERDRAW | WS_TABSTOP, 22, 284, 62, 74, ID_START, 0);
        g_pBtn[3] = mk(L"BUTTON", L"Forward 5s", BS_OWNERDRAW | WS_TABSTOP, 244, 284, 62, 74, ID_FORWARD, 0);
        g_pBtn[4] = mk(L"BUTTON", L"Stop", BS_OWNERDRAW | WS_TABSTOP, 312, 284, 56, 74, ID_PSTOP, 0);
        g_pTime = mk(L"STATIC", L"", SS_CENTER, 24, 168, 332, 18, ID_PTIME, g_fontSmall);
        g_pSeek = mk(TSS_CLASS, L"", WS_TABSTOP, 22, 190, 336, 28, ID_SEEK, 0);
        SendMessageW(g_pSeek, TBM_SETRANGE, TRUE, MAKELONG(0, 1000));
        SendMessageW(g_pSeek, TBM_SETPAGESIZE, 0, 50);
        SendMessageW(g_pSeek, TBM_SETLINESIZE, 0, 10);
        g_pVolTxt = mk(L"STATIC", L"Volume 100%", 0, 30, 226, 150, 16, ID_PVOLTXT, g_fontSmall);
        g_pVol = mk(TSS_CLASS, L"", WS_TABSTOP, 24, 242, 160, 26, ID_VOL, 0);
        SendMessageW(g_pVol, TBM_SETRANGE, TRUE, MAKELONG(0, 200));
        SendMessageW(g_pVol, TBM_SETPAGESIZE, 0, 10);
        SendMessageW(g_pVol, TBM_SETLINESIZE, 0, 5);
        g_pSpdTxt = mk(L"STATIC", L"Speed 100%", 0, 200, 226, 150, 16, ID_PSPDTXT, g_fontSmall);
        g_pSpd = mk(TSS_CLASS, L"", WS_TABSTOP, 196, 242, 160, 26, ID_SPEED, 0);
        SendMessageW(g_pSpd, TBM_SETRANGE, TRUE, MAKELONG(10, 60));
        SendMessageW(g_pSpd, TBM_SETPAGESIZE, 0, 2);
        SendMessageW(g_pSpd, TBM_SETLINESIZE, 0, 1);
        {
            int vol = (int)reg_get_dw(L"PlayVolume", 100), spd = (int)reg_get_dw(L"PlaySpeed", 20), rw = (int)reg_get_dw(L"RewindSeconds", 5), ri = 3;
            if (vol < 0 || vol > 200) vol = 100;
            if (spd < 10 || spd > 60) spd = 20;
            for (i = 0; i < NREWIND; i++) if (REWIND_CHOICES[i] == rw) ri = i;
            g_rewind = REWIND_CHOICES[ri];
            SendMessageW(g_pVol, TBM_SETPOS, TRUE, vol);
            SendMessageW(g_pSpd, TBM_SETPOS, TRUE, spd);
            play_update_labels();
            /* settings: playback shortcuts and rewind amount */
            sc_load();
            g_lblPlay = mk(L"STATIC", L"Playback shortcuts (work from any window, even when minimized)", 0, 30, 460, 320, 18, 0, 0);
            for (i = 0; i < NSC; i++) {
                g_scLbl[i] = mk(L"STATIC", SC_DEF[i].label, 0, 30, 480, 320, 18, 0, g_fontSmall);
                g_scVal[i] = mk(L"STATIC", L"", SS_LEFT, 30, 500, 145, 24, 0, 0);
                g_scBtn[i] = mk(L"BUTTON", L"Change", BS_OWNERDRAW | WS_TABSTOP, 180, 498, 75, 28, ID_SC_CHANGE + i, 0);
                g_scDef[i] = mk(L"BUTTON", L"Default", BS_OWNERDRAW | WS_TABSTOP, 265, 498, 85, 28, ID_SC_DEFAULT + i, 0);
            }
            g_lblBack = mk(L"STATIC", L"Rewind amount", 0, 30, 540, 150, 20, 0, 0);
            g_backCombo = mk(L"COMBOBOX", L"", CBS_DROPDOWNLIST | WS_TABSTOP | WS_VSCROLL, 184, 536, 166, 200, ID_BACKSECS, 0);
            for (i = 0; i < NREWIND; i++) {
                wchar_t t[32]; swprintf(t, 32, i == 0 ? L"%d second" : L"%d seconds", REWIND_CHOICES[i]);
                SendMessageW(g_backCombo, CB_ADDSTRING, 0, (LPARAM)t);
            }
            SendMessageW(g_backCombo, CB_SETCURSEL, ri, 0);
            back_label();
            sc_update_controls();
        }
        /* saved settings */
        i = (int)reg_get_dw(L"Format", DEFAULT_FMT); if (i < 0 || i >= NFMT) i = DEFAULT_FMT;
        SendMessageW(g_qual, CB_SETCURSEL, i, 0);
        { int zi = 5, k; DWORD zp = reg_get_dw(L"Zoom", 100);
          for (k = 0; k < NZOOM; k++) if ((DWORD)ZOOMS[k].pct == zp) zi = k;
          SendMessageW(g_size, CB_SETCURSEL, zi, 0);
          if (ZOOMS[zi].pct != g_zoom) { g_zoom = ZOOMS[zi].pct; g_scale = g_dpi * g_zoom / 100.0; make_fonts(); } }
        {
            DWORD saved_vk = reg_get_dw(L"HotkeyKey", DEFAULT_HOTKEY_VK);
            DWORD saved_mods = reg_get_dw(L"HotkeyMods", DEFAULT_HOTKEY_MODS);
            if (hotkey_is_valid(saved_vk, saved_mods)) { g_hotkeyVk = saved_vk; g_hotkeyMods = saved_mods; }
            g_hotkeyOk = register_global_hotkey(g_hotkeyMods, g_hotkeyVk);
            update_hotkey_controls();
            update_ready_status();
            if (!sc_register_global_hotkeys()) set_status(L"A playback shortcut is unavailable; another app may be using it. Choose a different key in Settings.");
        }
        SendMessageW(g_top, BM_SETCHECK, reg_get_dw(L"OnTop", 0) ? BST_CHECKED : BST_UNCHECKED, 0);
        SendMessageW(g_over, BM_SETCHECK, reg_get_dw(L"Replace", 0) ? BST_CHECKED : BST_UNCHECKED, 0);
        SendMessageW(g_skip, BM_SETCHECK, reg_get_dw(L"SkipSilence", 0) ? BST_CHECKED : BST_UNCHECKED, 0);
        if (!reg_get_sz(L"Folder", g_dir, MAX_PATH)) {
            if (FAILED(SHGetFolderPathW(NULL, CSIDL_PERSONAL, NULL, 0, docs))) { GetTempPathW(MAX_PATH, docs); }
            swprintf(df, MAX_PATH, L"%ls\\TypeMyworDz Recordings", docs);
            wcscpy(g_dir, df);
        }
        SetWindowTextW(g_dirTxt, g_dir);
        if (reg_get_dw(L"OnTop", 0)) topmost(1);
        g_ready = 1;
        update_buttons();
        return 0;
    }
    case WM_ACTIVATE:
        if (LOWORD(w) == WA_INACTIVE && g_hotkeyCapturing) cancel_hotkey_capture();
        if (LOWORD(w) == WA_INACTIVE && g_scCap >= 0) sc_cancel();
        return DefWindowProcW(h, m, w, l);
    case WM_KILLFOCUS:
        if (g_hotkeyCapturing) cancel_hotkey_capture();
        return DefWindowProcW(h, m, w, l);
    case WM_KEYDOWN: case WM_SYSKEYDOWN:
        if (g_scCap >= 0) {
            if ((UINT)w == VK_ESCAPE) { sc_cancel(); return 0; }
            if (is_modifier_vk((UINT)w)) return 0;
            sc_finish((UINT)w, pressed_hotkey_mods() & ~(UINT)MOD_WIN);
            return 0;
        }
        if (g_hotkeyCapturing) {
            if ((UINT)w == VK_ESCAPE) { cancel_hotkey_capture(); return 0; }
            if (is_modifier_vk((UINT)w)) return 0;
            finish_hotkey_capture((UINT)w, pressed_hotkey_mods());
            return 0;
        }
        break;
    case WM_COMMAND:
        switch (LOWORD(w)) {
        case ID_REC: start_recording(); break;
        case ID_PAUSE: pause_toggle(); break;
        case ID_STOP: stop_recording(); break;
        case ID_MARK: add_mark(); break;
        case ID_SETTINGS:
            if (g_hotkeyCapturing) cancel_hotkey_capture();
            if (g_scCap >= 0) sc_cancel();
            g_showSet = !g_showSet; update_buttons(); break;
        case ID_HOTKEY_CHANGE: if (g_scCap >= 0) sc_cancel(); begin_hotkey_capture(); break;
        case ID_OPENF: play_choose_file(); break;
        case ID_LASTREC: play_last_recording(); break;
        case ID_PLAY: play_toggle(); break;
        case ID_BACK: play_back(); break;
        case ID_START: play_start(); break;
        case ID_FORWARD: play_forward(); break;
        case ID_PSTOP: play_stop(); break;
        case ID_SC_CHANGE: case ID_SC_CHANGE + 1: case ID_SC_CHANGE + 2: case ID_SC_CHANGE + 3: sc_begin(LOWORD(w) - ID_SC_CHANGE); break;
        case ID_SC_DEFAULT: case ID_SC_DEFAULT + 1: case ID_SC_DEFAULT + 2: case ID_SC_DEFAULT + 3: sc_default(LOWORD(w) - ID_SC_DEFAULT); break;
        case ID_BACKSECS: if (HIWORD(w) == CBN_SELCHANGE) {
            int ri = (int)SendMessageW(g_backCombo, CB_GETCURSEL, 0, 0);
            if (ri >= 0 && ri < NREWIND) { g_rewind = REWIND_CHOICES[ri]; back_label(); save_settings(); }
        } break;
        case ID_HOTKEY_DEFAULT:
            if (g_hotkeyCapturing) cancel_hotkey_capture();
            apply_hotkey(DEFAULT_HOTKEY_VK, DEFAULT_HOTKEY_MODS); break;
        case ID_DIR: choose_folder(); break;
        case ID_TOP: topmost(SendMessageW(g_top, BM_GETCHECK, 0, 0) == BST_CHECKED); save_settings(); break;
        case ID_OVER: case ID_SKIP: save_settings(); break;
        case ID_NAME: if (HIWORD(w) == EN_CHANGE) save_recording_name(); break;
        case ID_QUAL: if (HIWORD(w) == CBN_SELCHANGE) save_settings(); break;
        case ID_SIZE: if (HIWORD(w) == CBN_SELCHANGE) {
            int zi = (int)SendMessageW(g_size, CB_GETCURSEL, 0, 0);
            if (zi >= 0 && zi < NZOOM) { set_zoom(ZOOMS[zi].pct); save_settings(); }
        } break;
        case ID_WEB: panel_toggle(); InvalidateRect(g_btn[4], NULL, FALSE); break;
        case ID_MINI: if (g_mini) mini_exit(); else mini_enter(); break;
        case ID_COLLAPSE: set_collapsed(!g_collapsed); break;
        case ID_SHRINK: open_url(L"https://typemywordz.ai/tools/audio-converter.html"); break;
        case ID_FOLDER: {
            wchar_t a[MAX_PATH + 32]; swprintf(a, MAX_PATH + 32, L"/select,\"%ls\"", g_path);
            ShellExecuteW(NULL, L"open", L"explorer.exe", a, NULL, SW_SHOWNORMAL); break; }
        }
        return 0;
    case WM_DROPFILES: {
        HDROP drop = (HDROP)w;
        UINT count = DragQueryFileW(drop, 0xFFFFFFFF, NULL, 0);
        if (g_hotkeyCapturing || g_scCap >= 0) {
            set_status(L"Finish changing a shortcut before dropping audio.");
        } else if (g_state != S_IDLE) {
            set_status(L"Stop recording before dropping an audio file.");
        } else if (count != 1) {
            set_status(L"Drop one MP3, WAV or M4A file at a time.");
        } else {
            UINT chars = DragQueryFileW(drop, 0, NULL, 0);
            wchar_t path[MAX_PATH];
            if (chars >= MAX_PATH) {
                set_status(L"That file path is too long to load here.");
            } else if (!DragQueryFileW(drop, 0, path, MAX_PATH)) {
                set_status(L"Could not read the dropped file path.");
            } else {
                play_load_external(path);
            }
        }
        DragFinish(drop);
        return 0;
    }
    case MM_WIM_DATA: {
        WAVEHDR *hd = (WAVEHDR *)l;
        if (g_in && hd) {
            process_hdr(hd);
            if (g_state == S_REC) { hd->dwUser = 0; hd->dwBytesRecorded = 0; waveInAddBuffer(g_in, hd, sizeof(WAVEHDR)); }
        }
        return 0; }
    case WM_HSCROLL: {
        HWND c = (HWND)l; int code = LOWORD(w);
        if (c == g_pSeek && g_plOk) {
            double dur = pl_dur(); int v = (int)SendMessageW(g_pSeek, TBM_GETPOS, 0, 0);
            if (code == TB_THUMBTRACK) {
                g_seekDrag = 1; show_pos(dur * v / 1000.0, dur);
            } else if (code != TB_ENDTRACK || g_seekDrag) {
                g_seekDrag = 0; pl_seek(dur * v / 1000.0); play_tick();
            }
        } else if (c == g_pVol) {
            play_update_labels(); if (g_plOk) pl_set_volume(SendMessageW(g_pVol, TBM_GETPOS, 0, 0) / 100.0);
            if (code == TB_ENDTRACK) save_settings();
        } else if (c == g_pSpd) {
            play_update_labels(); if (g_plOk) pl_set_speed(SendMessageW(g_pSpd, TBM_GETPOS, 0, 0) * 0.05);
            if (code == TB_ENDTRACK) save_settings();
        }
        return 0; }
    case WM_TIMER:
        if (w == TIMER_PLAY) { play_tick(); return 0; }
        if (w == TIMER_UI) {
            if (g_state == S_REC) {
                int loud = g_clipHold > 0;
                if (g_clipHold > 0) g_clipHold--;
                if (loud != g_clipShown) { g_clipShown = loud; set_status(loud ? L"Recording. Too loud, move back from the microphone" : L"Recording"); }
            }
            wchar_t t[32]; fmt_hms(elapsed(), t, 32);
            if (wcscmp(t, g_lastTime)) { wcscpy(g_lastTime, t); SetWindowTextW(g_timer, t); }
            RECT r = { S(PW_X + g_ox), S(PW_Y), S(PW_X + g_ox + PW_W), S(PW_Y + PW_H) }; if (!g_mini || g_miniCut > PW_Y) InvalidateRect(h, &r, FALSE);
            g_peak = g_peak * 8 / 10;
        }
        return 0;
    case WM_HOTKEY:
        if (w == HOTKEY_REC && !g_hotkeyCapturing && g_scCap < 0) { if (g_state == S_IDLE) start_recording(); else stop_recording(); }
        else if (!g_hotkeyCapturing && g_scCap < 0 && g_state == S_IDLE && g_plOk && !(g_collapsed && g_panelOpen)) {
            if (w == HOTKEY_PLAY) play_toggle();
            else if (w == HOTKEY_PLAY + 1) play_back();
            else if (w == HOTKEY_PLAY + 2) play_start();
            else if (w == HOTKEY_PLAY + 3) play_forward();
        }
        return 0;
    case WM_DRAWITEM: draw_button((DRAWITEMSTRUCT *)l); return TRUE;
    case WM_CTLCOLORSTATIC: case WM_CTLCOLORBTN: {
        HDC dc = (HDC)w; int id = GetDlgCtrlID((HWND)l);
        SetBkColor(dc, RGB(255, 255, 255));
        SetTextColor(dc, id == ID_TIMER_TXT ? (playback_mode() ? RGB(91, 68, 207) : RGB(20, 22, 26)) : (id == ID_STATUS || id == ID_FOOT || id == ID_DIRTXT) ? RGB(133, 138, 149) : RGB(63, 67, 76));
        return (LRESULT)g_white; }
    case WM_ERASEBKGND: return 1;
    case WM_PAINT: {
        PAINTSTRUCT ps; HDC dc = BeginPaint(h, &ps), m; HBITMAP bm; HGDIOBJ ob;
        int pw = ps.rcPaint.right - ps.rcPaint.left, ph = ps.rcPaint.bottom - ps.rcPaint.top;
        if (pw > 0 && ph > 0) {
            RECT all = { 0, 0, pw, ph }; HBRUSH wb = CreateSolidBrush(RGB(255, 255, 255));
            m = CreateCompatibleDC(dc); bm = CreateCompatibleBitmap(dc, pw, ph); ob = SelectObject(m, bm);
            FillRect(m, &all, wb); DeleteObject(wb);
            SetViewportOrgEx(m, -ps.rcPaint.left, -ps.rcPaint.top, NULL);
            if (!g_hideAll) {
                if (ps.rcPaint.top < S(52)) draw_header(m);
                if (!playback_mode() && !(g_mini && g_miniCut <= PW_Y)) {
                    RECT wr = { S(PW_X + g_ox), S(PW_Y), S(PW_X + g_ox + PW_W), S(PW_Y + PW_H) }, ix;
                    if (IntersectRect(&ix, &wr, &ps.rcPaint)) draw_wave(m);
                }
            }
            SetViewportOrgEx(m, 0, 0, NULL);
            BitBlt(dc, ps.rcPaint.left, ps.rcPaint.top, pw, ph, m, 0, 0, SRCCOPY);
            SelectObject(m, ob); DeleteObject(bm); DeleteDC(m);
        }
        EndPaint(h, &ps); return 0; }
    case WM_SIZE:
        if (g_ready && !g_inLayout && w != SIZE_MINIMIZED) {
            RECT cr; int cw; GetClientRect(h, &cr); cw = (int)(cr.right / g_scale + 0.5);
            if (g_ox != ox_for(cw)) { g_noResize = 1; layout(); g_noResize = 0; }
            else { place_panel(); InvalidateRect(h, NULL, FALSE); }
        }
        return 0;
    case WM_GETMINMAXINFO: {
        MINMAXINFO *mm = (MINMAXINFO *)l;
        if (g_ready) {
            int mw = g_mini ? LW : g_panelOpen ? (g_collapsed ? STRIP_W + WEB_MIN : LW + STRIP_W + WEB_MIN) : LW, mh = g_needH;
            RECT r; MONITORINFO mi; HMONITOR mon = MonitorFromWindow(h, MONITOR_DEFAULTTONEAREST);
            r.left = 0; r.top = 0; r.right = S(mw); r.bottom = S(mh);
            AdjustWindowRectEx(&r, (DWORD)GetWindowLongPtrW(h, GWL_STYLE), FALSE, 0);
            mi.cbSize = sizeof mi;
            if (GetMonitorInfoW(mon, &mi) && r.bottom - r.top > mi.rcWork.bottom - mi.rcWork.top) r.bottom = r.top + (mi.rcWork.bottom - mi.rcWork.top);
            mm->ptMinTrackSize.x = r.right - r.left; mm->ptMinTrackSize.y = r.bottom - r.top;
            if (g_mini) { mm->ptMaxTrackSize.x = mm->ptMinTrackSize.x; mm->ptMaxTrackSize.y = mm->ptMinTrackSize.y; }
        }
        return 0; }
    case WM_EXITSIZEMOVE:
        if (g_mini) mini_save_pos();
        else if (!IsZoomed(h) && !IsIconic(h)) { RECT cr; GetClientRect(h, &cr); g_userH = (int)(cr.bottom / g_scale + 0.5); }
        return 0;
    case WM_CLOSE:
        if (g_mini) mini_save_pos();
        UnregisterHotKey(h, HOTKEY_REC);
        wp_destroy();
        sc_unregister_global_hotkeys();
        if (g_state != S_IDLE) stop_recording();
        save_settings();
        play_unload();
        DestroyWindow(h); return 0;
    case WM_DESTROY: PostQuitMessage(0); return 0;
    }
    return DefWindowProcW(h, m, w, l);
}

int WINAPI wWinMain(HINSTANCE inst, HINSTANCE prev, LPWSTR cmd, int show) {
    (void)prev; (void)cmd;
    g_inst = inst;
    OleInitialize(NULL);
    InitCommonControls();
    HDC sdc = GetDC(NULL); g_dpi = GetDeviceCaps(sdc, LOGPIXELSX) / 96.0; ReleaseDC(NULL, sdc); g_scale = g_dpi;
    g_white = CreateSolidBrush(RGB(255, 255, 255));
    make_fonts();
    WNDCLASSW wc; ZeroMemory(&wc, sizeof wc);
    wc.lpfnWndProc = proc; wc.hInstance = inst; wc.hCursor = LoadCursor(NULL, IDC_ARROW);
    wc.hbrBackground = NULL; wc.lpszClassName = L"TMWZRecorder"; wc.hIcon = LoadIconW(inst, MAKEINTRESOURCEW(1));
    RegisterClassW(&wc);
    wp_set_request_cb(panel_request_audio);
    { WNDCLASSW sc; ZeroMemory(&sc, sizeof sc); sc.lpfnWndProc = tss_proc; sc.hInstance = inst; sc.hCursor = LoadCursor(NULL, IDC_HAND); sc.lpszClassName = TSS_CLASS; sc.cbWndExtra = TS_N * (int)sizeof(LONG_PTR); RegisterClassW(&sc); }
    RECT r = { 0, 0, S(380), S(520) };
    AdjustWindowRect(&r, WINSTYLE, FALSE);
    HWND w = CreateWindowExW(0, L"TMWZRecorder", L"TypeScribe v" RECORDER_VERSION, WINSTYLE,
        CW_USEDEFAULT, CW_USEDEFAULT, r.right - r.left, r.bottom - r.top, NULL, NULL, inst, NULL);
    ShowWindow(w, show); UpdateWindow(w);
    MSG msg;
    while (GetMessageW(&msg, NULL, 0, 0) > 0) {
        if (g_hotkeyCapturing || g_scCap >= 0) DispatchMessageW(&msg);
        else if (!(msg.hwnd == w || GetParent(msg.hwnd) == w) || !IsDialogMessageW(w, &msg)) { TranslateMessage(&msg); DispatchMessageW(&msg); } /* keys inside the embedded browser must reach it untouched */
    }
    OleUninitialize();
    return 0;
}
