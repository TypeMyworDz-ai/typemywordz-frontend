/* TypeScribe: embedded TypeMyworDz panel using Microsoft Edge WebView2.
   WebView2Loader.dll (Microsoft, redistributable) is stored inside the exe as a
   resource and unpacked on first use; nothing has to be installed by the user
   except the free Evergreen WebView2 Runtime, which Windows 11 and current
   Windows 10 already include. */
#define UNICODE
#define _UNICODE
#define COBJMACROS
#define INITGUID
#include <windows.h>
#include <objbase.h>
#include <shlobj.h>
#include <stdio.h>
#include <wchar.h>
#include "wv2inc/WebView2.h"
#include "webpanel.h"

#define IDR_WV2LOADER 200

typedef HRESULT (STDAPICALLTYPE *CreateEnvFn)(PCWSTR, PCWSTR, ICoreWebView2EnvironmentOptions *, ICoreWebView2CreateCoreWebView2EnvironmentCompletedHandler *);

static HWND g_parent;
static RECT g_rc;
static wchar_t g_url[512], g_root[MAX_PATH], g_hand[MAX_PATH];
static wp_fail_fn g_fail;
static ICoreWebView2Controller *g_ctl;
static ICoreWebView2 *g_wv;
static int g_started, g_pageReady, g_visible = 1;
static void (*g_reqCb)(void);
static wchar_t *g_pending; /* JSON waiting for the page to say it is ready */
static ICoreWebView2Environment *g_env;

static void fail(const wchar_t *why) { if (g_fail) g_fail(why); }

/* ---- tiny COM objects (one per handler type) ---- */
typedef struct { const void *vtbl; LONG ref; } Obj;
static HRESULT STDMETHODCALLTYPE q_ni(void *This, REFIID riid, void **out) { (void)riid; *out = This; ((Obj *)This)->ref++; return S_OK; }
static ULONG STDMETHODCALLTYPE q_ar(void *This) { return (ULONG)++((Obj *)This)->ref; }
static ULONG STDMETHODCALLTYPE q_rl(void *This) { return (ULONG)((Obj *)This)->ref > 1 ? (ULONG)--((Obj *)This)->ref : 1; }

static void post_pending(void) {
    if (g_wv && g_pageReady && g_pending) ICoreWebView2_PostWebMessageAsJson(g_wv, g_pending);
}

/* WebMessageReceived: the page says "typescribe-ready" once its listener exists */
static HRESULT STDMETHODCALLTYPE msg_invoke(ICoreWebView2WebMessageReceivedEventHandler *This, ICoreWebView2 *s, ICoreWebView2WebMessageReceivedEventArgs *a) {
    LPWSTR str = NULL; (void)This; (void)s;
    if (SUCCEEDED(ICoreWebView2WebMessageReceivedEventArgs_TryGetWebMessageAsString(a, &str)) && str) {
        if (!wcscmp(str, L"typescribe-ready")) { g_pageReady = 1; post_pending(); }
        else if (!wcscmp(str, L"typescribe-request-audio")) { if (g_reqCb) g_reqCb(); }
        CoTaskMemFree(str);
    }
    return S_OK;
}
static ICoreWebView2WebMessageReceivedEventHandlerVtbl msg_vt = { (void *)q_ni, (void *)q_ar, (void *)q_rl, msg_invoke };
static Obj msg_obj = { &msg_vt, 1 };

static HRESULT STDMETHODCALLTYPE nav_invoke(ICoreWebView2NavigationCompletedEventHandler *This, ICoreWebView2 *s, ICoreWebView2NavigationCompletedEventArgs *a) {
    (void)This; (void)s; (void)a; g_pageReady = 0; /* a new page: wait for its ready message again */
    return S_OK;
}
static ICoreWebView2NavigationCompletedEventHandlerVtbl nav_vt = { (void *)q_ni, (void *)q_ar, (void *)q_rl, nav_invoke };
static Obj nav_obj = { &nav_vt, 1 };

static HRESULT STDMETHODCALLTYPE ctl_invoke(ICoreWebView2CreateCoreWebView2ControllerCompletedHandler *This, HRESULT hr, ICoreWebView2Controller *c) {
    (void)This;
    if (FAILED(hr) || !c) { fail(L"The embedded browser could not start."); return S_OK; }
    g_ctl = c; ICoreWebView2Controller_AddRef(c);
    ICoreWebView2Controller_get_CoreWebView2(c, &g_wv);
    ICoreWebView2Controller_put_Bounds(c, g_rc);
    ICoreWebView2Controller_put_IsVisible(c, g_visible);
    if (g_wv) {
        EventRegistrationToken tk; ICoreWebView2Settings *st = NULL;
        if (SUCCEEDED(ICoreWebView2_get_Settings(g_wv, &st)) && st) {
            ICoreWebView2Settings_put_IsStatusBarEnabled(st, FALSE);
            ICoreWebView2Settings_put_AreDevToolsEnabled(st, FALSE);
            ICoreWebView2Settings_put_IsZoomControlEnabled(st, FALSE);
            ICoreWebView2Settings_Release(st);
        }
        {   /* let the page fetch the audio file we hand over, from a private virtual address */
            ICoreWebView2_3 *w3 = NULL;
            if (SUCCEEDED(ICoreWebView2_QueryInterface(g_wv, &IID_ICoreWebView2_3, (void **)&w3)) && w3) {
                ICoreWebView2_3_SetVirtualHostNameToFolderMapping(w3, L"typescribe.local", g_hand, COREWEBVIEW2_HOST_RESOURCE_ACCESS_KIND_ALLOW);
                ICoreWebView2_3_Release(w3);
            }
        }
        ICoreWebView2_add_WebMessageReceived(g_wv, (ICoreWebView2WebMessageReceivedEventHandler *)&msg_obj, &tk);
        ICoreWebView2_add_NavigationCompleted(g_wv, (ICoreWebView2NavigationCompletedEventHandler *)&nav_obj, &tk);
        ICoreWebView2_Navigate(g_wv, g_url);
        g_started = 1;
    }
    return S_OK;
}
static ICoreWebView2CreateCoreWebView2ControllerCompletedHandlerVtbl ctl_vt = { (void *)q_ni, (void *)q_ar, (void *)q_rl, ctl_invoke };
static Obj ctl_obj = { &ctl_vt, 1 };

static HRESULT STDMETHODCALLTYPE env_invoke(ICoreWebView2CreateCoreWebView2EnvironmentCompletedHandler *This, HRESULT hr, ICoreWebView2Environment *env) {
    (void)This;
    if (FAILED(hr) || !env) { fail(L"Microsoft Edge WebView2 Runtime was not found."); return S_OK; }
    g_env = env; ICoreWebView2Environment_AddRef(env);
    ICoreWebView2Environment_CreateCoreWebView2Controller(env, g_parent, (ICoreWebView2CreateCoreWebView2ControllerCompletedHandler *)&ctl_obj);
    return S_OK;
}
static ICoreWebView2CreateCoreWebView2EnvironmentCompletedHandlerVtbl env_vt = { (void *)q_ni, (void *)q_ar, (void *)q_rl, env_invoke };
static Obj env_obj = { &env_vt, 1 };

/* ---- setup ---- */
static int extract_loader(wchar_t *dllPath) {
    HRSRC r = FindResourceW(NULL, MAKEINTRESOURCEW(IDR_WV2LOADER), RT_RCDATA);
    HGLOBAL g; DWORD sz; const void *p; HANDLE f, h; WIN32_FIND_DATAW fd; DWORD w;
    if (!r) return 0;
    g = LoadResource(NULL, r); sz = SizeofResource(NULL, r); p = LockResource(g);
    if (!g || !p || !sz) return 0;
    swprintf(dllPath, MAX_PATH, L"%ls\\WebView2Loader.dll", g_root);
    h = FindFirstFileW(dllPath, &fd);
    if (h != INVALID_HANDLE_VALUE) { FindClose(h); if (fd.nFileSizeLow == sz && !fd.nFileSizeHigh) return 1; }
    f = CreateFileW(dllPath, GENERIC_WRITE, 0, NULL, CREATE_ALWAYS, FILE_ATTRIBUTE_NORMAL, NULL);
    if (f == INVALID_HANDLE_VALUE) return 0;
    WriteFile(f, p, sz, &w, NULL); CloseHandle(f);
    return w == sz;
}

int wp_started(void) { return g_started; }

int wp_start(HWND parent, int x, int y, int w, int h, const wchar_t *url, wp_fail_fn failcb) {
    wchar_t base[MAX_PATH], dll[MAX_PATH], ud[MAX_PATH]; HMODULE m; CreateEnvFn fn; HRESULT hr;
    g_parent = parent; g_fail = failcb; wcsncpy(g_url, url, 511);
    g_rc.left = x; g_rc.top = y; g_rc.right = x + w; g_rc.bottom = y + h;
    if (g_ctl || g_started) { return 1; }
    if (FAILED(SHGetFolderPathW(NULL, CSIDL_LOCAL_APPDATA, NULL, 0, base))) { fail(L"Could not find a folder for the panel files."); return 0; }
    swprintf(g_root, MAX_PATH, L"%ls\\TypeMyworDz\\TypeScribe", base);
    SHCreateDirectoryExW(NULL, g_root, NULL);
    swprintf(g_hand, MAX_PATH, L"%ls\\handoff", g_root); SHCreateDirectoryExW(NULL, g_hand, NULL);
    swprintf(ud, MAX_PATH, L"%ls\\WebView2", g_root);
    if (!extract_loader(dll)) { fail(L"Could not prepare the embedded browser."); return 0; }
    m = LoadLibraryW(dll);
    fn = m ? (CreateEnvFn)GetProcAddress(m, "CreateCoreWebView2EnvironmentWithOptions") : NULL;
    if (!fn) { fail(L"Could not load the embedded browser."); return 0; }
    hr = fn(NULL, ud, NULL, (ICoreWebView2CreateCoreWebView2EnvironmentCompletedHandler *)&env_obj);
    if (FAILED(hr)) { fail(L"Microsoft Edge WebView2 Runtime was not found."); return 0; }
    return 1;
}

void wp_bounds(int x, int y, int w, int h) {
    g_rc.left = x; g_rc.top = y; g_rc.right = x + w; g_rc.bottom = y + h;
    if (g_ctl) ICoreWebView2Controller_put_Bounds(g_ctl, g_rc);
}
void wp_visible(int on) { g_visible = on; if (g_ctl) ICoreWebView2Controller_put_IsVisible(g_ctl, on ? TRUE : FALSE); }

static void json_escape(const wchar_t *s, wchar_t *o, size_t cap) {
    size_t n = 0;
    for (; *s && n + 8 < cap; s++) {
        if (*s == L'\\' || *s == L'"') { o[n++] = L'\\'; o[n++] = *s; }
        else if (*s < 32) { o[n++] = L' '; }
        else o[n++] = *s;
    }
    o[n] = 0;
}

void wp_send_audio(const wchar_t *path) {
    wchar_t ext[16] = L"mp3", dst[MAX_PATH], nm[300], nj[640], *json; const wchar_t *dot, *base;
    WIN32_FIND_DATAW fd; HANDLE h; size_t cap; static unsigned seq;
    if (!path || !path[0] || !g_hand[0]) return;
    /* clear earlier hand-offs so the folder never fills up */
    swprintf(dst, MAX_PATH, L"%ls\\*", g_hand);
    h = FindFirstFileW(dst, &fd);
    if (h != INVALID_HANDLE_VALUE) {
        do { if (!(fd.dwFileAttributes & FILE_ATTRIBUTE_DIRECTORY)) { swprintf(nm, 300, L"%ls\\%ls", g_hand, fd.cFileName); DeleteFileW(nm); } } while (FindNextFileW(h, &fd));
        FindClose(h);
    }
    dot = wcsrchr(path, L'.');
    if (dot && wcslen(dot) > 1 && wcslen(dot) < 8) wcscpy(ext, dot + 1);
    seq++;
    swprintf(nm, 300, L"audio-%u-%lu.%ls", seq, (unsigned long)GetTickCount(), ext);
    swprintf(dst, MAX_PATH, L"%ls\\%ls", g_hand, nm);
    if (!CopyFileW(path, dst, FALSE)) { fail(L"Could not hand this audio to the panel."); return; }
    base = wcsrchr(path, L'\\'); base = base ? base + 1 : path;
    json_escape(base, nj, 640);
    cap = 1400; json = (wchar_t *)calloc(cap, sizeof(wchar_t));
    if (!json) return;
    swprintf(json, cap, L"{\"type\":\"typescribe-audio\",\"url\":\"https://typescribe.local/%ls\",\"name\":\"%ls\"}", nm, nj);
    free(g_pending); g_pending = json;
    post_pending();
}

void wp_destroy(void) {
    if (g_ctl) { ICoreWebView2Controller_Close(g_ctl); ICoreWebView2Controller_Release(g_ctl); g_ctl = NULL; }
    g_wv = NULL; g_started = 0; g_pageReady = 0;
}

void wp_set_request_cb(wp_req_fn f) { g_reqCb = f; }
void wp_clear(void) {
    free(g_pending); g_pending = NULL; g_pageReady = 0;
    if (g_wv) ICoreWebView2_Navigate(g_wv, g_url);
}
