#ifndef MP3ENC_H
#define MP3ENC_H
typedef int (*mp3_write_fn)(void *ctx, const void *data, int len);
/* Mono, 16-bit. Returns 0 on success. */
int mp3_open(int rate, int kbps);
int mp3_feed(const short *pcm, int n, mp3_write_fn w, void *ctx);
int mp3_close(mp3_write_fn w, void *ctx);
#endif
