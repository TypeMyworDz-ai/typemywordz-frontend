/* Small wrapper around the Shine MP3 encoder (LGPL 2). Mono input. The output
   is a plain stream of MP3 frames, so a file is playable at any moment. */
#include <string.h>
#include "mp3enc.h"
#include "layer3.h"

static shine_t g_s;
static int g_spp;
static short g_acc[1152];
static int g_n;

int mp3_open(int rate, int kbps) {
    shine_config_t c;
    memset(&c, 0, sizeof c);
    shine_set_config_mpeg_defaults(&c.mpeg);
    c.wave.channels = PCM_MONO;
    c.wave.samplerate = rate;
    c.mpeg.mode = MONO;
    c.mpeg.bitr = kbps;
    if (shine_check_config(c.wave.samplerate, c.mpeg.bitr) < 0) return -1;
    g_s = shine_initialise(&c);
    if (!g_s) return -2;
    g_spp = shine_samples_per_pass(g_s);
    if (g_spp > 1152) return -3;
    g_n = 0;
    return 0;
}

static int pass(mp3_write_fn w, void *ctx) {
    int written = 0;
    unsigned char *d = shine_encode_buffer_interleaved(g_s, g_acc, &written);
    g_n = 0;
    if (written > 0 && d) return w(ctx, d, written);
    return 0;
}

int mp3_feed(const short *pcm, int n, mp3_write_fn w, void *ctx) {
    int i, bad = 0;
    if (!g_s) return -1;
    for (i = 0; i < n; i++) {
        g_acc[g_n++] = pcm[i];
        if (g_n == g_spp && pass(w, ctx) < 0) bad = 1;
    }
    return bad ? -1 : 0;
}

int mp3_close(mp3_write_fn w, void *ctx) {
    int written = 0, bad = 0;
    unsigned char *d;
    if (!g_s) return 0;
    if (g_n > 0) {
        while (g_n < g_spp) g_acc[g_n++] = 0;
        if (pass(w, ctx) < 0) bad = 1;
    }
    d = shine_flush(g_s, &written);
    if (written > 0 && d && w(ctx, d, written) < 0) bad = 1;
    shine_close(g_s);
    g_s = 0;
    return bad ? -1 : 0;
}
