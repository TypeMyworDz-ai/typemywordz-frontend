#ifndef PLAYER_H
#define PLAYER_H
#ifndef PLAYER_TEST
#include <windows.h>
#endif
/* Small audio player for the take that was just recorded. MP3 or WAV is read
   into memory once, then played through waveOut with a pitch-preserving speed
   control (50% to 300%) and a software volume (0% to 200%). */
#ifndef PLAYER_TEST
int    pl_load(const wchar_t *path);     /* 0 on success */
void   pl_unload(void);
int    pl_loaded(void);
int    pl_play(void);
void   pl_pause(void);
int    pl_playing(void);
int    pl_ended(void);                   /* reached the end since the last play */
void   pl_seek(double seconds);
double pl_pos(void);
double pl_dur(void);
void   pl_set_volume(double v);          /* 0.0 .. 2.0 */
void   pl_set_speed(double s);           /* 0.5 .. 3.0 */
#endif

/* Time-stretch core, exposed so it can be tested without Windows. */
typedef struct TS TS;
TS    *ts_new(int rate);
void   ts_free(TS *t);
void   ts_reset(TS *t, double pos);
/* Produces exactly n output samples from in[0..len); returns the source
   position (in samples) the stretcher has consumed up to. */
double ts_render(TS *t, const short *in, long len, double speed, short *out, int n);
double ts_pos(const TS *t);
#endif
