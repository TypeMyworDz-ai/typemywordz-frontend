/* TypeMyworDz Recorder for Windows. One small file, no installer, no browser.
   Records the microphone straight to disk as an MP3 (32 kbps by default) or a
   WAV. The file is written as the recording goes, so a crash or a power cut
   never loses the take. MP3 encoding by Shine (LGPL 2.1), see ABOUT file. */
#define UNICODE
#define _UNICODE
#define WINVER 0x0601
#define _WIN32_WINNT 0x0601
#include <windows.h>
#include <mmsystem.h>
#include <shellapi.h>
#include <shlobj.h>
#include <commctrl.h>
#include <stdio.h>
#include <stdlib.h>
#include <math.h>
#include <wchar.h>
#include "mp3enc.h"

#define ID_REC 101
#define ID_PAUSE 102
#define ID_STOP 103
#define ID_MARK 104
#define ID_SKIP 105
#define ID_QUAL 106
#define ID_OVER 107
#define ID_TOP 108
#define ID_SETTINGS 109
#define ID_TIMER_TXT 110
#define ID_STATUS 111
#define ID_MSG 112
#define ID_FOLDER 113
#define ID_WEB 114
#define ID_SHRINK 115
#define ID_FOOT 116
#define ID_DIR 117
#define ID_NAME 118
#define ID_DIRTXT 119
#define ID_SIZE 120
#define ID_HOTKEY_CHANGE 121
#define ID_HOTKEY_DEFAULT 122
#define HOTKEY_REC 1
#define TIMER_UI 1
#define NBUF 4
#ifndef MOD_NOREPEAT
#define MOD_NOREPEAT 0x4000
#endif
#define DEFAULT_HOTKEY_VK 'R'
#define DEFAULT_HOTKEY_MODS (MOD_CONTROL | MOD_SHIFT)
#define PW_X 30
#define PW_Y 82
#define PW_W 320
#define PW_H 52
#define RECORDER_VERSION L"1.4"
#define WINSTYLE (WS_OVERLAPPED | WS_CAPTION | WS_SYSMENU | WS_MINIMIZEBOX)

enum { S_IDLE, S_REC, S_PAUSED };

static const struct { const wchar_t *label; int kbps; int rate; } FMT[] = {
    { L"MP3 32 kbps, smallest (default)", 32, 22050 },
    { L"MP3 48 kbps", 48, 22050 },
    { L"MP3 64 kbps", 64, 22050 },
    { L"MP3 96 kbps, high quality", 96, 44100 },
    { L"MP3 128 kbps, best quality", 128, 44100 },
    { L"WAV, lossless (very large files)", 0, 44100 },
};
#define NFMT 6

static HINSTANCE g_inst;
static HWND g_wnd, g_timer, g_status, g_msg, g_skip, g_qual, g_over, g_top, g_name, g_lblName, g_lblQ, g_lblDir, g_dirTxt, g_btnSet, g_btnDir, g_foot, g_btn[9];
static HWND g_lblHotkey, g_hotkeyValue, g_hotkeyNote;
static HFONT g_font, g_fontBig, g_fontSmall;
static HBRUSH g_white;
static int g_state = S_IDLE, g_showSet = 0, g_fmt = 0, g_isMp3 = 1;
static double g_scale = 1.0, g_dpi = 1.0;
static int g_zoom = 100, g_hotkeyOk = 0, g_hotkeyCapturing = 0;
static UINT g_hotkeyVk = DEFAULT_HOTKEY_VK, g_hotkeyMods = DEFAULT_HOTKEY_MODS;
static double g_fontScale = 1.0;
static HWND g_lblSize, g_size;
static const struct { const wchar_t *label; int pct; } ZOOMS[] = {
    { L"50%", 50 }, { L"60%", 60 }, { L"70%", 70 }, { L"80%", 80 },
    { L"90%", 90 }, { L"100%", 100 }, { L"110%", 110 }, { L"120%", 120 },
    { L"130%", 130 }, { L"140%", 140 }, { L"150%", 150 },
};
#define NZOOM 11
static HWAVEIN g_in;
static WAVEHDR g_hdr[NBUF];
static char *g_buf[NBUF];
static int g_rate = 22050;
static HANDLE g_file = INVALID_HANDLE_VALUE;
static DWORD g_dataBytes = 0;
static int g_peak = 0, g_silentMs = 0, g_bufCount = 0, g_maxPeak = 0;
static double g_marks[512];
static int g_nmarks = 0;
static wchar_t g_path[MAX_PATH], g_marksPath[MAX_PATH], g_dir[MAX_PATH], g_lastTime[32];
static int g_hasTake = 0;

#define S(x) ((int)((x) * g_scale + 0.5))
#define F(x) ((int)((x) * g_fontScale + 0.5))
#define REGKEY L"Software\\TypeMyworDz\\Recorder"

/* ---- settings kept in the current user's registry ---- */
static void reg_set_dw(const wchar_t *n, DWORD v) {
    HKEY k;
    if (RegCreateKeyExW(HKEY_CURRENT_USER, REGKEY, 0, NULL, 0, KEY_SET_VALUE, NULL, &k, NULL) == ERROR_SUCCESS) {
        RegSetValueExW(k, n, 0, REG_DWORD, (const BYTE *)&v, 4); RegCloseKey(k);
    }
}
static void reg_set_sz(const wchar_t *n, const wchar_t *v) {
    HKEY k;
    if (RegCreateKeyExW(HKEY_CURRENT_USER, REGKEY, 0, NULL, 0, KEY_SET_VALUE, NULL, &k, NULL) == ERROR_SUCCESS) {
        RegSetValueExW(k, n, 0, REG_SZ, (const BYTE *)v, (DWORD)((wcslen(v) + 1) * sizeof(wchar_t))); RegCloseKey(k);
    }
}
static DWORD reg_get_dw(const wchar_t *n, DWORD def) {
    HKEY k; DWORD v = def, sz = 4, t = 0;
    if (RegOpenKeyExW(HKEY_CURRENT_USER, REGKEY, 0, KEY_QUERY_VALUE, &k) == ERROR_SUCCESS) {
        if (RegQueryValueExW(k, n, NULL, &t, (BYTE *)&v, &sz) != ERROR_SUCCESS || t != REG_DWORD) v = def;
        RegCloseKey(k);
    }
    return v;
}
static int reg_get_sz(const wchar_t *n, wchar_t *out, DWORD cch) {
    HKEY k; DWORD sz = cch * sizeof(wchar_t), t = 0; int ok = 0;
    if (RegOpenKeyExW(HKEY_CURRENT_USER, REGKEY, 0, KEY_QUERY_VALUE, &k) == ERROR_SUCCESS) {
        if (RegQueryValueExW(k, n, NULL, &t, (BYTE *)out, &sz) == ERROR_SUCCESS && t == REG_SZ && out[0]) ok = 1;
        RegCloseKey(k);
    }
    return ok;
}
static void save_settings(void) {
    reg_set_dw(L"Format", (DWORD)SendMessageW(g_qual, CB_GETCURSEL, 0, 0));
    reg_set_dw(L"OnTop", SendMessageW(g_top, BM_GETCHECK, 0, 0) == BST_CHECKED);
    reg_set_dw(L"Replace", SendMessageW(g_over, BM_GETCHECK, 0, 0) == BST_CHECKED);
    reg_set_dw(L"SkipSilence", SendMessageW(g_skip, BM_GETCHECK, 0, 0) == BST_CHECKED);
    reg_set_dw(L"Zoom", (DWORD)g_zoom);
    reg_set_dw(L"HotkeyKey", g_hotkeyVk);
    reg_set_dw(L"HotkeyMods", g_hotkeyMods);
    reg_set_sz(L"Folder", g_dir);
}

/* ---- WAV helpers ---- */
static void put32(unsigned char *p, DWORD v) { p[0] = v; p[1] = v >> 8; p[2] = v >> 16; p[3] = v >> 24; }
static void put16(unsigned char *p, WORD v) { p[0] = v; p[1] = v >> 8; }

static void write_header(HANDLE h, int rate, DWORD data) {
    unsigned char hd[44];
    memcpy(hd, "RIFF", 4); put32(hd + 4, 36 + data); memcpy(hd + 8, "WAVEfmt ", 8);
    put32(hd + 16, 16); put16(hd + 20, 1); put16(hd + 22, 1); put32(hd + 24, rate);
    put32(hd + 28, rate * 2); put16(hd + 32, 2); put16(hd + 34, 16);
    memcpy(hd + 36, "data", 4); put32(hd + 40, data);
    DWORD w; LARGE_INTEGER z; z.QuadPart = 0;
    SetFilePointerEx(h, z, NULL, FILE_BEGIN);
    WriteFile(h, hd, 44, &w, NULL);
    z.QuadPart = 0; SetFilePointerEx(h, z, NULL, FILE_END);
}

static int file_write(void *ctx, const void *d, int n) {
    DWORD w = 0; (void)ctx;
    if (g_file == INVALID_HANDLE_VALUE) return -1;
    return (WriteFile(g_file, d, n, &w, NULL) && (int)w == n) ? 0 : -1;
}

static double elapsed(void) { return (double)g_dataBytes / (g_rate * 2.0); }

static void fmt_time(double s, wchar_t *out, size_t n) {
    int t = (int)s, h = t / 3600, m = (t % 3600) / 60, x = t % 60;
    if (h) swprintf(out, n, L"%d:%02d:%02d", h, m, x); else swprintf(out, n, L"%02d:%02d", m, x);
}

static void set_status(const wchar_t *t) { SetWindowTextW(g_status, t); }
static void set_msg(const wchar_t *t) { SetWindowTextW(g_msg, t); }

static int is_modifier_vk(UINT vk) {
    return vk == VK_SHIFT || vk == VK_CONTROL || vk == VK_MENU ||
        vk == VK_LSHIFT || vk == VK_RSHIFT || vk == VK_LCONTROL || vk == VK_RCONTROL ||
        vk == VK_LMENU || vk == VK_RMENU || vk == VK_LWIN || vk == VK_RWIN;
}

static int hotkey_is_valid(UINT vk, UINT mods) {
    const UINT allowed = MOD_ALT | MOD_CONTROL | MOD_SHIFT | MOD_WIN;
    if (!vk || vk > 0xFF || (mods & ~allowed) || is_modifier_vk(vk)) return 0;
    if (vk == VK_CAPITAL || vk == VK_NUMLOCK || vk == VK_SCROLL || vk == VK_F12) return 0;
    if (mods & MOD_WIN) return 0;
    if (vk == VK_TAB && mods != 0) return 0;
    if ((mods & MOD_ALT) && (vk == VK_TAB || vk == VK_F4 || vk == VK_ESCAPE || vk == VK_SPACE)) return 0;
    if ((mods & MOD_CONTROL) && (vk == VK_ESCAPE || vk == VK_TAB || vk == VK_F4)) return 0;
    if ((mods & MOD_CONTROL) && (mods & MOD_SHIFT) && vk == VK_ESCAPE) return 0;
    if ((mods & MOD_CONTROL) && (mods & MOD_ALT) && vk == VK_DELETE) return 0;
    return 1;
}

static UINT pressed_hotkey_mods(void) {
    UINT mods = 0;
    if (GetKeyState(VK_CONTROL) & 0x8000) mods |= MOD_CONTROL;
    if (GetKeyState(VK_SHIFT) & 0x8000) mods |= MOD_SHIFT;
    if (GetKeyState(VK_MENU) & 0x8000) mods |= MOD_ALT;
    if ((GetKeyState(VK_LWIN) & 0x8000) || (GetKeyState(VK_RWIN) & 0x8000)) mods |= MOD_WIN;
    return mods;
}

static void append_hotkey_text(wchar_t *out, size_t cap, const wchar_t *text) {
    size_t used = wcslen(out);
    if (used < cap - 1) wcsncat(out, text, cap - used - 1);
}

static void format_hotkey(UINT mods, UINT vk, wchar_t *out, size_t cap) {
    wchar_t key[64] = L"";
    UINT scan = MapVirtualKeyW(vk, MAPVK_VK_TO_VSC);
    LPARAM key_info = (LPARAM)scan << 16;
    if (vk == VK_INSERT || vk == VK_DELETE || vk == VK_HOME || vk == VK_END ||
        vk == VK_PRIOR || vk == VK_NEXT || vk == VK_LEFT || vk == VK_RIGHT ||
        vk == VK_UP || vk == VK_DOWN || vk == VK_NUMLOCK) key_info |= (LPARAM)1 << 24;
    out[0] = 0;
    if (mods & MOD_CONTROL) append_hotkey_text(out, cap, L"Ctrl+");
    if (mods & MOD_ALT) append_hotkey_text(out, cap, L"Alt+");
    if (mods & MOD_SHIFT) append_hotkey_text(out, cap, L"Shift+");
    if (mods & MOD_WIN) append_hotkey_text(out, cap, L"Win+");
    if (!GetKeyNameTextW((LONG)key_info, key, 64)) swprintf(key, 64, L"Key %u", vk);
    append_hotkey_text(out, cap, key);
}

static int register_global_hotkey(UINT mods, UINT vk) {
    return RegisterHotKey(g_wnd, HOTKEY_REC, mods | MOD_NOREPEAT, vk) != 0;
}

static void update_hotkey_controls(void) {
    wchar_t label[128], foot[256];
    format_hotkey(g_hotkeyMods, g_hotkeyVk, label, 128);
    if (g_hotkeyValue) SetWindowTextW(g_hotkeyValue, g_hotkeyCapturing ? L"Press a key; Esc cancels" : label);
    if (g_btn[7]) { SetWindowTextW(g_btn[7], g_hotkeyCapturing ? L"Cancel" : L"Change"); InvalidateRect(g_btn[7], NULL, TRUE); }
    if (g_btn[8]) InvalidateRect(g_btn[8], NULL, TRUE);
    if (g_foot) {
        swprintf(foot, 256, L"Version %ls  |  %ls works from any window.", RECORDER_VERSION, label);
        SetWindowTextW(g_foot, foot);
    }
}

static void update_ready_status(void) {
    wchar_t label[128], msg[200];
    if (g_state != S_IDLE) return;
    if (!g_hotkeyOk) { set_status(L"Global shortcut unavailable; open Settings to choose another"); return; }
    format_hotkey(g_hotkeyMods, g_hotkeyVk, label, 128);
    swprintf(msg, 200, L"Ready to record  (%ls)", label);
    set_status(msg);
}

static void restore_current_hotkey(void) {
    if (g_hotkeyOk) UnregisterHotKey(g_wnd, HOTKEY_REC);
    g_hotkeyOk = register_global_hotkey(g_hotkeyMods, g_hotkeyVk);
    update_hotkey_controls();
    update_ready_status();
}

static int apply_hotkey(UINT vk, UINT mods) {
    wchar_t label[128], prompt[320];
    int had_old = g_hotkeyOk;
    UINT old_vk = g_hotkeyVk, old_mods = g_hotkeyMods;
    if (!hotkey_is_valid(vk, mods)) {
        if (!had_old) restore_current_hotkey();
        if (g_state == S_IDLE) set_status(L"Windows reserves that shortcut. Choose another.");
        update_hotkey_controls();
        return 0;
    }
    if (mods == 0) {
        format_hotkey(mods, vk, label, 128);
        swprintf(prompt, 320, L"%ls has no modifier key. While the recorder is open, Windows will capture it across apps. Tab may no longer move focus normally.\n\nUse this single-key shortcut?", label);
        if (MessageBoxW(g_wnd, prompt, L"Confirm global shortcut", MB_YESNO | MB_ICONWARNING | MB_DEFBUTTON2) != IDYES) {
            restore_current_hotkey();
            if (g_state == S_IDLE) set_status(L"Shortcut unchanged.");
            return 0;
        }
    }

    if (had_old) UnregisterHotKey(g_wnd, HOTKEY_REC);
    g_hotkeyOk = 0;
    if (register_global_hotkey(mods, vk)) {
        g_hotkeyVk = vk; g_hotkeyMods = mods; g_hotkeyOk = 1;
        reg_set_dw(L"HotkeyKey", g_hotkeyVk);
        reg_set_dw(L"HotkeyMods", g_hotkeyMods);
        update_hotkey_controls();
        update_ready_status();
        return 1;
    }

    g_hotkeyOk = register_global_hotkey(old_mods, old_vk);
    g_hotkeyVk = old_vk; g_hotkeyMods = old_mods;
    update_hotkey_controls();
    if (g_state == S_IDLE) set_status(g_hotkeyOk ? L"Windows could not reserve that shortcut; the previous one remains." : L"Neither shortcut is available. Open Settings or use Record.");
    return 0;
}

static void cancel_hotkey_capture(void) {
    if (!g_hotkeyCapturing) return;
    g_hotkeyCapturing = 0;
    restore_current_hotkey();
    if (g_state == S_IDLE) set_status(L"Shortcut change cancelled.");
}

static void finish_hotkey_capture(UINT vk, UINT mods) {
    g_hotkeyCapturing = 0;
    if (!hotkey_is_valid(vk, mods)) {
        restore_current_hotkey();
        if (g_state == S_IDLE) set_status(L"Windows reserves that shortcut. Choose another.");
        return;
    }
    apply_hotkey(vk, mods);
}

static void begin_hotkey_capture(void) {
    if (g_hotkeyCapturing) { cancel_hotkey_capture(); return; }
    if (g_hotkeyOk) UnregisterHotKey(g_wnd, HOTKEY_REC);
    g_hotkeyOk = 0;
    g_hotkeyCapturing = 1;
    update_hotkey_controls();
    set_status(L"Press your record/stop shortcut now. Press Esc to cancel.");
    SetFocus(g_wnd);
}

/* ---- layout: controls are placed from the top so the window grows and
   shrinks with what is showing ---- */
static void place(HWND c, int x, int y, int w, int h, int show) {
    SetWindowPos(c, NULL, S(x), S(y), S(w), S(h), SWP_NOZORDER | SWP_NOACTIVATE | (show ? SWP_SHOWWINDOW : SWP_HIDEWINDOW));
}

static void layout(void) {
    int y = 260, open = g_showSet, tk = (g_state == S_IDLE && g_hasTake);
    place(g_timer, 0, 8, 380, 50, 1);
    place(g_status, 0, 58, 380, 20, 1);
    place(g_btn[0], 30, 145, 74, 36, 1);
    place(g_btn[1], 112, 145, 74, 36, 1);
    place(g_btn[2], 194, 145, 74, 36, 1);
    place(g_btn[3], 276, 145, 74, 36, 1);
    place(g_lblName, 30, 190, 66, 24, 1);
    place(g_name, 100, 188, 250, 26, 1);
    place(g_btnSet, 30, 222, 150, 28, 1);
    if (open) {
        place(g_over, 30, y, 320, 22, 1); y += 27;
        place(g_skip, 30, y, 320, 22, 1); y += 27;
        place(g_top, 30, y, 320, 22, 1); y += 28;
        place(g_lblHotkey, 30, y, 320, 18, 1); y += 19;
        place(g_hotkeyValue, 30, y + 2, 145, 24, 1);
        place(g_btn[7], 180, y, 75, 28, 1);
        place(g_btn[8], 265, y, 85, 28, 1); y += 31;
        place(g_hotkeyNote, 30, y, 320, 52, 1); y += 55;
        place(g_lblQ, 30, y + 4, 68, 20, 1);
        place(g_qual, 100, y, 250, 28, 1); y += 34;
        place(g_lblSize, 30, y + 4, 88, 20, 1);
        place(g_size, 124, y, 226, 28, 1); y += 34;
        place(g_lblDir, 30, y, 320, 18, 1); y += 20;
        place(g_dirTxt, 30, y, 320, 24, 1); y += 27;
        place(g_btnDir, 30, y, 170, 28, 1); y += 34;
        place(g_btn[5], 30, y, 154, 28, tk); place(g_btn[6], 196, y, 154, 28, tk); if (tk) y += 34;
        place(g_foot, 30, y, 320, 30, 1); y += 34;
    } else {
        place(g_over, 0, 0, 1, 1, 0); place(g_skip, 0, 0, 1, 1, 0); place(g_top, 0, 0, 1, 1, 0);
        place(g_lblHotkey, 0, 0, 1, 1, 0); place(g_hotkeyValue, 0, 0, 1, 1, 0); place(g_hotkeyNote, 0, 0, 1, 1, 0);
        place(g_btn[7], 0, 0, 1, 1, 0); place(g_btn[8], 0, 0, 1, 1, 0);
        place(g_lblQ, 0, 0, 1, 1, 0); place(g_qual, 0, 0, 1, 1, 0);
        place(g_lblSize, 0, 0, 1, 1, 0); place(g_size, 0, 0, 1, 1, 0);
        place(g_lblDir, 0, 0, 1, 1, 0); place(g_dirTxt, 0, 0, 1, 1, 0); place(g_btnDir, 0, 0, 1, 1, 0);
        place(g_btn[5], 0, 0, 1, 1, 0); place(g_btn[6], 0, 0, 1, 1, 0); place(g_foot, 0, 0, 1, 1, 0);
    }
    place(g_msg, 30, y, 320, 38, 1); y += 42;
    place(g_btn[4], 30, y, 320, 82, 1); y += 90;
    RECT r = { 0, 0, S(380), S(y) };
    AdjustWindowRect(&r, WINSTYLE, FALSE);
    SetWindowPos(g_wnd, NULL, 0, 0, r.right - r.left, r.bottom - r.top, SWP_NOMOVE | SWP_NOZORDER | SWP_NOACTIVATE);
    InvalidateRect(g_wnd, NULL, TRUE);
}

static void update_buttons(void) {
    int rec = g_state == S_REC, pau = g_state == S_PAUSED, idle = g_state == S_IDLE;
    EnableWindow(g_btn[0], idle);
    EnableWindow(g_btn[1], rec || pau);
    EnableWindow(g_btn[2], rec || pau);
    EnableWindow(g_btn[3], rec);
    EnableWindow(g_qual, idle);
    EnableWindow(g_name, idle);
    EnableWindow(g_over, idle);
    EnableWindow(g_btnDir, idle);
    SetWindowTextW(g_btn[1], pau ? L"Resume" : L"Pause");
    SetWindowTextW(g_btnSet, g_showSet ? L"Settings  \u25B4" : L"Settings  \u25BE");
    layout();
}

static void process_hdr(WAVEHDR *h) {
    if (h->dwUser || !(h->dwFlags & WHDR_DONE) || h->dwBytesRecorded == 0) { return; }
    h->dwUser = 1;
    short *s = (short *)h->lpData; int n = h->dwBytesRecorded / 2, pk = 0, i;
    for (i = 0; i < n; i++) { int v = s[i] < 0 ? -s[i] : s[i]; if (v > pk) pk = v; }
    g_peak = pk; if (pk > g_maxPeak) g_maxPeak = pk;
    int ms = (int)((double)n * 1000.0 / g_rate), keep = 1;
    if (SendMessageW(g_skip, BM_GETCHECK, 0, 0) == BST_CHECKED) {
        if (pk < 450) { g_silentMs += ms; if (g_silentMs > 1500) keep = 0; } else g_silentMs = 0;
    } else g_silentMs = 0;
    if (keep && g_file != INVALID_HANDLE_VALUE) {
        if (g_isMp3) {
            mp3_feed(s, n, file_write, NULL);
        } else {
            DWORD w; WriteFile(g_file, h->lpData, h->dwBytesRecorded, &w, NULL);
            if (++g_bufCount % 30 == 0) write_header(g_file, g_rate, g_dataBytes + h->dwBytesRecorded);
        }
        g_dataBytes += h->dwBytesRecorded;
    }
}

static void close_input(void) {
    int i;
    if (g_in) {
        waveInStop(g_in);
        for (i = 0; i < NBUF; i++) process_hdr(&g_hdr[i]);
        waveInReset(g_in);
        for (i = 0; i < NBUF; i++) { waveInUnprepareHeader(g_in, &g_hdr[i], sizeof(WAVEHDR)); }
        waveInClose(g_in); g_in = NULL;
    }
    for (i = 0; i < NBUF; i++) { free(g_buf[i]); g_buf[i] = NULL; }
}

/* Builds the file name from the name box. Empty means date and time. An
   existing name gets (2), (3) ... unless "replace" is ticked. */
static void make_paths(wchar_t *base, size_t cap) {
    wchar_t name[200]; SYSTEMTIME t; size_t n, i, j = 0;
    const wchar_t *ext = g_isMp3 ? L"mp3" : L"wav";
    GetWindowTextW(g_name, name, 200);
    wchar_t clean[200];
    for (i = 0; name[i] && j < 150; i++) {
        wchar_t c = name[i];
        if (c < 32 || wcschr(L"\\/:*?\"<>|", c)) c = L'-';
        clean[j++] = c;
    }
    clean[j] = 0;
    for (;;) {
        n = wcslen(clean);
        if (n && (clean[n - 1] == L' ' || clean[n - 1] == L'.')) clean[n - 1] = 0; else break;
    }
    n = wcslen(clean);
    if (n > 4 && (_wcsicmp(clean + n - 4, L".mp3") == 0 || _wcsicmp(clean + n - 4, L".wav") == 0)) clean[n - 4] = 0;
    for (i = 0; clean[i] == L' '; i++) {}
    if (i) memmove(clean, clean + i, (wcslen(clean + i) + 1) * sizeof(wchar_t));
    if (!clean[0]) {
        GetLocalTime(&t);
        swprintf(clean, 200, L"recording-%04d%02d%02d-%02d%02d%02d", t.wYear, t.wMonth, t.wDay, t.wHour, t.wMinute, t.wSecond);
    }
    swprintf(base, cap, L"%ls", clean);
    swprintf(g_path, MAX_PATH, L"%ls\\%ls.%ls", g_dir, base, ext);
    if (SendMessageW(g_over, BM_GETCHECK, 0, 0) != BST_CHECKED) {
        int k = 2;
        while (GetFileAttributesW(g_path) != INVALID_FILE_ATTRIBUTES && k < 1000) {
            swprintf(base, cap, L"%ls (%d)", clean, k);
            swprintf(g_path, MAX_PATH, L"%ls\\%ls.%ls", g_dir, base, ext);
            k++;
        }
    }
    swprintf(g_marksPath, MAX_PATH, L"%ls\\%ls-marks.txt", g_dir, base);
}

static void start_recording(void) {
    int i, sel = (int)SendMessageW(g_qual, CB_GETCURSEL, 0, 0);
    wchar_t base[260];
    if (sel < 0 || sel >= NFMT) sel = 0;
    g_fmt = sel; g_isMp3 = FMT[sel].kbps > 0; g_rate = FMT[sel].rate;
    WAVEFORMATEX wf; ZeroMemory(&wf, sizeof wf);
    wf.wFormatTag = WAVE_FORMAT_PCM; wf.nChannels = 1; wf.nSamplesPerSec = g_rate; wf.wBitsPerSample = 16;
    wf.nBlockAlign = 2; wf.nAvgBytesPerSec = g_rate * 2;
    if (waveInOpen(&g_in, WAVE_MAPPER, &wf, (DWORD_PTR)g_wnd, 0, CALLBACK_WINDOW) != MMSYSERR_NOERROR) {
        g_in = NULL;
        set_status(L"No microphone found");
        set_msg(L"Plug in or enable a microphone in Windows sound settings, then press Record again.");
        return;
    }
    CreateDirectoryW(g_dir, NULL);
    make_paths(base, 260);
    {
        int over = SendMessageW(g_over, BM_GETCHECK, 0, 0) == BST_CHECKED;
        g_file = CreateFileW(g_path, GENERIC_WRITE, FILE_SHARE_READ, NULL, over ? CREATE_ALWAYS : CREATE_NEW, FILE_ATTRIBUTE_NORMAL, NULL);
    }
    if (g_file == INVALID_HANDLE_VALUE) {
        waveInClose(g_in); g_in = NULL;
        set_status(L"Could not create the file");
        set_msg(L"Windows would not let the recorder write there. Open Settings and choose another folder, or close any program using a file with the same name.");
        return;
    }
    if (g_isMp3 && mp3_open(g_rate, FMT[sel].kbps) != 0) {
        CloseHandle(g_file); g_file = INVALID_HANDLE_VALUE; DeleteFileW(g_path);
        waveInClose(g_in); g_in = NULL;
        set_status(L"Could not start the MP3 encoder");
        set_msg(L"Choose WAV in Settings and try again.");
        return;
    }
    g_dataBytes = 0; g_silentMs = 0; g_bufCount = 0; g_nmarks = 0; g_peak = 0; g_maxPeak = 0;
    if (!g_isMp3) write_header(g_file, g_rate, 0);
    DWORD size = g_rate * 2 / 10;
    for (i = 0; i < NBUF; i++) {
        g_buf[i] = (char *)calloc(1, size);
        ZeroMemory(&g_hdr[i], sizeof(WAVEHDR));
        g_hdr[i].lpData = g_buf[i]; g_hdr[i].dwBufferLength = size;
        waveInPrepareHeader(g_in, &g_hdr[i], sizeof(WAVEHDR));
        waveInAddBuffer(g_in, &g_hdr[i], sizeof(WAVEHDR));
    }
    waveInStart(g_in);
    g_state = S_REC; g_hasTake = 0;
    set_status(L"Recording"); set_msg(L"Saving as you go. If anything goes wrong, your recording is already on disk.");
    SetTimer(g_wnd, TIMER_UI, 70, NULL);
    save_settings();
    update_buttons();
}

static void pause_toggle(void) {
    int i;
    if (g_state == S_REC) {
        waveInStop(g_in); g_state = S_PAUSED; set_status(L"Paused");
    } else if (g_state == S_PAUSED) {
        for (i = 0; i < NBUF; i++) {
            if (g_hdr[i].dwFlags & WHDR_DONE) { g_hdr[i].dwUser = 0; g_hdr[i].dwBytesRecorded = 0; waveInAddBuffer(g_in, &g_hdr[i], sizeof(WAVEHDR)); }
        }
        waveInStart(g_in); g_state = S_REC; set_status(L"Recording");
    }
    update_buttons();
}

static void add_mark(void) {
    wchar_t t[32], s[96];
    if (g_nmarks < 512) g_marks[g_nmarks++] = elapsed();
    fmt_time(elapsed(), t, 32);
    swprintf(s, 96, L"Recording. Mark %d added at %ls", g_nmarks, t);
    set_status(s);
}

static void stop_recording(void) {
    wchar_t t[32], m[MAX_PATH + 160];
    close_input();
    KillTimer(g_wnd, TIMER_UI);
    if (g_file != INVALID_HANDLE_VALUE) {
        if (g_isMp3) mp3_close(file_write, NULL); else write_header(g_file, g_rate, g_dataBytes);
        CloseHandle(g_file); g_file = INVALID_HANDLE_VALUE;
    }
    g_state = S_IDLE; g_peak = 0;
    if (g_dataBytes < 4000) {
        DeleteFileW(g_path); g_hasTake = 0;
        set_status(L"Nothing was recorded"); set_msg(L"The recording was empty, so no file was kept. Check your microphone and try again.");
    } else {
        double mb = 0; WIN32_FILE_ATTRIBUTE_DATA fa;
        g_hasTake = 1;
        if (GetFileAttributesExW(g_path, GetFileExInfoStandard, &fa)) mb = ((double)fa.nFileSizeHigh * 4294967296.0 + fa.nFileSizeLow) / 1048576.0;
        if (g_nmarks > 0) {
            HANDLE h = CreateFileW(g_marksPath, GENERIC_WRITE, 0, NULL, CREATE_ALWAYS, FILE_ATTRIBUTE_NORMAL, NULL);
            if (h != INVALID_HANDLE_VALUE) {
                int i; char line[64]; DWORD w;
                for (i = 0; i < g_nmarks; i++) { int sec = (int)g_marks[i]; int n = sprintf(line, "Mark %d  %02d:%02d\r\n", i + 1, sec / 60, sec % 60); WriteFile(h, line, n, &w, NULL); }
                CloseHandle(h);
            }
        }
        fmt_time(elapsed(), t, 32);
        swprintf(m, MAX_PATH + 160, L"Saved (%ls, %.1f MB) to:\r\n%ls\r\nNext: press \"Transcribe on TypeMyworDz\" and choose this file there.", t, mb, g_path);
        set_status(L"Done and saved"); set_msg(m);
        if (g_maxPeak < 60) {
            set_status(L"Saved, but no sound was picked up");
            set_msg(L"The recording is silent. In Windows go to Settings, Privacy, Microphone and switch on \"Let desktop apps access your microphone\", then record again.");
        }
    }
    InvalidateRect(g_wnd, NULL, FALSE);
    update_buttons();
}

static void open_url(const wchar_t *u) { ShellExecuteW(NULL, L"open", u, NULL, NULL, SW_SHOWNORMAL); }

static void choose_folder(void) {
    BROWSEINFOW bi; PIDLIST_ABSOLUTE pid;
    ZeroMemory(&bi, sizeof bi);
    bi.hwndOwner = g_wnd; bi.lpszTitle = L"Choose where your recordings are saved";
    bi.ulFlags = BIF_RETURNONLYFSDIRS | BIF_NEWDIALOGSTYLE;
    pid = SHBrowseForFolderW(&bi);
    if (pid) {
        wchar_t p[MAX_PATH];
        if (SHGetPathFromIDListW(pid, p) && p[0]) { wcscpy(g_dir, p); SetWindowTextW(g_dirTxt, g_dir); save_settings(); }
        CoTaskMemFree(pid);
    }
}

static void draw_button(DRAWITEMSTRUCT *d) {
    int id = (int)d->CtlID;
    if (id == ID_WEB) {
        HBRUSH bb = CreateSolidBrush(RGB(91, 68, 207)); HPEN bp = CreatePen(PS_SOLID, 1, RGB(91, 68, 207));
        HGDIOBJ ob0 = SelectObject(d->hDC, bb), op0 = SelectObject(d->hDC, bp);
        RoundRect(d->hDC, d->rcItem.left, d->rcItem.top, d->rcItem.right, d->rcItem.bottom, S(14), S(14));
        SelectObject(d->hDC, ob0); SelectObject(d->hDC, op0); DeleteObject(bb); DeleteObject(bp);
        int cs = S(34), cx = d->rcItem.right - S(14) - cs, cy = (d->rcItem.top + d->rcItem.bottom - cs) / 2;
        HBRUSH gb = CreateSolidBrush(RGB(40, 167, 69)); HPEN gp = CreatePen(PS_SOLID, 1, RGB(40, 167, 69));
        ob0 = SelectObject(d->hDC, gb); op0 = SelectObject(d->hDC, gp);
        Ellipse(d->hDC, cx, cy, cx + cs, cy + cs);
        SelectObject(d->hDC, ob0); SelectObject(d->hDC, op0); DeleteObject(gb); DeleteObject(gp);
        SetBkMode(d->hDC, TRANSPARENT); SetTextColor(d->hDC, RGB(255, 255, 255));
        HGDIOBJ of0 = SelectObject(d->hDC, g_font);
        RECT ar = { cx, cy, cx + cs, cy + cs };
        DrawTextW(d->hDC, L"\u2192", -1, &ar, DT_CENTER | DT_VCENTER | DT_SINGLELINE);
        RECT t1 = { d->rcItem.left + S(16), d->rcItem.top + S(9), cx - S(8), d->rcItem.top + S(36) };
        DrawTextW(d->hDC, L"Transcribe on TypeMyworDz", -1, &t1, DT_LEFT | DT_VCENTER | DT_SINGLELINE);
        SelectObject(d->hDC, g_fontSmall); SetTextColor(d->hDC, RGB(240, 238, 250));
        RECT t2 = { d->rcItem.left + S(16), d->rcItem.top + S(36), cx - S(8), d->rcItem.bottom - S(7) };
        DrawTextW(d->hDC, L"Upload this file for an accurate, editable transcript.", -1, &t2, DT_LEFT | DT_WORDBREAK);
        SelectObject(d->hDC, of0);
        if (d->itemState & ODS_FOCUS) { RECT fr = d->rcItem; InflateRect(&fr, -S(4), -S(4)); DrawFocusRect(d->hDC, &fr); }
        return;
    }
    int disabled = (d->itemState & ODS_DISABLED) != 0, down = (d->itemState & ODS_SELECTED) != 0;
    COLORREF fill = RGB(255, 255, 255), border = RGB(91, 68, 207), text = RGB(91, 68, 207);
    if (id == ID_REC || id == ID_WEB) { fill = RGB(40, 167, 69); border = fill; text = RGB(255, 255, 255); }
    else if (id == ID_STOP) { fill = RGB(20, 22, 26); border = fill; text = RGB(255, 255, 255); }
    if (down && !disabled) { if (fill == RGB(255, 255, 255)) fill = RGB(238, 235, 252); else fill = RGB(GetRValue(fill) * 85 / 100, GetGValue(fill) * 85 / 100, GetBValue(fill) * 85 / 100); }
    if (disabled) { fill = (fill == RGB(255, 255, 255)) ? RGB(255, 255, 255) : RGB(190, 192, 198); border = RGB(209, 205, 238); text = (text == RGB(255, 255, 255)) ? RGB(255, 255, 255) : RGB(190, 186, 224); }
    HBRUSH b = CreateSolidBrush(fill); HPEN p = CreatePen(PS_SOLID, 1, border);
    HGDIOBJ ob = SelectObject(d->hDC, b), op = SelectObject(d->hDC, p);
    RoundRect(d->hDC, d->rcItem.left, d->rcItem.top, d->rcItem.right, d->rcItem.bottom, S(10), S(10));
    SelectObject(d->hDC, ob); SelectObject(d->hDC, op); DeleteObject(b); DeleteObject(p);
    wchar_t t[64]; GetWindowTextW(d->hwndItem, t, 64);
    SetBkMode(d->hDC, TRANSPARENT); SetTextColor(d->hDC, text);
    HGDIOBJ of = SelectObject(d->hDC, g_font);
    DrawTextW(d->hDC, t, -1, &d->rcItem, DT_CENTER | DT_VCENTER | DT_SINGLELINE);
    SelectObject(d->hDC, of);
}

/* The wave bars: the same bars, spacing and purple as the TypeMyworDz web app,
   drawn off screen and copied over so they never flicker. */
static void grad(HDC dc, int x, int y1, int y2, COLORREF a, COLORREF b) {
    TRIVERTEX v[2]; GRADIENT_RECT gr = { 0, 1 };
    v[0].x = x; v[0].y = y1; v[0].Red = GetRValue(a) << 8; v[0].Green = GetGValue(a) << 8; v[0].Blue = GetBValue(a) << 8; v[0].Alpha = 0;
    v[1].x = x + S(3); v[1].y = y2; v[1].Red = GetRValue(b) << 8; v[1].Green = GetGValue(b) << 8; v[1].Blue = GetBValue(b) << 8; v[1].Alpha = 0;
    GradientFill(dc, v, 2, &gr, 1, GRADIENT_FILL_RECT_V);
}

static void draw_wave(HDC dc) {
    int w = S(PW_W), h = S(PW_H), i;
    HDC m = CreateCompatibleDC(dc);
    HBITMAP bm = CreateCompatibleBitmap(dc, w, h);
    HGDIOBJ obm = SelectObject(m, bm);
    HBRUSH bg = CreateSolidBrush(RGB(247, 245, 253)); HPEN pen = CreatePen(PS_SOLID, 1, RGB(232, 229, 246)), bl = CreatePen(PS_SOLID, 1, RGB(228, 225, 244));
    HBRUSH wb = CreateSolidBrush(RGB(255, 255, 255));
    RECT all = { 0, 0, w, h }; FillRect(m, &all, wb);
    HGDIOBJ ob = SelectObject(m, bg), op = SelectObject(m, pen);
    RoundRect(m, 0, 0, w, h, S(18), S(18));
    SelectObject(m, bl); MoveToEx(m, S(18), h / 2, NULL); LineTo(m, w - S(18), h / 2);
    int rec = g_state == S_REC, live = rec && g_peak > 1200, paused = g_state == S_PAUSED;
    double lvl = rec ? g_peak / 12000.0 : 0; if (lvl > 1) lvl = 1;
    double tt = GetTickCount() / 1000.0 * 1.4;
    int bw = S(3), gap = S(4), total = 32 * bw + 31 * gap, x0 = (w - total) / 2;
    COLORREF mid = live ? RGB(115, 98, 205) : paused ? RGB(226, 223, 246) : RGB(214, 209, 243);
    COLORREF edge = live ? RGB(190, 181, 239) : paused ? RGB(238, 236, 250) : RGB(232, 229, 247);
    for (i = 0; i < 32; i++) {
        double pulse = 0.32 + fabs(sin(i * 0.72 + tt * 0.9)) * 0.68;
        double sc = 0.22 + lvl * 1.75 * pulse; if (sc > 1.35) sc = 1.35; if (sc < 0.22) sc = 0.22;
        int bh = (int)(S(34) * sc), y1 = (h - bh) / 2, x = x0 + i * (bw + gap);
        grad(m, x, y1, y1 + bh / 2, edge, mid);
        grad(m, x, y1 + bh / 2, y1 + bh, mid, edge);
    }
    BitBlt(dc, S(PW_X), S(PW_Y), w, h, m, 0, 0, SRCCOPY);
    SelectObject(m, ob); SelectObject(m, op); SelectObject(m, obm);
    DeleteObject(bg); DeleteObject(pen); DeleteObject(bl); DeleteObject(wb); DeleteObject(bm); DeleteDC(m);
}

static void make_fonts(void) {
    HFONT a = g_font, b = g_fontSmall, c = g_fontBig;
    g_fontScale = g_scale;
    g_font = CreateFontW(-F(15), 0, 0, 0, FW_SEMIBOLD, 0, 0, 0, DEFAULT_CHARSET, 0, 0, CLEARTYPE_QUALITY, 0, L"Segoe UI");
    g_fontSmall = CreateFontW(-F(13), 0, 0, 0, FW_NORMAL, 0, 0, 0, DEFAULT_CHARSET, 0, 0, CLEARTYPE_QUALITY, 0, L"Segoe UI");
    g_fontBig = CreateFontW(-F(42), 0, 0, 0, FW_BOLD, 0, 0, 0, DEFAULT_CHARSET, 0, 0, CLEARTYPE_QUALITY, 0, L"Georgia");
    if (a) { /* controls already exist: give them the new fonts, then free the old ones */
        int i; HWND all[] = { g_status, g_msg, g_skip, g_qual, g_over, g_top, g_name, g_lblName, g_lblQ, g_lblDir, g_dirTxt, g_btnSet, g_btnDir, g_foot, g_lblSize, g_size, g_lblHotkey, g_hotkeyValue, g_hotkeyNote };
        for (i = 0; i < 19; i++) if (all[i]) SendMessageW(all[i], WM_SETFONT, (WPARAM)g_font, TRUE);
        for (i = 0; i < 9; i++) if (g_btn[i]) SendMessageW(g_btn[i], WM_SETFONT, (WPARAM)g_font, TRUE);
        SendMessageW(g_timer, WM_SETFONT, (WPARAM)g_fontBig, TRUE);
        SendMessageW(g_msg, WM_SETFONT, (WPARAM)g_fontSmall, TRUE);
        SendMessageW(g_lblDir, WM_SETFONT, (WPARAM)g_fontSmall, TRUE);
        SendMessageW(g_dirTxt, WM_SETFONT, (WPARAM)g_fontSmall, TRUE);
        SendMessageW(g_foot, WM_SETFONT, (WPARAM)g_fontSmall, TRUE);
        if (g_hotkeyNote) SendMessageW(g_hotkeyNote, WM_SETFONT, (WPARAM)g_fontSmall, TRUE);
        DeleteObject(a); DeleteObject(b); DeleteObject(c);
    }
}

static void set_zoom(int pct) {
    g_zoom = pct; g_scale = g_dpi * pct / 100.0;
    make_fonts(); layout();
}

static HWND mkex(DWORD ex, const wchar_t *cls, const wchar_t *txt, DWORD style, int x, int y, int w, int h, int id, HFONT f) {
    HWND c = CreateWindowExW(ex, cls, txt, WS_CHILD | WS_VISIBLE | style, S(x), S(y), S(w), S(h), g_wnd, (HMENU)(INT_PTR)id, g_inst, NULL);
    SendMessageW(c, WM_SETFONT, (WPARAM)(f ? f : g_font), TRUE);
    return c;
}
static HWND mk(const wchar_t *cls, const wchar_t *txt, DWORD style, int x, int y, int w, int h, int id, HFONT f) {
    return mkex(0, cls, txt, style, x, y, w, h, id, f);
}

static void topmost(int on) {
    SetWindowPos(g_wnd, on ? HWND_TOPMOST : HWND_NOTOPMOST, 0, 0, 0, 0, SWP_NOMOVE | SWP_NOSIZE | SWP_NOACTIVATE);
}

static LRESULT CALLBACK proc(HWND h, UINT m, WPARAM w, LPARAM l) {
    switch (m) {
    case WM_CREATE: {
        int i; wchar_t df[MAX_PATH], docs[MAX_PATH];
        g_wnd = h;
        g_timer = mk(L"STATIC", L"00:00", SS_CENTER, 0, 10, 380, 56, ID_TIMER_TXT, g_fontBig);
        g_status = mk(L"STATIC", L"Ready to record", SS_CENTER, 0, 66, 380, 22, ID_STATUS, 0);
        g_btn[0] = mk(L"BUTTON", L"Record", BS_OWNERDRAW | WS_TABSTOP, 30, 178, 74, 38, ID_REC, 0);
        g_btn[1] = mk(L"BUTTON", L"Pause", BS_OWNERDRAW | WS_TABSTOP, 112, 178, 74, 38, ID_PAUSE, 0);
        g_btn[2] = mk(L"BUTTON", L"Stop", BS_OWNERDRAW | WS_TABSTOP, 194, 178, 74, 38, ID_STOP, 0);
        g_btn[3] = mk(L"BUTTON", L"Mark", BS_OWNERDRAW | WS_TABSTOP, 276, 178, 74, 38, ID_MARK, 0);
        g_lblName = mk(L"STATIC", L"File name", 0, 30, 235, 66, 20, 0, 0);
        g_name = mkex(WS_EX_CLIENTEDGE, L"EDIT", L"", ES_AUTOHSCROLL | WS_TABSTOP, 100, 232, 250, 24, ID_NAME, 0);
        SendMessageW(g_name, EM_LIMITTEXT, 120, 0);
        SendMessageW(g_name, EM_SETCUEBANNER, FALSE, (LPARAM)L"Empty = date and time");
        g_over = mk(L"BUTTON", L"Replace a file that has the same name", BS_AUTOCHECKBOX | WS_TABSTOP, 30, 266, 320, 22, ID_OVER, 0);
        g_skip = mk(L"BUTTON", L"Skip long silences while recording", BS_AUTOCHECKBOX | WS_TABSTOP, 30, 292, 320, 22, ID_SKIP, 0);
        g_top = mk(L"BUTTON", L"Keep this window on top of other windows", BS_AUTOCHECKBOX | WS_TABSTOP, 30, 318, 320, 22, ID_TOP, 0);
        g_lblHotkey = mk(L"STATIC", L"Global record/stop shortcut", 0, 30, 348, 320, 18, 0, 0);
        g_hotkeyValue = mk(L"STATIC", L"Ctrl+Shift+R", SS_LEFT, 30, 369, 145, 24, 0, 0);
        g_btn[7] = mk(L"BUTTON", L"Change", BS_OWNERDRAW | WS_TABSTOP, 180, 367, 75, 28, ID_HOTKEY_CHANGE, 0);
        g_btn[8] = mk(L"BUTTON", L"Default", BS_OWNERDRAW | WS_TABSTOP, 265, 367, 85, 28, ID_HOTKEY_DEFAULT, 0);
        g_hotkeyNote = mk(L"STATIC", L"Works while minimized. A single key is intercepted in other apps; Tab also affects normal focus navigation.", SS_LEFT, 30, 399, 320, 52, 0, g_fontSmall);
        g_btnSet = mk(L"BUTTON", L"Settings", BS_OWNERDRAW | WS_TABSTOP, 30, 458, 130, 28, ID_SETTINGS, 0);
        g_lblQ = mk(L"STATIC", L"Quality", 0, 30, 388, 60, 20, 0, 0);
        g_qual = mk(L"COMBOBOX", L"", CBS_DROPDOWNLIST | WS_TABSTOP | WS_VSCROLL, 92, 384, 258, 140, ID_QUAL, 0);
        for (i = 0; i < NFMT; i++) SendMessageW(g_qual, CB_ADDSTRING, 0, (LPARAM)FMT[i].label);
        g_lblDir = mk(L"STATIC", L"Save recordings in", 0, 30, 420, 320, 18, 0, g_fontSmall);
        g_dirTxt = mk(L"STATIC", L"", SS_LEFT | SS_PATHELLIPSIS, 30, 440, 320, 34, ID_DIRTXT, g_fontSmall);
        g_btnDir = mk(L"BUTTON", L"Change folder...", BS_OWNERDRAW | WS_TABSTOP, 30, 478, 150, 28, ID_DIR, 0);
        g_msg = mk(L"STATIC", L"Your recording is saved as you go. It stays on this computer until you upload it.", 0, 30, 518, 320, 64, ID_MSG, g_fontSmall);
        g_btn[4] = mk(L"BUTTON", L"Transcribe on TypeMyworDz", BS_OWNERDRAW | WS_TABSTOP, 30, 590, 320, 64, ID_WEB, 0);
        g_btn[5] = mk(L"BUTTON", L"Show file in folder", BS_OWNERDRAW | WS_TABSTOP, 30, 590, 320, 34, ID_FOLDER, 0);
        g_btn[6] = mk(L"BUTTON", L"Make the file smaller (free tool)", BS_OWNERDRAW | WS_TABSTOP, 30, 632, 320, 32, ID_SHRINK, 0);
        g_foot = mk(L"STATIC", L"Version " RECORDER_VERSION L" · Ctrl+Shift+R starts and stops recording from any window.", 0, 30, 672, 320, 34, ID_FOOT, g_fontSmall);
        g_lblSize = mk(L"STATIC", L"Window size", 0, 30, 388, 90, 20, 0, 0);
        g_size = mk(L"COMBOBOX", L"", CBS_DROPDOWNLIST | WS_TABSTOP | WS_VSCROLL, 124, 384, 226, 140, ID_SIZE, 0);
        for (i = 0; i < NZOOM; i++) SendMessageW(g_size, CB_ADDSTRING, 0, (LPARAM)ZOOMS[i].label);
        /* saved settings */
        i = (int)reg_get_dw(L"Format", 0); if (i < 0 || i >= NFMT) i = 0;
        SendMessageW(g_qual, CB_SETCURSEL, i, 0);
        { int zi = 5, k; DWORD zp = reg_get_dw(L"Zoom", 100);
          for (k = 0; k < NZOOM; k++) if ((DWORD)ZOOMS[k].pct == zp) zi = k;
          SendMessageW(g_size, CB_SETCURSEL, zi, 0);
          if (ZOOMS[zi].pct != g_zoom) { g_zoom = ZOOMS[zi].pct; g_scale = g_dpi * g_zoom / 100.0; make_fonts(); } }
        {
            DWORD saved_vk = reg_get_dw(L"HotkeyKey", DEFAULT_HOTKEY_VK);
            DWORD saved_mods = reg_get_dw(L"HotkeyMods", DEFAULT_HOTKEY_MODS);
            if (hotkey_is_valid(saved_vk, saved_mods)) { g_hotkeyVk = saved_vk; g_hotkeyMods = saved_mods; }
            g_hotkeyOk = register_global_hotkey(g_hotkeyMods, g_hotkeyVk);
            update_hotkey_controls();
            update_ready_status();
        }
        SendMessageW(g_top, BM_SETCHECK, reg_get_dw(L"OnTop", 0) ? BST_CHECKED : BST_UNCHECKED, 0);
        SendMessageW(g_over, BM_SETCHECK, reg_get_dw(L"Replace", 0) ? BST_CHECKED : BST_UNCHECKED, 0);
        SendMessageW(g_skip, BM_SETCHECK, reg_get_dw(L"SkipSilence", 0) ? BST_CHECKED : BST_UNCHECKED, 0);
        if (!reg_get_sz(L"Folder", g_dir, MAX_PATH)) {
            if (FAILED(SHGetFolderPathW(NULL, CSIDL_PERSONAL, NULL, 0, docs))) { GetTempPathW(MAX_PATH, docs); }
            swprintf(df, MAX_PATH, L"%ls\\TypeMyworDz Recordings", docs);
            wcscpy(g_dir, df);
        }
        SetWindowTextW(g_dirTxt, g_dir);
        if (reg_get_dw(L"OnTop", 0)) topmost(1);
        update_buttons();
        return 0;
    }
    case WM_ACTIVATE:
        if (LOWORD(w) == WA_INACTIVE && g_hotkeyCapturing) cancel_hotkey_capture();
        return DefWindowProcW(h, m, w, l);
    case WM_KILLFOCUS:
        if (g_hotkeyCapturing) cancel_hotkey_capture();
        return DefWindowProcW(h, m, w, l);
    case WM_KEYDOWN: case WM_SYSKEYDOWN:
        if (g_hotkeyCapturing) {
            if ((UINT)w == VK_ESCAPE) { cancel_hotkey_capture(); return 0; }
            if (is_modifier_vk((UINT)w)) return 0;
            finish_hotkey_capture((UINT)w, pressed_hotkey_mods());
            return 0;
        }
        break;
    case WM_COMMAND:
        switch (LOWORD(w)) {
        case ID_REC: start_recording(); break;
        case ID_PAUSE: pause_toggle(); break;
        case ID_STOP: stop_recording(); break;
        case ID_MARK: add_mark(); break;
        case ID_SETTINGS:
            if (g_hotkeyCapturing) cancel_hotkey_capture();
            g_showSet = !g_showSet; update_buttons(); break;
        case ID_HOTKEY_CHANGE: begin_hotkey_capture(); break;
        case ID_HOTKEY_DEFAULT:
            if (g_hotkeyCapturing) cancel_hotkey_capture();
            apply_hotkey(DEFAULT_HOTKEY_VK, DEFAULT_HOTKEY_MODS); break;
        case ID_DIR: choose_folder(); break;
        case ID_TOP: topmost(SendMessageW(g_top, BM_GETCHECK, 0, 0) == BST_CHECKED); save_settings(); break;
        case ID_OVER: case ID_SKIP: save_settings(); break;
        case ID_QUAL: if (HIWORD(w) == CBN_SELCHANGE) save_settings(); break;
        case ID_SIZE: if (HIWORD(w) == CBN_SELCHANGE) {
            int zi = (int)SendMessageW(g_size, CB_GETCURSEL, 0, 0);
            if (zi >= 0 && zi < NZOOM) { set_zoom(ZOOMS[zi].pct); save_settings(); }
        } break;
        case ID_WEB: open_url(L"https://typemywordz.ai/?utm_source=desktop-recorder"); break;
        case ID_SHRINK: open_url(L"https://typemywordz.ai/tools/audio-converter.html"); break;
        case ID_FOLDER: {
            wchar_t a[MAX_PATH + 32]; swprintf(a, MAX_PATH + 32, L"/select,\"%ls\"", g_path);
            ShellExecuteW(NULL, L"open", L"explorer.exe", a, NULL, SW_SHOWNORMAL); break; }
        }
        return 0;
    case MM_WIM_DATA: {
        WAVEHDR *hd = (WAVEHDR *)l;
        if (g_in && hd) {
            process_hdr(hd);
            if (g_state == S_REC) { hd->dwUser = 0; hd->dwBytesRecorded = 0; waveInAddBuffer(g_in, hd, sizeof(WAVEHDR)); }
        }
        return 0; }
    case WM_TIMER:
        if (w == TIMER_UI) {
            wchar_t t[32]; fmt_time(elapsed(), t, 32);
            if (wcscmp(t, g_lastTime)) { wcscpy(g_lastTime, t); SetWindowTextW(g_timer, t); }
            RECT r = { S(PW_X), S(PW_Y), S(PW_X + PW_W), S(PW_Y + PW_H) }; InvalidateRect(h, &r, FALSE);
            g_peak = g_peak * 8 / 10;
        }
        return 0;
    case WM_HOTKEY:
        if (w == HOTKEY_REC && !g_hotkeyCapturing) { if (g_state == S_IDLE) start_recording(); else stop_recording(); }
        return 0;
    case WM_DRAWITEM: draw_button((DRAWITEMSTRUCT *)l); return TRUE;
    case WM_CTLCOLORSTATIC: case WM_CTLCOLORBTN: {
        HDC dc = (HDC)w; int id = GetDlgCtrlID((HWND)l);
        SetBkColor(dc, RGB(255, 255, 255));
        SetTextColor(dc, id == ID_TIMER_TXT ? RGB(20, 22, 26) : (id == ID_STATUS || id == ID_FOOT || id == ID_DIRTXT) ? RGB(133, 138, 149) : RGB(63, 67, 76));
        return (LRESULT)g_white; }
    case WM_PAINT: {
        PAINTSTRUCT ps; HDC dc = BeginPaint(h, &ps);
        draw_wave(dc);
        EndPaint(h, &ps); return 0; }
    case WM_CLOSE:
        UnregisterHotKey(h, HOTKEY_REC);
        if (g_state != S_IDLE) stop_recording();
        save_settings();
        DestroyWindow(h); return 0;
    case WM_DESTROY: PostQuitMessage(0); return 0;
    }
    return DefWindowProcW(h, m, w, l);
}

int WINAPI wWinMain(HINSTANCE inst, HINSTANCE prev, LPWSTR cmd, int show) {
    (void)prev; (void)cmd;
    g_inst = inst;
    OleInitialize(NULL);
    InitCommonControls();
    HDC sdc = GetDC(NULL); g_dpi = GetDeviceCaps(sdc, LOGPIXELSX) / 96.0; ReleaseDC(NULL, sdc); g_scale = g_dpi;
    g_white = CreateSolidBrush(RGB(255, 255, 255));
    make_fonts();
    WNDCLASSW wc; ZeroMemory(&wc, sizeof wc);
    wc.lpfnWndProc = proc; wc.hInstance = inst; wc.hCursor = LoadCursor(NULL, IDC_ARROW);
    wc.hbrBackground = g_white; wc.lpszClassName = L"TMWZRecorder"; wc.hIcon = LoadIconW(inst, MAKEINTRESOURCEW(1));
    RegisterClassW(&wc);
    RECT r = { 0, 0, S(380), S(410) };
    AdjustWindowRect(&r, WINSTYLE, FALSE);
    HWND w = CreateWindowExW(0, L"TMWZRecorder", L"TypeMyworDz Recorder v" RECORDER_VERSION, WINSTYLE,
        CW_USEDEFAULT, CW_USEDEFAULT, r.right - r.left, r.bottom - r.top, NULL, NULL, inst, NULL);
    ShowWindow(w, show); UpdateWindow(w);
    MSG msg;
    while (GetMessageW(&msg, NULL, 0, 0) > 0) {
        if (g_hotkeyCapturing) DispatchMessageW(&msg);
        else if (!IsDialogMessageW(w, &msg)) { TranslateMessage(&msg); DispatchMessageW(&msg); }
    }
    OleUninitialize();
    return 0;
}
