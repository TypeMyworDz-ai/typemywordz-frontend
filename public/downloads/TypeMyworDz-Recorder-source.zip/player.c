#ifndef PLAYER_TEST
#define UNICODE
#define _UNICODE
#define WINVER 0x0601
#define _WIN32_WINNT 0x0601
#include <windows.h>
#include <mmsystem.h>
#endif
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <math.h>
#include "player.h"

/* ------------------------------------------------------------------ */
/* Time stretch (WSOLA): changes speed without changing the voice pitch. */
/* ------------------------------------------------------------------ */
struct TS {
    int rate, N, Hs, tol;
    float *win, *acc, *fifo;
    int fifo_n, fifo_cap;
    double apos;      /* nominal analysis position of the next frame */
    long natbase;     /* where the previous frame's natural continuation starts */
    int primed;
    double consumed;  /* source position corresponding to the start of the fifo */
};

TS *ts_new(int rate) {
    TS *t = (TS *)calloc(1, sizeof *t);
    int i;
    if (!t) return NULL;
    t->rate = rate;
    t->N = ((int)(rate * 0.04)) & ~1;
    if (t->N < 64) t->N = 64;
    t->Hs = t->N / 2;
    t->tol = (int)(rate * 0.012);
    t->win = (float *)malloc(sizeof(float) * t->N);
    t->acc = (float *)calloc(t->N, sizeof(float));
    t->fifo_cap = t->N * 8;
    t->fifo = (float *)malloc(sizeof(float) * t->fifo_cap);
    if (!t->win || !t->acc || !t->fifo) { ts_free(t); return NULL; }
    for (i = 0; i < t->N; i++) t->win[i] = (float)(0.5 - 0.5 * cos(2.0 * 3.14159265358979 * i / t->N));
    return t;
}
void ts_free(TS *t) { if (!t) return; free(t->win); free(t->acc); free(t->fifo); free(t); }
void ts_reset(TS *t, double pos) {
    if (!t) return;
    memset(t->acc, 0, sizeof(float) * t->N);
    t->fifo_n = 0; t->primed = 0; t->apos = pos; t->consumed = pos;
}
double ts_pos(const TS *t) { return t ? t->consumed : 0; }

static float sample_at(const short *in, long len, long i) { return (i >= 0 && i < len) ? (float)in[i] : 0.0f; }

static void ts_frame(TS *t, const short *in, long len, double speed) {
    int i, d, N = t->N, Hs = t->Hs;
    long chosen;
    if (!t->primed) {
        chosen = (long)t->apos;
        t->primed = 1;
    } else {
        long target = (long)(t->apos + 0.5), bestd = 0;
        double best = -1e30;
        for (d = -t->tol; d <= t->tol; d += 2) {
            double c = 0, e = 1e-3;
            long b = target + d;
            if (b < 0) continue;
            for (i = 0; i < Hs; i += 2) {
                float x = sample_at(in, len, b + i), y = sample_at(in, len, t->natbase + i);
                c += (double)x * y; e += (double)x * x;
            }
            c /= sqrt(e);
            if (c > best) { best = c; bestd = d; }
        }
        chosen = target + bestd;
        if (chosen < 0) chosen = 0;
    }
    for (i = 0; i < N; i++) t->acc[i] += t->win[i] * sample_at(in, len, chosen + i);
    if (t->fifo_n + Hs > t->fifo_cap) { /* cannot happen with the caller's loop, but stay safe */
        int keep = t->fifo_cap - Hs;
        memmove(t->fifo, t->fifo + (t->fifo_n - keep), sizeof(float) * keep);
        t->fifo_n = keep;
    }
    memcpy(t->fifo + t->fifo_n, t->acc, sizeof(float) * Hs);
    t->fifo_n += Hs;
    memmove(t->acc, t->acc + Hs, sizeof(float) * Hs);
    memset(t->acc + Hs, 0, sizeof(float) * Hs);
    t->natbase = chosen + Hs;
    t->apos += Hs * speed;
}

double ts_render(TS *t, const short *in, long len, double speed, short *out, int n) {
    int i;
    if (speed < 0.5) speed = 0.5;
    if (speed > 3.0) speed = 3.0;
    if (n > t->fifo_cap - t->Hs) n = t->fifo_cap - t->Hs;
    while (t->fifo_n < n) ts_frame(t, in, len, speed);
    for (i = 0; i < n; i++) {
        float v = t->fifo[i];
        out[i] = (short)(v > 32767.f ? 32767 : v < -32768.f ? -32768 : v);
    }
    memmove(t->fifo, t->fifo + n, sizeof(float) * (t->fifo_n - n));
    t->fifo_n -= n;
    t->consumed = t->apos - (double)t->fifo_n * speed;
    return t->consumed;
}

#ifndef PLAYER_TEST
#define MINIMP3_IMPLEMENTATION
#define MINIMP3_ONLY_MP3
#include "minimp3.h"

/* ------------------------------------------------------------------ */
/* Loading                                                              */
/* ------------------------------------------------------------------ */
#define PNB 4
static short *g_pcm; static long g_n; static int g_prate = 22050;
static CRITICAL_SECTION g_cs; static int g_cs_ready;
static HWAVEOUT g_hwo; static HANDLE g_ev, g_th;
static WAVEHDR g_h[PNB]; static short *g_hb[PNB]; static int g_hq[PNB];
static int g_chunk;
static volatile int g_quit, g_playing, g_eof, g_ended, g_dirty;
static double g_vol = 1.0, g_speed = 1.0, g_pos = 0;
static long g_written; /* output samples queued since the last reset */
static TS *g_ts;

static unsigned char *read_all(const wchar_t *path, DWORD *size) {
    HANDLE f = CreateFileW(path, GENERIC_READ, FILE_SHARE_READ | FILE_SHARE_WRITE, NULL, OPEN_EXISTING, FILE_ATTRIBUTE_NORMAL, NULL);
    LARGE_INTEGER sz; unsigned char *b = NULL; DWORD got = 0, total = 0;
    if (f == INVALID_HANDLE_VALUE) return NULL;
    if (!GetFileSizeEx(f, &sz) || sz.QuadPart <= 0 || sz.QuadPart > 0x7fffffff) { CloseHandle(f); return NULL; }
    b = (unsigned char *)malloc((size_t)sz.QuadPart);
    if (!b) { CloseHandle(f); return NULL; }
    while (total < (DWORD)sz.QuadPart && ReadFile(f, b + total, (DWORD)sz.QuadPart - total, &got, NULL) && got) total += got;
    CloseHandle(f);
    *size = total;
    return b;
}

static int load_wav(const unsigned char *b, DWORD size) {
    DWORD pos = 12; int rate = 0, ch = 0, bits = 0;
    if (size < 44 || memcmp(b, "RIFF", 4) || memcmp(b + 8, "WAVE", 4)) return -1;
    while (pos + 8 <= size) {
        DWORD len = b[pos + 4] | (b[pos + 5] << 8) | (b[pos + 6] << 16) | ((DWORD)b[pos + 7] << 24);
        if (!memcmp(b + pos, "fmt ", 4) && pos + 24 <= size) {
            ch = b[pos + 10] | (b[pos + 11] << 8);
            rate = b[pos + 12] | (b[pos + 13] << 8) | (b[pos + 14] << 16) | ((DWORD)b[pos + 15] << 24);
            bits = b[pos + 22] | (b[pos + 23] << 8);
        } else if (!memcmp(b + pos, "data", 4)) {
            DWORD avail = size - (pos + 8);
            if (len > avail) len = avail;
            if (bits != 16 || ch < 1 || rate < 8000) return -1;
            g_n = (long)(len / 2 / ch);
            g_pcm = (short *)malloc(sizeof(short) * (g_n + 1));
            if (!g_pcm) return -1;
            { long i; const short *s = (const short *)(b + pos + 8); for (i = 0; i < g_n; i++) g_pcm[i] = s[i * ch]; }
            g_prate = rate;
            return 0;
        }
        pos += 8 + len + (len & 1);
    }
    return -1;
}

static int load_mp3(const unsigned char *b, DWORD size) {
    mp3dec_t dec; mp3dec_frame_info_t info; short frame[MINIMP3_MAX_SAMPLES_PER_FRAME];
    long cap = 1 << 20, n = 0; short *out = (short *)malloc(sizeof(short) * cap);
    DWORD off = 0; int rate = 0;
    if (!out) return -1;
    mp3dec_init(&dec);
    while (off < size) {
        int s = mp3dec_decode_frame(&dec, b + off, (int)(size - off), frame, &info);
        if (info.frame_bytes <= 0) break;
        off += info.frame_bytes;
        if (s > 0) {
            int c = info.channels > 0 ? info.channels : 1, i;
            if (!rate) rate = info.hz;
            if (info.hz != rate) continue;
            if (n + s > cap) {
                short *t; while (n + s > cap) cap *= 2;
                t = (short *)realloc(out, sizeof(short) * cap);
                if (!t) { free(out); return -1; }
                out = t;
            }
            for (i = 0; i < s; i++) out[n + i] = frame[i * c];
            n += s;
        }
    }
    if (n < 100 || !rate) { free(out); return -1; }
    g_pcm = out; g_n = n; g_prate = rate;
    return 0;
}

static void apply_state(void) {
    if (!g_hwo) return;
    if (g_playing) waveOutRestart(g_hwo); else waveOutPause(g_hwo);
}

static void fill(int k) {
    int i; short *o = g_hb[k];
    double speed = g_speed, gain = g_vol;
    if (g_dirty) { ts_reset(g_ts, g_pos); g_dirty = 0; }
    if (speed > 0.98 && speed < 1.02) {
        /* normal speed: straight copy, no processing at all */
        long p = (long)ts_pos(g_ts);
        for (i = 0; i < g_chunk; i++) o[i] = (p + i < g_n) ? g_pcm[p + i] : 0;
        ts_reset(g_ts, (double)(p + g_chunk));
    } else {
        ts_render(g_ts, g_pcm, g_n, speed, o, g_chunk);
    }
    g_pos = ts_pos(g_ts);
    for (i = 0; i < g_chunk; i++) {
        double v = o[i] * gain;
        o[i] = (short)(v > 32767.0 ? 32767 : v < -32768.0 ? -32768 : v);
    }
    if (g_pos >= (double)g_n) g_eof = 1;
    g_h[k].dwBufferLength = g_chunk * 2;
    waveOutWrite(g_hwo, &g_h[k], sizeof(WAVEHDR));
    g_hq[k] = 1;
    g_written += g_chunk;
}

static DWORD WINAPI feeder(LPVOID p) {
    (void)p;
    while (!g_quit) {
        int k, busy = 0;
        WaitForSingleObject(g_ev, 40);
        EnterCriticalSection(&g_cs);
        if (g_hwo && !g_quit) {
            for (k = 0; k < PNB; k++) {
                if (g_hq[k] && (g_h[k].dwFlags & WHDR_DONE)) g_hq[k] = 0;
                if (!g_hq[k] && !g_eof) fill(k);
                if (g_hq[k]) busy = 1;
            }
            if (g_eof && !busy && g_playing) { g_playing = 0; g_ended = 1; apply_state(); }
        }
        LeaveCriticalSection(&g_cs);
    }
    return 0;
}

int pl_loaded(void) { return g_pcm != NULL && g_hwo != NULL; }

void pl_unload(void) {
    int k;
    if (!g_cs_ready) return;
    g_quit = 1;
    if (g_ev) SetEvent(g_ev);
    if (g_th) { WaitForSingleObject(g_th, 2000); CloseHandle(g_th); g_th = NULL; }
    EnterCriticalSection(&g_cs);
    if (g_hwo) {
        waveOutReset(g_hwo);
        for (k = 0; k < PNB; k++) { waveOutUnprepareHeader(g_hwo, &g_h[k], sizeof(WAVEHDR)); free(g_hb[k]); g_hb[k] = NULL; g_hq[k] = 0; }
        waveOutClose(g_hwo); g_hwo = NULL;
    }
    free(g_pcm); g_pcm = NULL; g_n = 0;
    ts_free(g_ts); g_ts = NULL;
    if (g_ev) { CloseHandle(g_ev); g_ev = NULL; }
    g_playing = 0; g_ended = 0; g_eof = 0; g_pos = 0;
    LeaveCriticalSection(&g_cs);
}

int pl_load(const wchar_t *path) {
    DWORD size = 0; unsigned char *b; int rc, k; WAVEFORMATEX wf;
    size_t L = wcslen(path);
    if (!g_cs_ready) { InitializeCriticalSection(&g_cs); g_cs_ready = 1; }
    pl_unload();
    b = read_all(path, &size);
    if (!b) return -1;
    rc = (L > 4 && _wcsicmp(path + L - 4, L".wav") == 0) ? load_wav(b, size) : load_mp3(b, size);
    free(b);
    if (rc != 0) { free(g_pcm); g_pcm = NULL; return -1; }
    g_ts = ts_new(g_prate);
    if (!g_ts) { free(g_pcm); g_pcm = NULL; return -1; }
    g_chunk = g_prate / 20;
    ZeroMemory(&wf, sizeof wf);
    wf.wFormatTag = WAVE_FORMAT_PCM; wf.nChannels = 1; wf.nSamplesPerSec = g_prate; wf.wBitsPerSample = 16;
    wf.nBlockAlign = 2; wf.nAvgBytesPerSec = g_prate * 2;
    g_ev = CreateEventW(NULL, FALSE, FALSE, NULL);
    if (waveOutOpen(&g_hwo, WAVE_MAPPER, &wf, (DWORD_PTR)g_ev, 0, CALLBACK_EVENT) != MMSYSERR_NOERROR) {
        g_hwo = NULL; CloseHandle(g_ev); g_ev = NULL; free(g_pcm); g_pcm = NULL; ts_free(g_ts); g_ts = NULL; return -2;
    }
    for (k = 0; k < PNB; k++) {
        g_hb[k] = (short *)calloc(g_chunk, sizeof(short));
        ZeroMemory(&g_h[k], sizeof(WAVEHDR));
        g_h[k].lpData = (LPSTR)g_hb[k]; g_h[k].dwBufferLength = g_chunk * 2;
        waveOutPrepareHeader(g_hwo, &g_h[k], sizeof(WAVEHDR));
        g_hq[k] = 0;
    }
    g_pos = 0; g_eof = 0; g_ended = 0; g_playing = 0; g_written = 0; g_dirty = 1; g_quit = 0;
    waveOutPause(g_hwo);
    g_th = CreateThread(NULL, 0, feeder, NULL, 0, NULL);
    return 0;
}

int pl_playing(void) { return g_playing; }
int pl_ended(void) { return g_ended; }
double pl_dur(void) { return g_pcm ? (double)g_n / g_prate : 0; }

static void seek_locked(double sec) {
    if (sec < 0) sec = 0;
    if (sec > pl_dur()) sec = pl_dur();
    waveOutReset(g_hwo);
    { int k; for (k = 0; k < PNB; k++) g_hq[k] = 0; }
    g_pos = sec * g_prate; g_dirty = 1; g_eof = (g_pos >= (double)g_n); g_ended = 0;
    g_written = 0;
    apply_state();
    if (g_ev) SetEvent(g_ev);
}

void pl_seek(double sec) {
    if (!pl_loaded()) return;
    EnterCriticalSection(&g_cs); seek_locked(sec); LeaveCriticalSection(&g_cs);
}

int pl_play(void) {
    if (!pl_loaded()) return -1;
    EnterCriticalSection(&g_cs);
    if (g_ended || g_pos >= (double)g_n - 1) seek_locked(0);
    g_playing = 1; g_ended = 0; apply_state();
    if (g_ev) SetEvent(g_ev);
    LeaveCriticalSection(&g_cs);
    return 0;
}

void pl_pause(void) {
    if (!pl_loaded()) return;
    EnterCriticalSection(&g_cs); g_playing = 0; apply_state(); LeaveCriticalSection(&g_cs);
}

double pl_pos(void) {
    double p, queued = 0;
    MMTIME mt;
    if (!pl_loaded()) return 0;
    EnterCriticalSection(&g_cs);
    p = g_pos;
    mt.wType = TIME_SAMPLES;
    if (waveOutGetPosition(g_hwo, &mt, sizeof mt) == MMSYSERR_NOERROR && mt.wType == TIME_SAMPLES) {
        queued = (double)g_written - (double)mt.u.sample;
        if (queued < 0) queued = 0;
    }
    p -= queued * g_speed;
    if (g_eof && !g_playing) p = g_ended ? (double)g_n : p;
    LeaveCriticalSection(&g_cs);
    if (p < 0) p = 0;
    if (p > (double)g_n) p = (double)g_n;
    return p / g_prate;
}

void pl_set_volume(double v) { if (v < 0) v = 0; if (v > 2) v = 2; g_vol = v; }
void pl_set_speed(double s) {
    if (s < 0.5) s = 0.5;
    if (s > 3) s = 3;
    if (!g_cs_ready) { g_speed = s; return; }
    EnterCriticalSection(&g_cs);
    if (fabs(s - g_speed) > 1e-6) { g_speed = s; g_dirty = 1; }
    LeaveCriticalSection(&g_cs);
}
#endif /* PLAYER_TEST */
